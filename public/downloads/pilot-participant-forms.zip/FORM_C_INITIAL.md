# Form C: A partial fill changes the hedge — initial packet

Fictional teaching data. Save your initial recommendation, calculations and uncertainty before requesting the separate update. Record prior exposure and any assistance; this public blueprint is not automatically an unseen assessment.

## Contract and accounting conventions

All issuers, portfolios, quotes, fills, events and mandates below are invented. Cash interest, dividends, taxes, stock commissions and modeled settlement charges are zero. Each filled option entry contract costs a total $1 fee for that leg. Premiums already paid or received remain part of cash; they are not counted again in terminal payoff. Use supplied option asks for purchases and bids for sales. Displayed quotes alone do not guarantee a fill. Adequate size and actual execution at the supplied side are stipulated only for each initial comparison.

Initial scenario tables assume the stated positions remain intact until the common three-month expiration and value the supplied terminal rights/obligations. They do not predict an American option's pre-expiration value or eliminate early-assignment exposure. Where an update supplies an American-style physical-assignment event, rebuild positions and cash from that event; it is a separate operational rehearsal. Do not invent option marks, exit prices, exercise choices or broker permissions that the packet does not supply.

### Learner packet

The fictional Cedar committee owns **200 shares at $80 and $5,000 cash**, total current wealth **$21,000**. It seeks protection against a severe three-month decline while preserving some participation in a rise. It requires **$4,200 accessible cash immediately after implementation**. Borrowing and naked short options are not authorized.

All initial options are same-expiry standard 100-share contracts with premium multiplier 100 and aggregate exercise cash of strike × 100.

| Instrument | Bid/share | Ask/share |
|---|---:|---:|
| $72 put | $4.60 | $5.00 |
| $90 call | $3.00 | $3.40 |

- **A: Hold.** Keep 200 shares and cash.
- **B: Reduce shares.** Sell 100 shares at $80; keep 100 shares and all cash/proceeds.
- **C: Protect.** Keep 200 shares and buy two $72 puts at the ask, with entry fees.
- **D: Collar.** Keep 200 shares, buy two $72 puts at the ask and sell two covered $90 calls at the bid, with all entry fees.

Build cash and terminal wealth at stock prices **$45, $72, $80, $90 and $110**, plus change from $21,000. Test cash feasibility before recommending an action. Identify the difference between a planned hedge and evidence that it actually exists.

Defense question: Which decision can be correct at planning time but require a different response after execution?
