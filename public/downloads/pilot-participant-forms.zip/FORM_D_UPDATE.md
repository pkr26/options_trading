# Form D: Adjusted deliverables and surviving coverage — update packet

Release only after the initial response has been saved. Preserve it, then write and defend a separate revision.

Audit this supplied operational event for D: after implementation, **one adjusted short call is assigned early**. The broker confirms delivery of 50 shares and receipt of $1,500 strike cash. No put has been exercised, no other option has closed, and no further fees are charged in this event.

Reconcile cash, shares, puts and remaining short calls. Is every remaining call still share-covered? A colleague says the assignment automatically exercises a put. Evaluate that claim. Then perform a separate hypothetical ledger exercise: if the committee elects to exercise one adjusted put without any other trade, what changes, and would all remaining calls still be share-covered? The packet supplies no current option marks or exit quotes; identify what that prevents you from reporting.
