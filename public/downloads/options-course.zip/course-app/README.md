# Browser application note

This offline download contains teaching material and Python labs. It does not contain the frontend/backend application source, its dependencies, runtime files, or any user database.

To study without the app, open [the beginner course](../beginner/README.md). To run the browser app, use the separate source checkout and its course-app/README.md setup instructions, or a hosted link supplied separately. Commands for the app require that full source checkout; they do not run from this teaching-only package.
