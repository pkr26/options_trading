# Advanced Options Academy

Case seminars, analytical practice, and defended portfolio decisions. All case data are fictional unless explicitly sourced.

## Module 1: Money, markets, and the purpose of trading

Separate financial objectives, essential cash and risk capital before evaluating an option.

Stage: Foundations and account decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: Foundation diagnostic.

### Decision, intuition and learning outcome

## Begin with a decision

A budget is a set of claims on money, not merely an account balance. A dollar promised for a near-term bill cannot simultaneously absorb a speculative loss. Begin with the obligation and work toward the instrument. Percentage returns become useful only after you identify the capital base, time horizon and possible loss.

**Learning outcome:** Separate financial objectives, essential cash and risk capital before evaluating an option.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

Start with an everyday distinction. **Saving** puts money aside for a future need. **Investing** puts money into assets whose value and cash flows are uncertain, often for years. **Trading** means making shorter-horizon decisions to buy, sell, or hedge. None of these words describes a guaranteed return. An options position can change value much faster than a stock position, so the first trading skill is knowing which money is available for risk and which money pays for ordinary life. In your notebook, keep living expenses, emergency reserves, debt obligations, and potential trading capital as separate lines. A classroom exercise can use hypothetical capital even if you have no money available for trading.

A **share of stock** is a unit of ownership in a company. An **exchange-traded fund (ETF)** is a fund whose shares trade on an exchange and hold assets according to its rules. An **index** is a calculated measure, such as a basket's level; the index itself is not a share you can take home. Options can reference a stock, ETF, or index, but their contract terms may differ. Before learning an option, learn to ask what its underlying actually is. The [SEC's investing basics](https://www.investor.gov/introduction-investing/investing-basics/investment-products) is a starting reference for products. We will use an imaginary company, ABC, rather than a real ticker so that examples cannot be mistaken for recommendations.

Trading needs infrastructure. A **broker** is the firm through which a customer submits orders and maintains an account. An **exchange** organizes trading and publishes market rules and prices. The **Options Clearing Corporation (OCC)** clears standardized U.S. listed securities options and sets out the rights, obligations, exercise, and assignment framework in its [disclosure document](https://www.theocc.com/company-information/documents-and-archives/options-disclosure-document). The broker determines what option strategies an account is approved to use; [the SEC says approval levels and allowed strategies vary by firm](https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-77). You do not need an options account to complete the first part of this course.

Measure outcomes in both dollars and percentages. If 100 ABC shares cost $50 each, the position costs $5,000. At $55 each, its market value is $5,500 and its gain is $500, or `500 / 5,000 = 10%` before costs and taxes. At $45, the loss is $500, or 10%. A loss and its recovery are asymmetric: $5,000 falling by 50% becomes $2,500. A later 50% rise produces $3,750, still below the start. To return to $5,000 from $2,500 requires a 100% gain. This is why avoiding a severe loss matters more than collecting impressive small wins.

Time and alternatives matter as much as the percentage. A 10% gain over one year and a 10% gain over ten years describe different outcomes. A $500 profit from risking nearly all of a small account is different from the same profit on a well-controlled exposure. A trading journal should therefore record the starting amount, dates, capital tied up, worst loss along the way, and a sensible comparison such as holding the underlying or staying in cash. This does not mean cash is always better; it means you should be able to describe what extra risk an option is supposed to solve. The eventual aim is a repeatable decision process, not a striking single result.

**Vocabulary to own:** asset, stock, ETF, index, broker, exchange, clearinghouse, cost basis, return, drawdown, liquidity, risk capital. A *drawdown* is a decline from a prior peak; it is not automatically the same as the total loss on one trade. Do not use a high percentage return to judge skill until you know the starting capital, risk taken, fees, and the time period.

**Common mistakes to catch:** calling an index a share, treating all account cash as available for a loss, or comparing two percentages without their time periods and drawdowns.

### Four teaching weeks

| Week | Use the 2/3/2/2/1-hour pattern |
| --- | --- |
| 1 | Complete [ADVANCED_FIRST_WEEK.md](ADVANCED_FIRST_WEEK.md); rewrite its seven key definitions in your own words; observe one stock and one ETF quote without placing an order; correct the quiz. |
| 2 | Read the SEC product overview. Make a one-page map of stock, ETF, index, broker, exchange, and OCC; calculate ten stock-position dollar values and returns. Use the [math bridge](FOUNDATION_MATH_BRIDGE.md) for percentages and units as needed. |
| 3 | Write a hypothetical budget separating essential money from an imaginary practice account; observe how a stock and ETF price move over five sessions; note that an index is a calculation, not a deliverable share. |
| 4 | Work drawdown and recovery problems, teach the broker/exchange/OCC map aloud, and take the closed-note check below. Correct the math-bridge diagnostic if needed. |

### Try it before opening the answers

1. You buy 20 ABC shares at $40. What was the cost, and what is the percentage return if the share price becomes $44, before costs?
2. An account moves from $8,000 to $6,000. What is its drawdown from that peak? What return on $6,000 is needed to reach $8,000 again?
3. Which is a calculated level rather than a share: ABC stock, ABC ETF, or ABC index?
4. Name the distinct jobs of broker, exchange, and OCC in one sentence each.
5. Why is a 40% gain by itself insufficient evidence that someone is a skilled trader?

<details><summary>Module 1 worked answers</summary>

1. Cost is `20 × $40 = $800`. New value is `20 × $44 = $880`. Gain is `$80 / $800 = 10%`.
2. Loss is `$2,000 / $8,000 = 25%`. Recovery requires `$2,000 / $6,000 = 33⅓%`, not 25%.
3. The index. A stock or ETF has tradable shares; an index is a calculated reference level.
4. Broker handles the customer account and order; exchange runs the trading venue and rules; OCC clears listed option contracts and their exercise/assignment obligations.
5. You need the time period, starting capital, losses and drawdowns, position size, fees, and a fair benchmark; one gain could follow a large gamble.

</details>

**Pass gate:** 5/5 with correct arithmetic and a plain-language explanation. Produce a one-page map of the market and a hypothetical budget; no real order is part of this gate.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** A different household has $24,000 cash, a $15,000 reserve and $7,500 bills. Find the uncommitted balance and explain why it is not automatically an appropriate loss budget.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The household capital committee

**Fictional teaching case.** You advise a fictional household with $18,000 in cash. One person wants to reserve $5,000 for an options-learning account because a friend reported a 40% gain. Another insists that learning must preserve emergency and bill money. You must recommend a classroom plan that both can understand.

| Item | Amount | Timing |
|---|---:|---|
| Cash currently available | $18,000 | Today |
| Agreed emergency reserve | $12,000 | Must remain accessible |
| Known bill | $4,000 | In six weeks |
| Proposed practice allocation | $5,000 | Today |

The friend's starting capital, dates, costs and drawdown are unknown. There is no obligation to open an account.

### Initial decision

Recommend a learning budget and explain which money is committed. What evidence would be needed before interpreting the reported 40%?

### New information — commit your first decision before reading

The household learns that the six-week bill will be $5,500. Preserve the first memo, recalculate the uncommitted amount and revise the plan.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The household capital committee'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Initially, $18,000 − $12,000 − $4,000 = $2,000 is uncommitted under the stated reserve policy; that is not a recommendation to risk it. A $5,000 allocation would use $3,000 already committed elsewhere. After the update only $500 is uncommitted. A simulation-only plan is feasible under either budget. The friend's return cannot establish skill without dates, capital, drawdowns, costs and a comparator. A good answer begins with the household's obligations rather than an attractive percentage.

### Weak — unsupported submission

A 40% return sounds high, so allocate the requested $5,000. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Initially, $18,000 − $12,000 − $4,000 = $2,000 is uncommitted under the stated reserve policy; that is not a recommendation to risk it. A $5,000 allocation would use $3,000 already committed elsewhere. After the update only $500 is uncommitted. A simulation-only plan is feasible under either budget. The friend's return cannot establish skill without dates, capital, drawdowns, costs and a comparator. A good answer begins with the household's obligations rather than an attractive percentage. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

Only $2,000 is initially uncommitted and $500 after the update. I recommend fictional practice while the household states a separate loss tolerance; the reported return is insufficient evidence for reallocating committed cash.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Separate financial objectives, essential cash and risk capital before evaluating an option. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The household capital committee'. Recommend a learning budget and explain which money is committed. What evidence would be needed before interpreting the reported 40%?

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- A different household has $24,000 cash, a $15,000 reserve and $7,500 bills. Find the uncommitted balance and explain why it is not automatically an appropriate loss budget.
- Teach the central distinction of 'The household capital committee' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [SEC's investing basics](https://www.investor.gov/introduction-investing/investing-basics/investment-products)
- [disclosure document](https://www.theocc.com/company-information/documents-and-archives/options-disclosure-document)
- [the SEC says approval levels and allowed strategies vary by firm](https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-77)

## Module 2: How to read an option quote

Audit a quote before converting it into an order or an expected result.

Stage: Foundations and account decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 1.

### Decision, intuition and learning outcome

## Begin with a decision

Read a chain row like a dated contract record. The last trade answers what happened earlier; the bid and ask describe displayed interest now. Premium multiplier, exercise deliverable and displayed size answer different questions. An apparently cheap quote is not meaningful until its identity and timestamp are coherent.

**Learning outcome:** Audit a quote before converting it into an order or an expected result.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

A quote is an invitation to trade at indicated prices, not a record of what you will earn. The **bid** is the displayed price at which someone is currently willing to buy; the **ask** or offer is the displayed price at which someone is willing to sell. The **bid–ask spread** is the difference. If a standard 100-share stock option has a bid of $2.10 and an ask of $2.30, buying one at the displayed ask costs `$2.30 × 100 = $230`. If the market is unchanged and you immediately sell at the displayed bid, you receive `$2.10 × 100 = $210`. The $20 difference is a cost before commissions. The $2.20 **midpoint** is just `(bid + ask) / 2`; nobody has promised a fill there. Quotes can move or disappear before an order arrives.

An option quote must identify more than a ticker. Record the **underlying**, **call or put**, **strike**, **expiration**, **premium multiplier**, and **exercise deliverable** as separate fields. The premium multiplier converts a per-share quote into contract dollars; the deliverable describes what exercise transfers. They can differ on adjusted contracts. The **last trade** is a past transaction, possibly at an old price. **Volume** counts contracts traded during the session. **Open interest** counts outstanding contracts under the reporting convention and may not reflect today's trades yet. Neither volume nor open interest alone guarantees that you can enter or leave at a good price. A liquid contract often has a narrower spread and accessible size, but liquidity can change when a stock moves or news breaks. [OIC's options tools](https://www.optionseducation.org/options-quotes-calculators) show delayed quotes and calculators; delayed data are for learning, not a live execution assumption.

Consider a displayed quote: `ABC Dec 18 $50 call, bid $1.45, ask $1.65, last $1.80, volume 200, open interest 4,000`. Read it from left to right. ABC is the underlying, December 18 is the expiration, $50 is the strike, and this is a call. If the deliverable is standard 100 shares, the ask represents $165 per contract. The last price of $1.80 does **not** mean the current option can be sold for $180. At the displayed bid, one contract would bring in $145 before fees. The displayed spread is $0.20 per share, or $20 per contract. Check the quote timestamp, particularly when using free delayed data.

A **market order** asks to trade promptly against available interest and can fill at prices worse than the screen last showed. A **limit order** specifies your worst acceptable price for a buy or sale, but may never fill. Imagine a buy limit at $1.55 when the ask is $1.65. The order might be filled if someone sells at $1.55; it might also sit unfilled. The $10 improvement from ask to limit is not a saving until a fill actually occurs. In later research you will count rejected and unfilled orders as part of the process, rather than inventing midpoint trades.

The same $0.20 per-share spread has different importance for different option prices. On a $10 option it is a small fraction of the premium; on a $0.30 option it consumes most of the quoted price. Calculate both the **dollar spread** and its size relative to the ask. An option may display one contract at the best bid and many at other prices, so a larger order may not all fill at the best quote. Nor does a tight screen guarantee the same liquidity during a sudden move. As a beginner, read the chain to learn how markets work, not to identify the option with the biggest percentage movement.

**Vocabulary to own:** bid, ask, midpoint, spread, last, volume, open interest, multiplier, deliverable, market order, limit order, timestamp. Read a quote as a bundle of exact contract terms plus a time-specific market, not as a single option price.

**Common mistakes to catch:** multiplying a premium quote by 100 before checking the actual premium multiplier; assuming the share deliverable must equal that multiplier; treating a last trade as today's bid; assuming a limit order must fill; or mistaking open interest for the number of contracts traded today.

### Four teaching weeks

| Week | Use the 2/3/2/2/1-hour pattern |
| --- | --- |
| 5 | Label every field in ten invented quotes; practice converting quoted per-share premiums into contract dollars; observe OIC's delayed chain. |
| 6 | Record five real delayed quotes with timestamps; compute each spread in dollars and as a fraction of the ask; watch how the quote changes without trading. |
| 7 | Compare last, bid, ask, volume, and open interest for ten contract rows. Draft ten hypothetical limit orders and state whether the screen guarantees a fill. |
| 8 | Build a 20-row quote notebook, including the underlying and contract identifiers. Audit every multiplier, timestamp, and round-trip spread calculation. |

### Try it before opening the answers

1. A standard contract is quoted $0.80 bid / $1.00 ask. What is the displayed spread per share and per contract? What is the immediate ask-to-bid loss before fees?
2. A call's last price is $2.40, but its current bid is $1.70 and ask is $1.90. At the displayed prices, how much would a one-contract marketable sale bring in before fees?
3. What contract identifiers and separate multiplier and deliverable fields should you write down before converting a quoted premium into dollars?
4. A buy limit is $1.50 while the displayed ask is $1.60. Does the limit order guarantee a $1.50 fill? What is the most it authorizes you to pay per share if it fills?
5. A contract shows high open interest but a very wide spread. What can you conclude about the price at which you will exit tomorrow?

<details><summary>Module 2 worked answers</summary>

1. Spread is `$1.00 − $0.80 = $0.20` per share, or `$20` for 100 shares. An unchanged immediate buy at ask and sell at bid loses $20 before fees.
2. `$1.70 × 100 = $170`. The $2.40 last trade does not set the current sale price. This assumes the displayed bid remains and has enough size when the order reaches it.
3. Underlying, call/put type, strike, expiration, actual **premium multiplier**, and actual **exercise deliverable** in separate fields; also record timestamp and exercise/settlement terms before acting.
4. No. It may not fill. If it fills as a standard buy limit order, it authorizes at most $1.50 per share, excluding fees.
5. You cannot know tomorrow's exit price or spread from today's open interest; market conditions and quotes can change.

</details>

**Pass gate:** 5/5 and a 20-row quote notebook with accurate dollar conversions. You must never substitute last or midpoint for a guaranteed execution price.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Change the bid/ask to $0.40/$0.70 with size three and a four-contract intention. What is the per-contract spread and which quantity remains unsupported by the top displayed ask?

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The attractive last price

**Fictional teaching case.** A fictional study group wants to buy two calls because the last trade was $2.60. Their screen shows a lower current ask, but the group has not checked size or quote time.

Standard 100-share call; strike $50; one stated expiry. At 10:00:00: bid $2.00, ask $2.30, last $2.60 from 09:35; displayed ask size is one contract. Assume $0 fees only for the first hand calculation. No actual fill report exists.

### Initial decision

Write an order-intent note for two contracts. Calculate one contract at the displayed ask and an immediate one-contract bid-side exit. State what cannot be inferred for the second contract.

### New information — commit your first decision before reading

At 10:00:02 the ask becomes $2.50 and the bid $2.10. Your $2.30 buy limit is still reported open. Should the journal contain a filled position?

### Defense

- What is the strongest reason to disagree with your recommendation in 'The attractive last price'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

One contract at $2.30 would cost $230; an immediate sale at $2.00 would receive $200, a $30 quote-side loss before fees. Two contracts cannot simply be assumed to fill at an ask displaying size one. The old $2.60 last trade is not a guaranteed exit value. After the update a $2.30 buy limit remains a limit, and an open order is not a position. Record its status without inventing a fill or a saving. A cancellation request would also need confirmation.

### Weak — unsupported submission

The last price is $2.60, so buying two at $2.30 guarantees $60 profit. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

One contract at $2.30 would cost $230; an immediate sale at $2.00 would receive $200, a $30 quote-side loss before fees. Two contracts cannot simply be assumed to fill at an ask displaying size one. The old $2.60 last trade is not a guaranteed exit value. After the update a $2.30 buy limit remains a limit, and an open order is not a position. Record its status without inventing a fill or a saving. A cancellation request would also need confirmation. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The one-contract ask-to-bid spread is $30. I record an unfilled two-contract intention, confirm contract identity and quote time, and avoid using either last or midpoint as execution evidence.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Audit a quote before converting it into an order or an expected result. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The attractive last price'. Write an order-intent note for two contracts. Calculate one contract at the displayed ask and an immediate one-contract bid-side exit. State what cannot be inferred for the second contract.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Change the bid/ask to $0.40/$0.70 with size three and a four-contract intention. What is the per-contract spread and which quantity remains unsupported by the top displayed ask?
- Teach the central distinction of 'The attractive last price' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OIC's options tools](https://www.optionseducation.org/options-quotes-calculators)

## Module 3: Calls, puts, buyers, and sellers

Distinguish moneyness, payoff and profit for buyers and writers.

Stage: Foundations and account decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 2.

### Decision, intuition and learning outcome

## Begin with a decision

An option can finish in the money while its owner loses money. Intrinsic value measures the exercise payoff; profit also includes the premium paid or received and costs. Write separate cash-flow lines before saying that a directional prediction was correct.

**Learning outcome:** Distinguish moneyness, payoff and profit for buyers and writers.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

An option is a contract with two sides. The **buyer** or *holder* pays a premium for a right. The **seller** or *writer* receives that premium when opening a short position and accepts an obligation if assigned. For the standard stock options in this chapter, one contract covers 100 shares. A **call** buyer may buy those shares at the strike; a **put** buyer may sell them at the strike. The call writer may have to sell or deliver shares, and the put writer may have to buy them. These rights and obligations are described in the [SEC options bulletin](https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-63) and [OCC disclosure document](https://www.theocc.com/company-information/documents-and-archives/options-disclosure-document).

To learn option arithmetic, hold time still and imagine the moment of expiration. A call's **intrinsic value** per share is `max(stock price − strike, 0)`. A put's is `max(strike − stock price, 0)`. The `max(..., 0)` part says the holder need not exercise a right that has no favorable intrinsic value. **Profit** then subtracts the premium paid by a buyer or adds the premium received by a writer. Before expiration, an option can have **extrinsic value** on top of intrinsic value because time and uncertain future moves still matter. So an expiration break-even price is neither a forecast nor the price where you must sell before expiration.

Work through a call slowly. ABC is $100 today. You pay $3 per share for one $105 call: `$3 × 100 = $300` leaves your account. If ABC ends at $112, the right to buy at $105 is worth `$7 × 100 = $700`; subtract $300 and your expiration profit is $400 before fees. If ABC ends at $106, the right is worth $100 and the profit is **negative $200**. A correct prediction that the stock would rise was not enough. The expiration break-even is `$105 + $3 = $108`. Below the strike the call's intrinsic value is zero and the premium can be lost in full. A put works in the opposite stock direction: a $95 put costing $2 has a $93 expiration break-even. At a stock price of $88, it is worth `$7 × 100 = $700`, leaving $500 after its $200 premium.

Now reverse the position. If someone **writes an uncovered $105 call** for $3, $300 is the most premium they can keep from that call. At $112 expiration, the intrinsic obligation is $700, producing `+$300 − $700 = −$400` before fees. If the stock rose to $200, the obligation would be far larger; because a stock has no fixed upper price ceiling, the uncovered call has no fixed theoretical loss ceiling. A **short $95 put** sold for $2 can require buying 100 shares for $9,500 even if the shares have collapsed. If the stock went to zero, its expiration loss would be `$9,500 − $200 = $9,300` before fees. Receiving premium therefore does not make a position low risk or turn it into a salary.

You will also hear **in the money** and **out of the money**. A call is in the money when the stock is above its strike; a put is in the money when the stock is below its strike. This says only whether exercise has immediate intrinsic value. It does **not** say whether the original buyer has made a profit. For example, the $105 call at stock $106 is in the money by $1 per share but still loses $2 per share after its $3 purchase premium. Before expiration, a call might trade above its intrinsic value because time remains. If the $105 call is quoted at $7 while the stock is $110, $5 is intrinsic and $2 is extrinsic in that illustrative quote. The actual quote can change for many reasons. At expiration, that extra time value disappears from the simple payoff model.

**Vocabulary to own:** holder, writer, long, short, strike, premium, intrinsic, extrinsic, in the money, out of the money, expiration break-even, obligation. The words *long* and *short* refer to owning and writing the option, not automatically to optimism or pessimism about the stock. A short put, for example, often benefits when a stock stays up, yet it can lose heavily when the stock falls.

**Common mistakes to catch:** calling an in-the-money option profitable without subtracting the premium, assuming a writer's premium is the maximum possible loss, or using an expiration break-even as a price forecast.

### Four teaching weeks

| Week | Use the 2/3/2/2/1-hour pattern |
| --- | --- |
| 9 | Draw and label the rights and obligations of the four basic positions. Work 20 intrinsic-value problems without a calculator, then observe five calls and five puts. |
| 10 | Build call and put expiration payoff tables for six different strikes and premiums. Mark premium paid or received separately from the position's ending value. |
| 11 | Invert each of your long positions to a short position. Explain how the sign changes and where a loss can exceed premium received. Work the five exercises below. |
| 12 | Work the [40 fresh payoff cases](FOUNDATION_ASSESSMENTS.md), each with stated hypothetical fees. Explain aloud why a correct price direction can still be an unprofitable long option. |

### Try it before opening the answers

1. One $60 call costs $4. What is the dollar premium and expiration break-even? What is its profit if the stock ends at $68?
2. One $40 put costs $1.50. What is its expiration break-even and profit if the stock ends at $35?
3. A $50 call sold uncovered for $2 expires with stock at $58. What is its profit/loss? What is the theoretical maximum loss of this uncovered call?
4. A $30 put sold for $1 ends with the stock at zero. What is its expiration profit/loss before fees?
5. ABC rises from $100 to $106. Why did a long $105 call bought for $3 still lose money at expiration?

<details><summary>Module 3 worked answers</summary>

1. Premium `$4 × 100 = $400`; break-even `$60 + $4 = $64`. At $68, intrinsic value is `$8 × 100 = $800`; profit is `$800 − $400 = $400`.
2. Break-even `$40 − $1.50 = $38.50`. At $35, intrinsic value `$5 × 100 = $500`; subtract $150 premium for a `$350` profit.
3. Premium received is $200; intrinsic obligation is `($58 − $50) × 100 = $800`; profit is `−$600`. With no offsetting shares or option, the theoretical loss has no finite upper bound.
4. Premium received is $100. Obligation at $0 is `$30 × 100 = $3,000`; expiration result is `−$2,900`.
5. The call's intrinsic value is only `($106 − $105) × 100 = $100`. It cost $300, leaving a $200 loss. Rising stock price alone was not enough.

</details>

**Pass gate:** At least 90% on the [40 fresh payoff cases](FOUNDATION_ASSESSMENTS.md), with **all** multiplier, obligation, and maximum-loss cases correct after a new-number retest when missed. Save the first attempt before opening [the separate key](FOUNDATION_ANSWER_KEY.md). Stay in observation mode.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Use a $60 put bought for $4 with stock ending at $58. Find payoff, profit and break-even; then explain the corresponding writer obligation.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: Right direction, losing call

**Fictional teaching case.** A fictional analyst predicted a rise from $100 and bought one $100 call for $6. The stock ends at $104. The analyst reports a successful call because the option is in the money.

Standard 100-share European-style classroom call, evaluated at expiration; purchase premium $6 per share; ending stock $104. Ignore financing, dividends and fees for the first pass. Separately consider the writer of the exact same call.

### Initial decision

Correct the report using payoff, premium, profit and break-even. Reconcile the buyer and writer as opposite option cash flows without assuming either holds stock.

### New information — commit your first decision before reading

A $1 entry fee and $1 exit or settlement expense are added to each side for the classroom ledger. Recompute the buyer result and explain why the two participants no longer sum to zero after their separate costs.

### Defense

- What is the strongest reason to disagree with your recommendation in 'Right direction, losing call'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

The buyer receives $400 of expiration payoff after paying $600: a $200 loss before costs. The expiration break-even is $106 before fees. The bare option writer has the opposite $200 result before their own costs, but that example does not establish a safe or suitable short position. The buyer loses $202 after the two stated expenses. Each party pays $2, so their combined net is −$4: costs leave the pair. A winning stock forecast and a profitable option position are distinct claims.

### Weak — unsupported submission

The call is in the money, therefore the buyer made $400. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

The buyer receives $400 of expiration payoff after paying $600: a $200 loss before costs. The expiration break-even is $106 before fees. The bare option writer has the opposite $200 result before their own costs, but that example does not establish a safe or suitable short position. The buyer loses $202 after the two stated expenses. Each party pays $2, so their combined net is −$4: costs leave the pair. A winning stock forecast and a profitable option position are distinct claims. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The call payoff is $400 but the buyer loses $200 before costs and $202 after the supplied expenses. I separate payoff from profit and avoid inferring a recommendation from one realized outcome.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Distinguish moneyness, payoff and profit for buyers and writers. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'Right direction, losing call'. Correct the report using payoff, premium, profit and break-even. Reconcile the buyer and writer as opposite option cash flows without assuming either holds stock.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Use a $60 put bought for $4 with stock ending at $58. Find payoff, profit and break-even; then explain the corresponding writer obligation.
- Teach the central distinction of 'Right direction, losing call' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [SEC options bulletin](https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-63)
- [OCC disclosure document](https://www.theocc.com/company-information/documents-and-archives/options-disclosure-document)

## Module 4: The contract's life and what happens at expiration

Reconcile assignment as an account event with remaining exposure and funding.

Stage: Foundations and account decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 3.

### Decision, intuition and learning outcome

## Begin with a decision

A spread is a collection of contracts. Assignment of its short leg is not an instruction that automatically exercises the long leg at the best possible moment. Reconstruct what the account actually owns or owes, then consider permitted next actions and funding.

**Learning outcome:** Reconcile assignment as an account event with remaining exposure and funding.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

Options have a life cycle: an option is opened, its market value changes, and it can be **closed**, **exercised**, or reach **expiration**. To close a long option, sell the same contract. To close a short option, buy back the same contract. Closing an option position is different from exercising it. When a holder exercises a standard stock call, the contract produces a purchase of shares at the strike; exercising a standard stock put produces a sale of shares at the strike. The writer on the other side can be **assigned** the matching obligation. [OIC explains exercise and assignment](https://www.optionseducation.org/optionsoverview/exercising-options), including the fact that an American-style short option can be assigned before expiration.

Take a $50 stock call covering 100 shares. If its holder exercises, they pay `$50 × 100 = $5,000` and receive 100 shares. If its writer is assigned, that writer must deliver 100 shares and receive $5,000. A writer who already owns the 100 shares can deliver them; a writer without them faces a stock-delivery obligation and broker treatment that must be understood. A put reverses the share movement: a holder who exercises a $50 put delivers 100 shares and receives $5,000; an assigned writer pays $5,000 and receives 100 shares. The premium paid or received earlier is separate from these exercise cash flows. Broker rules and fees can change the precise account display.

Expiring long equity options can enter **exercise-by-exception**, often called automatic exercise: OCC generally processes options that are at least $0.01 in the money, subject to contrary instructions, exceptions, and broker procedures. Do not assume an expiring long option simply pays its intrinsic value in cash. A stock call's exercise can create a share purchase requiring strike cash; a put's exercise can create a short stock position when shares were not owned, subject to broker handling. A stock position created by exercise has separate price and funding risk beyond the option premium. Check the product rules, the broker's instruction cutoff, and any risk-liquidation procedure before expiration. [OIC's exercise FAQ](https://www.optionseducation.org/referencelibrary/faq/options-exercise) explains exercise-by-exception; [its long-put example](https://www.optionseducation.org/strategies/all-strategies/long-put) distinguishes the put from the short stock it can create.

**American-style** means the holder can exercise before expiration; **European-style** means exercise only at expiration. These names describe exercise timing, not where the option trades. Most standard U.S. stock/ETF options are American-style and physically settled. Some index products, such as SPX, SPXW, and XSP, are European-style and cash settled, while SPY ETF options deliver shares. [Cboe's comparison](https://www.cboe.com/tradable_products/sp_500/spx_weekly_options/specifications) shows these specific products and also warns that A.M. versus P.M. settlement can differ by expiration type. For a cash-settled $100-strike index call with settlement value 107 and multiplier 100, the holder receives `($107 − $100) × 100 = $700` cash when exercised; no index shares arrive.

Short American-style options can be assigned **early**. Around a stock's ex-dividend date, an in-the-money short call is a common case to examine, because the long holder's exercise decision can change. Early assignment is possible on other days too. Near expiration, an option that appears out of the money at the regular close can still be exercised after an after-hours stock move. Your broker's exercise instruction cutoff is a deadline for **holders**; a short writer's way to eliminate a position is to buy it back while it is tradable, and the closing order must fill. [FINRA's assignment case study](https://www.finra.org/investors/insights/trading-options-understanding-assignment) shows why after-hours moves and multi-leg positions need special attention.

A **spread** is two or more option legs. Its diagram may show a bounded loss while both legs remain intact, but assignment of the short stock-option leg can create a share position while the long option is still open. The long leg does not automatically erase the newly created share obligation. In a classroom example, you are short one $50 call and long one $55 call. If the $50 call is assigned early, you must deliver 100 shares at $50; the $55 call still exists. Depending on whether you had shares, your account can now show short stock plus a long call. You must know the shares and cash involved, the broker's treatment, and the remaining option's status. This is an operations question before it is a profit-and-loss question.

An **adjusted contract** needs two separate calculations. In [OIC's illustrative 1-for-10 reverse split](https://www.optionseducation.org/news/splits-happen), a contract's quoted-premium multiplier can remain 100 while exercise delivers 10 current shares; the aggregate exercise payment remains tied to the contract's adjusted terms. For a classroom call with a $50 aggregate exercise payment, delivery of 10 shares worth $8 each produces `$80 − $50 = $30` intrinsic value. If its quoted premium were $0.20 with multiplier 100 and total hypothetical fees $2, the net expiration result would be `$30 − $20 − $2 = $8`. Applying a standard 100-current-share payoff would be wrong. Check the exact [OCC adjustment memo](https://infomemo.theocc.com/infomemo/search-memo) for a real series. Rework this in [the mixed safety exam](FOUNDATION_ASSESSMENTS.md).

**Vocabulary to own:** opening, closing, exercise, assignment, American-style, European-style, physical settlement, cash settlement, deliverable, ex-dividend date, expiration, adjusted contract. Corporate actions such as a split or merger can change deliverables; do not assume every option always represents exactly 100 current shares. The [OCC disclosure document](https://www.theocc.com/company-information/documents-and-archives/options-disclosure-document) is required reading before trading options, and you should check the exact contract and broker instructions for each product.

**Common mistakes to catch:** saying a closing sale exercises an option, using a long holder's exercise deadline as a short writer's exit deadline, or assuming a spread's long leg automatically removes shares created by early assignment.

### Four teaching weeks

| Week | Use the 2/3/2/2/1-hour pattern |
| --- | --- |
| 13 | Draw a timeline from opening to closing, exercise, or expiration; work ten call/put exercise cash-flow cases for standard stock options. |
| 14 | Compare Cboe's SPX, SPXW, XSP, and SPY specifications. Record exercise style, settlement type, multiplier, and A.M./P.M. settlement for specific expirations. |
| 15 | Read OIC and FINRA assignment explanations. Rehearse early assignment, ex-dividend, one-leg spread assignment, and after-hours decisions using written position tables. |
| 16 | Create a contract-specification sheet with separate premium multiplier, exercise deliverable, and aggregate exercise payment fields. Pass fresh scenario cases from [the assessment bank](FOUNDATION_ASSESSMENTS.md). Locate a broker's published exercise and risk-liquidation procedures without opening a live position. |

### Try it before opening the answers

1. You exercise one standard $40 stock call. What shares and strike cash move? Ignore premium.
2. You wrote one standard $35 stock put and are assigned. What shares and strike cash move? Ignore premium.
3. A cash-settled index call has strike 2,000, settlement value 2,018, and multiplier 100. What is the cash settlement amount? Are index shares delivered?
4. You are short one standard $50 call and long one $55 call. The short call is assigned early. Does the long call automatically close the stock-delivery obligation? What remains?
5. Does a short American-style call that appears out of the money at the regular close have zero assignment risk that evening? Explain briefly.

<details><summary>Module 4 worked answers</summary>

1. Pay `$40 × 100 = $4,000` and receive 100 shares. This is the strike cash flow, not the full trade profit.
2. Pay `$35 × 100 = $3,500` and receive 100 shares. The premium collected earlier affects total economics but not this assignment cash flow.
3. `(2,018 − 2,000) × 100 = $1,800` cash; no index shares are delivered.
4. No. The short call creates an obligation to deliver 100 shares at $50. The long $55 call remains open unless separately sold or exercised under its terms; the account may have short stock if shares were not owned.
5. No. Exercise instructions and after-hours moves can lead to assignment even when the short appeared out of the money at the regular close. Confirm product rules and broker procedures.

</details>

**Pass gate:** Every share/cash-flow and assignment scenario must be correct. Produce one verified contract-specification sheet. Any confusion about a broker deadline, settlement type, or deliverable blocks simulated order entry until resolved.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Change initial cash to $2,100. Show the same assignment obligation and identify the funding shortfall without inventing a broker liquidation price.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The spread that became shares

**Fictional teaching case.** A fictional account holds one $50/$45 put credit spread. The short $50 put is assigned early while the long $45 put remains open. The learner sees the original five-point payoff width and assumes no cash has moved.

Standard 100-share physically settled puts; same expiry; original net credit $1 per share. Immediately before assignment, cash is $6,100 including the $100 credit, and there are no shares. Do not assign a market value to the surviving long put without a quote.

### Initial decision

Write the ledger immediately after assignment: cash, shares and remaining options. Separate gross funding from theoretical intact-spread expiration loss.

### New information — commit your first decision before reading

The stock is now $47 and the long put shows bid $0.30/ask $0.50. Explain the information needed to compare selling the shares and put with exercising the put; do not assume broker deadlines or automatic action.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The spread that became shares'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Assignment buys 100 shares at $50, using $5,000 and leaving $1,100 cash. The account holds +100 shares and the long $45 put. The original $400 theoretical maximum expiration loss does not describe the $5,000 gross assignment purchase. At a stock value of $47, shares mark to $4,700, but executable stock prices and long-put sale proceeds require actual fills. The put is out of the money, and its quoted time value makes blindly exercising it economically unattractive under the supplied snapshot. Operational instructions still require product and broker confirmation.

### Weak — unsupported submission

The spread risks $400, so assignment moves only $400 of cash. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Assignment buys 100 shares at $50, using $5,000 and leaving $1,100 cash. The account holds +100 shares and the long $45 put. The original $400 theoretical maximum expiration loss does not describe the $5,000 gross assignment purchase. At a stock value of $47, shares mark to $4,700, but executable stock prices and long-put sale proceeds require actual fills. The put is out of the money, and its quoted time value makes blindly exercising it economically unattractive under the supplied snapshot. Operational instructions still require product and broker confirmation. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

Assignment consumes $5,000 and leaves shares plus the long put; I reconcile the gross obligation separately from modeled expiration loss and request actual account/order information before choosing the next action.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Reconcile assignment as an account event with remaining exposure and funding. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The spread that became shares'. Write the ledger immediately after assignment: cash, shares and remaining options. Separate gross funding from theoretical intact-spread expiration loss.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Change initial cash to $2,100. Show the same assignment obligation and identify the funding shortfall without inventing a broker liquidation price.
- Teach the central distinction of 'The spread that became shares' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OIC explains exercise and assignment](https://www.optionseducation.org/optionsoverview/exercising-options)
- [OIC's exercise FAQ](https://www.optionseducation.org/referencelibrary/faq/options-exercise)
- [its long-put example](https://www.optionseducation.org/strategies/all-strategies/long-put)
- [Cboe's comparison](https://www.cboe.com/tradable_products/sp_500/spx_weekly_options/specifications)
- [FINRA's assignment case study](https://www.finra.org/investors/insights/trading-options-understanding-assignment)
- [OIC's illustrative 1-for-10 reverse split](https://www.optionseducation.org/news/splits-happen)
- [OCC adjustment memo](https://infomemo.theocc.com/infomemo/search-memo)
- [OCC disclosure document](https://www.theocc.com/company-information/documents-and-archives/options-disclosure-document)

## Module 5: Building a position from parts

Compare a combined stock-option position with its simpler alternative.

Stage: Foundations and account decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 4.

### Decision, intuition and learning outcome

## Begin with a decision

The premium on a covered call is compensation for a changed payoff. It does not sit on top of an unchanged stock investment. Compare complete portfolios with the same starting resources, including the cash premium, capped upside and remaining downside.

**Learning outcome:** Compare a combined stock-option position with its simpler alternative.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

A named options strategy is just a combination of positions. Do not memorize the name first. Write down each leg, its opening cash flow, and what it will be worth at the evaluation time. Then **add the pieces**. For the first exercises, all options have the same expiration and a standard 100-share deliverable. This lets you calculate an idealized expiration payoff with arithmetic. Real positions can be closed earlier, and exercise, assignment, dividends, spread prices, and fees can change the account path. The [OIC strategy catalog](https://www.optionseducation.org/strategies/all-strategies-en) is useful for checking leg definitions after you build them yourself.

Start with **protective put**: own 100 ABC shares and own one ABC put. Suppose you bought the shares at $100 and one $95 put for $2. Your total initial outlay is `$10,000 + $200 = $10,200`. If ABC is $80 at expiration, the stock has lost `$2,000`, but the put is worth `($95 − $80) × 100 = $1,500`. Total P&L is `−$2,000 + $1,500 − $200 = −$700`. At $0 the put offsets almost all further stock decline; the expiration loss still includes the $5 gap between share purchase and strike plus the $2 premium, or `$7 × 100 = $700`. The put offers a floor at expiration, but the floor costs money and does not make the position profitable by itself.

Now **covered call**: own 100 shares bought at $100 and sell one $105 call for $3. At ABC $120, the stock gained `$2,000`, but the short call owes `($120 − $105) × 100 = $1,500`; add the `$300` premium and the total is `$800`. Above $105, the share gain is effectively capped at `$5 × 100`, plus $300 premium, under the idealized expiration calculation. At ABC $80, the call may expire with no intrinsic value, but the shares lost $2,000; the $300 premium only reduces that loss to $1,700. A covered call is not a hedge against a major stock collapse. If assigned, the writer must deliver shares at the strike. Dividends and early assignment require separate attention.

A **vertical spread** buys one option and sells another of the same type and expiration at a different strike. For a debit call vertical, buy a $100 call for $6 and sell a $105 call for $3. The net debit is `$3 × 100 = $300`. At ABC $110, the long call is worth $1,000 and the short call owes $500, leaving $500 value and `$500 − $300 = $200` profit. Below $100, both options have no expiration intrinsic value and the $300 debit is lost. Above $105, the idealized spread value remains $500, so the net expiration gain is capped at $200. A one-to-one matching vertical limits the *intact position's* payoff but the short American leg can still be assigned before expiration, creating an operational problem as Module 4 explained.

A **straddle** is one call and one put at the same strike and expiration; a **strangle** uses different strikes. For a long $100 straddle with a $4 call and $3 put, total premium is `$7 × 100 = $700`. At ABC $100 expiration, neither leg has intrinsic value, so the full $700 is lost. At $90, the put is worth $1,000 and the position profits `$300`. Its expiration break-even levels are $93 and $107. Do not interpret these as probabilities or promises of a volatility trade. A butterfly and an iron condor also combine legs; you will build their payoff tables by adding each leg rather than memorizing a diagram. Calendar spreads use **different expirations** and need a live-leg valuation, so they wait until the later Greeks and term-structure lesson.

**Vocabulary to own:** protective put, covered call, cash-secured put, vertical debit or credit spread, straddle, strangle, butterfly, iron condor, net debit, net credit, capped payoff. A **cash-secured put** is a short put with cash set aside for the possible share purchase; the cash does not eliminate share-price loss. Every diagram here is an *expiration* calculation under stated assumptions, not a statement about what a broker will allow or how a position will behave on every path.

**Common mistakes to catch:** believing a covered call protects a large stock decline, treating the intact spread's expiration loss as the only possible account obligation, or drawing a calendar as though both of its expirations occurred at the same time.

### Four teaching weeks

| Week | Use the 2/3/2/2/1-hour pattern |
| --- | --- |
| 17 | Build stock-plus-put and stock-plus-call tables at five final stock prices each. Observe how long stock's downside remains in a covered call. |
| 18 | Build four call and four put verticals, writing each leg's cash flow separately. Mark both idealized expiration loss and early-assignment obligation. |
| 19 | Derive straddle and strangle break-even prices, then construct a same-expiration butterfly and iron condor from individual legs using an OIC definition as a check. |
| 20 | Finish a 12-structure payoff notebook. For each structure include entry cash flow, at least five final-price outcomes, downside and upside, and an operational note. |

### Try it before opening the answers

1. Shares bought at $100 are paired with one $95 put bought for $2. What is expiration P&L at stock $80? What is the worst idealized expiration P&L if the stock goes to $0?
2. Shares bought at $100 are paired with one $105 call sold for $3. What is expiration P&L at stock $120 and at stock $80?
3. Buy one $100 call for $6 and sell one $105 call for $3. What is net entry cash flow, maximum idealized expiration loss, and P&L at stock $110?
4. Buy one $100 call for $4 and one $100 put for $3. What is total premium, and what are its two expiration break-even stock prices?
5. A short $95 put is backed by $9,500 cash and sold for $2. Does holding the cash remove downside exposure? What is the expiration loss if ABC reaches $0, before fees?

<details><summary>Module 5 worked answers</summary>

1. At $80, shares lose $2,000; put intrinsic is $1,500; put premium costs $200: total `−$700`. At $0, shares lose $10,000; put intrinsic is $9,500; subtract $200 premium: still `−$700`.
2. At $120: stock `+$2,000`, short call `−$1,500`, premium `+$300`, total `+$800`. At $80: stock `−$2,000`, short call expires without intrinsic value, premium `+$300`, total `−$1,700`.
3. Net debit `($6 − $3) × 100 = $300` paid. Idealized expiration maximum loss is $300; at $110 the spread is worth `$5 × 100 = $500`, giving `$200` profit. Assignment/fees may complicate the account path.
4. Total premium `$7 × 100 = $700`; break-evens `$100 − $7 = $93` and `$100 + $7 = $107`.
5. No. The cash funds the assigned share purchase but the shares can still become nearly worthless. At $0, obligation is `$95 × 100 = $9,500`; after the $200 premium, expiration loss is `$9,300`.

</details>

**Pass gate:** Reproduce all five answers without notes and submit 12 leg-by-leg tables. Correct every maximum-loss, deliverable, and assignment error before continuing.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Change the call strike to $52 and premium to $3. Recompute the cap and compare the altered tradeoff at an ending price of $60.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: Premium income versus participation

**Fictional teaching case.** A fictional investment committee owns 100 shares at $50 and considers selling one $55 call for $2. A member calls the $200 premium a free enhancement. Another wants full participation if the stock reaches $70.

Same expiration for all scenarios; standard 100-share physically settled call; classroom fees, taxes, dividends and cash interest are zero. Compare stock alone with covered stock plus the call premium at ending prices $35, $50 and $70.

### Initial decision

Build terminal wealth and P&L tables. Recommend which objective, if any, the covered call serves, and identify the obligation attached to the premium.

### New information — commit your first decision before reading

The committee now says it must retain every share through the expiry. Revise the recommendation in light of possible assignment; do not silently redefine the mandate.

### Defense

- What is the strongest reason to disagree with your recommendation in 'Premium income versus participation'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Stock alone ends at $3,500/$5,000/$7,000. Covered-call wealth is $3,700/$5,200/$5,700, including the $200 premium, so P&L relative to $5,000 is −$1,300/+$200/+$700. At $70 the call transfers $1,500 of upside above $55; the premium offsets only $200. A covered call may fit a willing-to-sell objective but conflicts with a requirement to retain all shares. The updated mandate can justify rejecting the overlay even though it improves the low-price illustration by $200.

### Weak — unsupported submission

The premium adds $200 in every outcome without changing stock returns. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Stock alone ends at $3,500/$5,000/$7,000. Covered-call wealth is $3,700/$5,200/$5,700, including the $200 premium, so P&L relative to $5,000 is −$1,300/+$200/+$700. At $70 the call transfers $1,500 of upside above $55; the premium offsets only $200. A covered call may fit a willing-to-sell objective but conflicts with a requirement to retain all shares. The updated mandate can justify rejecting the overlay even though it improves the low-price illustration by $200. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The premium cushions $200 but caps wealth at $5,700 under these assumptions. I would only consider the overlay if selling shares at the strike is consistent with the mandate, which the updated requirement rules out.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Compare a combined stock-option position with its simpler alternative. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'Premium income versus participation'. Build terminal wealth and P&L tables. Recommend which objective, if any, the covered call serves, and identify the obligation attached to the premium.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Change the call strike to $52 and premium to $3. Recompute the cap and compare the altered tradeoff at an ending price of $60.
- Teach the central distinction of 'Premium income versus participation' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OIC strategy catalog](https://www.optionseducation.org/strategies/all-strategies-en)

## Module 6: Risk is more than a payoff diagram

Apply a stated loss and funding policy without changing it to fit a trade.

Stage: Foundations and account decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 5.

### Decision, intuition and learning outcome

## Begin with a decision

Position size is constrained by the smallest tradable unit. A policy written in percent becomes actionable only after converting it into dollars and comparing both modeled loss and gross operational obligations. A promising story cannot shrink a contract.

**Learning outcome:** Apply a stated loss and funding policy without changing it to fit a trade.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

This is the safety chapter. A strategy's expiration diagram tells you one possible accounting view at one time. A complete risk view also asks **how the market and account can get from here to there**. The stock can gap overnight. Implied volatility can change while the stock barely moves. A bid/ask spread can widen, so closing costs more than expected. A short stock option can be assigned early. A broker can change buying-power requirements or liquidate a position. Options on the same underlying or related companies can lose together. These are not rare trivia items to memorize after learning strategy names; they are part of each position's definition. Read Chapter X of the [OCC options disclosure document](https://www.theocc.com/company-information/documents-and-archives/options-disclosure-document) and the [SEC margin bulletin](https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-29) alongside this chapter.

Separate **modeled loss** from **funding obligation**. A one-to-one, matching vertical's idealized expiration payoff may have a finite maximum loss. Yet if its short leg is assigned early, a stock position and cash or share obligation may appear while its long leg stays open. The account must survive that interval. A cash-secured put has cash for assignment but can still lose when the purchased stock falls. An uncovered short call has no finite theoretical loss ceiling. Never use a short-option premium collected or a platform's colored payoff picture as the sole measure of money at risk. If one contract's size already breaches your rule, abstaining is a valid outcome; buying a contract with a shorter expiry merely because its price is lower can introduce other risks.

To practice **position sizing** without recommending a real account limit, suppose a classroom policy says a new defined-risk idea may put at most 0.25% of a hypothetical $10,000 practice account at modeled loss. That budget is `$10,000 × 0.0025 = $25`. A one-contract long option costing $1.00 per share costs $100 before fees, so it cannot fit this particular policy. The right arithmetic answer is *no trade*, not half a contract (usually unavailable), borrowed money, or a promise to exit before the loss. These numbers are training rules, not universally safe thresholds; your personal finances and broker terms would matter before any live order. [RISK_AND_OPERATIONS.md](RISK_AND_OPERATIONS.md) contains the sample policy and a pre-order card.

Your **pre-order card** should identify exact contracts and deliverables, bid and ask, estimated fees, entry limit, why the position exists, what would disprove the idea, the exit/expiration plan, events and dividends, how much the entire account could lose in a stress case, and what shares/cash assignment could require. Keep a **decision journal** even when you choose not to trade. This trains you to distinguish a bad outcome from a bad decision and exposes repeated process errors. A paper simulator can help with mechanics but can grant unrealistic fills; [IBKR documents simulation limitations](https://www.ibkrguides.com/orgportal/aboutpapertradingaccount.htm). There is no requirement to produce a profitable paper record during this safety stage.

Broker permissions are not universal. A broker decides which option strategies a specific account may use based on its application and policies. Margin rules can also change. As of October 26, 2026, [FINRA's new intraday margin standards](https://www.finra.org/investors/insights/intraday-margin-requirements) took effect June 4, 2026, but brokers have a transition period through October 20, 2027; check what your own firm applies rather than assuming a single old pattern-day-trader rule. At this stage, the point is to recognize margin as a possible funding and liquidation risk, not to use it. Taxes and records matter too: premiums, opening/closing dates, exercise, assignment, fees, and stock basis should be tracked; treatment varies by contract and situation, so [IRS Publication 550](https://www.irs.gov/publications/p550) is a reference for later review rather than a one-rule shortcut.

**Vocabulary to own:** market risk, gap, volatility risk, liquidity risk, assignment risk, margin, buying power, concentration, stress test, modeled maximum loss, funding requirement, risk policy, decision journal. In this course, a **stress test** asks what happens under a specified adverse scenario; it cannot prove the largest possible future loss. A trader who is prepared to say *I do not know enough to place this order* is using the material correctly.

**Common mistakes to catch:** treating a stop order as guaranteed loss protection, buying a smaller premium solely to meet a risk limit, logging only trades that filled, or assuming margin is a source of free capital.

### Four teaching weeks

| Week | Use the 2/3/2/2/1-hour pattern |
| --- | --- |
| 21 | Read OCC Chapter X's holder, writer, and combination risk sections. For ten earlier payoff exercises, add a gap and a wider bid/ask exit. |
| 22 | Rehearse all eight [risk scenarios](RISK_AND_OPERATIONS.md) with share/cash tables. Add two scenarios from your own imagination and explain which data or broker rule you must check. |
| 23 | Build a hypothetical account risk sheet, pre-order card, and no-trade journal. Compute position size and aggregate exposure for ten examples, including cases too large for the classroom policy. |
| 24 | Take the safety exam below and [the mixed fresh safety exam](FOUNDATION_ASSESSMENTS.md). Correct every error; produce a dated plan for the later paper-trading stage without opening live orders. |

### Try it before opening the answers

1. A hypothetical account has $12,000 and a classroom per-position modeled-loss cap of 0.25%. What is the dollar cap? Does a $0.60 standard long option fit before fees?
2. Why is the quoted premium collected on a short put not the amount of risk in that position?
3. A one-to-one stock-option vertical's short leg is assigned while its long leg remains. Name two exposures that an expiration payoff diagram alone can hide.
4. You plan to buy an option at a $1.00 ask. During a shock the best bid falls to $0.40. What is the one-contract mark-to-exit loss before fees if those quotes were executable at their displayed size? What else could make the real exit differ?
5. A friend says the current U.S. day-trading margin rule always requires $25,000. Is that a safe universal statement in October 2026? What source and account information would you check?
6. Name at least five fields that belong on a pre-order card and explain why one of them matters.

<details><summary>Module 6 worked answers</summary>

1. `$12,000 × 0.0025 = $30`. A $0.60 option costs `$60` before fees for a standard 100-share contract, so it does not fit this illustrative cap. The policy would say no trade.
2. Assignment can require buying 100 shares at the strike, and those shares can fall substantially; loss can exceed the premium received.
3. Possible stock delivery or purchase, cash/margin requirement, and the still-open long option's changing value. The broker may act before a planned exit.
4. Buy for `$1.00 × 100 = $100`; sell at `$0.40 × 100 = $40`; loss `$60` before fees. The bid can change, lack enough size, or disappear; a limit order may fail to fill.
5. No. FINRA's new standards became effective June 4, 2026 with broker phase-in through October 20, 2027. Check [FINRA's explanation](https://www.finra.org/investors/insights/intraday-margin-requirements) and the specific broker's implemented rules and house requirements.
6. Examples: exact contract, multiplier, deliverable, exercise style, settlement type, bid/ask, entry limit, fees, event/dividend calendar, thesis, exit plan, modeled loss, assignment funding, account aggregate exposure. Each matters because an error can change cash at risk or the position created at exercise.

</details>

**Pass gate:** 6/6 plus the [mixed safety exam](FOUNDATION_ASSESSMENTS.md), including all fresh assignment, contract-size, settlement, and margin-funding scenarios correct after remediation. Complete the [risk and operations checklist](RISK_AND_OPERATIONS.md). This gate permits later *simulation*, not live trading; the full course has further research and risk gates.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Use a $30,000 account with a 0.5% aggregate limit and a two-point spread for $0.30 credit. Does a single contract fit before costs?

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The smallest contract fails policy

**Fictional teaching case.** A fictional $20,000 practice portfolio has a written $200 aggregate modeled-loss limit. A student proposes one five-point-wide put credit spread for a $1 credit and argues that one contract must be a small position.

Matching standard 100-share legs and expiry; no existing positions; intact expiration analysis; fees excluded initially. A separate policy requires cash/share obligations to be rehearsed before any simulated entry.

### Initial decision

Compute theoretical maximum expiration loss, compare it with the policy and state an executable classroom decision. Explain the operational questions the payoff width does not answer.

### New information — commit your first decision before reading

The apparent credit increases to $1.50. The learner proposes raising the risk limit to $400 because the opportunity looks better. Reassess both the arithmetic and governance.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The smallest contract fails policy'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

At a $1 credit, modeled expiration loss is ($5−$1)×100 = $400, double the $200 limit. At $1.50 the loss is $350 and still breaches it. Redefining the limit for the attractive example defeats the policy. A valid decision is to reject the simulated position under that mandate and study another exposure or stay in observation. Assignment, liquidity and fees can create additional operational concerns; a $400 payoff calculation is not an account funding plan.

### Weak — unsupported submission

One contract is always small, so the position complies. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

At a $1 credit, modeled expiration loss is ($5−$1)×100 = $400, double the $200 limit. At $1.50 the loss is $350 and still breaches it. Redefining the limit for the attractive example defeats the policy. A valid decision is to reject the simulated position under that mandate and study another exposure or stay in observation. Assignment, liquidity and fees can create additional operational concerns; a $400 payoff calculation is not an account funding plan. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The smallest contract risks $400 initially and $350 after repricing, both beyond $200. I preserve the limit and record a reasoned rejection, with assignment funding assessed separately.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Apply a stated loss and funding policy without changing it to fit a trade. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The smallest contract fails policy'. Compute theoretical maximum expiration loss, compare it with the policy and state an executable classroom decision. Explain the operational questions the payoff width does not answer.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Use a $30,000 account with a 0.5% aggregate limit and a two-point spread for $0.30 credit. Does a single contract fit before costs?
- Teach the central distinction of 'The smallest contract fails policy' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OCC options disclosure document](https://www.theocc.com/company-information/documents-and-archives/options-disclosure-document)
- [SEC margin bulletin](https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-29)
- [IBKR documents simulation limitations](https://www.ibkrguides.com/orgportal/aboutpapertradingaccount.htm)
- [FINRA's new intraday margin standards](https://www.finra.org/investors/insights/intraday-margin-requirements)
- [IRS Publication 550](https://www.irs.gov/publications/p550)

## Module 7: The Greeks are a map of sensitivity

Use local sensitivities with explicit units and explain when approximation fails.

Stage: Price behavior and trade decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 6.

### Decision, intuition and learning outcome

## Begin with a decision

Greeks are a local map, not a promise of tomorrow's executable quote. First predict signs, then attach units and calculate. A useful analyst reports both the estimate and the conditions under which the estimate loses meaning.

**Learning outcome:** Use local sensitivities with explicit units and explain when approximation fails.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

An expiration payoff chart answers, “What is this option worth at expiration if the stock ends at a particular price?” Before expiration, another question matters: “How might the option's *market value* change if one input moves now?” A stock option's quoted premium depends on the stock price, strike, time left, expected volatility, rates, expected dividends, and trading demand. The **Greeks** are model-based measurements of how theoretical option value responds to *small* changes in some of those inputs. They are local approximations, much as a car's current speed estimates where it will be one second later but cannot predict every turn over an hour. [OIC explicitly cautions that Greeks do not guarantee exact price changes](https://www.optionseducation.org/advancedconcepts/understanding-options-greeks).

**Delta** measures the approximate premium change for a $1 move in the underlying, holding the other inputs fixed. A long call with delta +0.55 is modeled to gain about $0.55 *per share* if the stock rises $1, or about $55 for a standard 100-share contract. A long put usually has negative delta: it tends to gain value when the stock falls. The signs reverse when you sell an option because your position is the negative of the long holder's position. Delta is neither a fixed stock-equivalent share count nor a guaranteed probability of expiring in the money. It changes as price, time, and volatility change. [OIC's delta lesson](https://prd-web.optionseducation.org/advancedconcepts/delta) provides examples.

**Gamma** measures the approximate change in delta for a $1 underlying move. If a call has delta +0.55 and gamma +0.04, a $1 rise might move delta toward +0.59; a $1 fall might move it toward +0.51, all else equal. A long, plain call or put usually has positive gamma, and a short option has negative position gamma. This is why an option's response is curved rather than a straight-line copy of stock. A common small-move correction to delta's estimate is `½ × gamma × (stock move)²`. This works only locally, with the model's inputs held sufficiently stable.

**Theta** estimates how theoretical value changes as time passes, often quoted per calendar day; conventions vary by platform, so check the label. A long option commonly has negative theta because it loses time value as expiration approaches, but that statement alone does not tell you its actual next-day P&L. A favorable stock move or volatility change can dominate a day's time decay. **Vega** estimates the change in option value when **implied volatility** (IV) changes by one *percentage point*: from 25% to 26% is one point, not a 1% proportional change. A long plain option usually has positive vega; short options usually have negative position vega. **Rho** estimates the effect of a one-percentage-point interest-rate change; near-term stock options often show less rho sensitivity than stock-price or volatility sensitivity, but it should not be silently assumed to be zero. [OIC describes the five common Greeks and their units](https://prd-web.optionseducation.org/advancedconcepts/volatility-the-greeks).

Here is a **fictional local model example**. A call's theoretical premium is $4.00 per share. Its current Greek readings are delta +0.55, gamma +0.04 per $1, theta −$0.05 per day, and vega +$0.12 per IV percentage point. Suppose the stock rises $1, IV rises from 25% to 26%, and one day passes; assume rates and dividends stay fixed. A rough model change is `0.55 × 1 + ½ × 0.04 × 1² + 0.12 × 1 − 0.05 × 1 = $0.64`. The modeled premium is about $4.64, or about $64 more per standard contract. This is **not** a forecast of the trade's realized profit: the original $4 may have been a midpoint, bid/ask can move, Greeks themselves change, and the stock and IV do not usually move independently.

For every Greek, first ask: “Per share or per contract? Per $1, per day, or per percentage point? Long position or short position? Which model and timestamp?” Misreading one unit can turn a sensible estimate into a 100-fold error.

**Common mistakes:** Treating delta as a guaranteed probability, treating theta as promised daily income, and multiplying a per-share Greek by 100 twice.

### Four-week teaching plan

| Week | Use the 2h lesson / 3h practice / 2h observation / 2h artifact / 1h recall allocation for… |
| --- | --- |
| 25 | Delta. Copy five dated call and put quotes, their delta, stock price, and multiplier; estimate a small $1 stock move and explain the sign. |
| 26 | Gamma. Draw how delta can change after a $1 move; compare a delta-only estimate with a delta-plus-gamma estimate in ten fictional cases. |
| 27 | Theta, vega, and rho. Change one model input at a time with [OIC's delayed calculator](https://www.optionseducation.org/options-quotes-calculators), recording the original and changed assumptions. |
| 28 | Combine the Greeks. Build a one-page “units and assumptions” reference, solve the exercises below, and explain aloud where the approximation fails. |

### Try it before the answers

1. One long call has delta +0.40. With a 100-share multiplier, what is the *delta-only* estimate for a $0.50 stock rise? Why is it not an actual profit figure?
2. A long put has delta −0.35. Estimate its premium change if the stock falls $2, with all other inputs fixed.
3. A long call has delta +0.50 and gamma +0.06. Estimate its new delta after a $1 stock rise. What would you expect after a $1 fall?
4. An option has vega +$0.08 per IV point. IV rises from 20% to 22%. What is the vega-only theoretical change per share and per 100-share contract?
5. Use the fictional $4 call above. Recalculate the local estimate if the stock is unchanged, IV falls one point, and a day passes.

<details><summary>Worked answers — Module 7</summary>

1. `0.40 × $0.50 × 100 = $20` of modeled *option-value* increase. The paid premium, quote spread, fees, and other changed inputs determine actual P&L.
2. `−0.35 × −$2 = +$0.70` per share, or about $70 for one standard contract. This is local; delta can change over a $2 move.
3. After a rise, about `0.50 + 0.06 = 0.56`; after a fall, about `0.50 − 0.06 = 0.44`, under the simplified one-input model.
4. Two IV points × $0.08 = **+$0.16 per share**, or about **+$16 per contract**. Do not multiply by 2% of the premium; vega's stated unit is dollars per IV point.
5. Vega contributes −$0.12 and theta contributes −$0.05; delta and gamma contribute zero. The theoretical change is about **−$0.17 per share**, so the model premium is about **$3.83**. A real quote may differ.

</details>

**Pass gate:** In fresh examples, label every Greek's sign and unit, calculate dollar exposure with the multiplier, and state at least three reasons a Greek estimate can differ from an observed fill or mark.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Reverse the local stock move to −$1 and IV move to −2 points. Calculate the expansion, keeping the gamma contribution positive for a long plain call.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: A Greek estimate is challenged

**Fictional teaching case.** A fictional option has model value $4 and a colleague forecasts its next price by multiplying delta by a large stock move. You are asked to provide a more disciplined small-move estimate and a plan for larger shocks.

One long standard call; delta 0.50, gamma 0.04 per $1 stock move, theta −$0.03 per calendar day, vega $0.10 per IV percentage point. Local case: stock +$1, IV +2 points, one day passes; other inputs fixed.

### Initial decision

Compute the delta/gamma/vega/theta estimate per share and per contract. Identify which inputs need a full repricing or market quote before calling the estimate tradable.

### New information — commit your first decision before reading

The stock instead gaps down $12, IV rises 15 points and the market widens. Explain why simply inserting those changes into the initial expansion is not a reliable price forecast.

### Defense

- What is the strongest reason to disagree with your recommendation in 'A Greek estimate is challenged'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

The local change is 0.50×1 + 0.5×0.04×1² + 0.10×2 − 0.03 = $0.69 per share, or $69 per standard contract. The model value estimate is $4.69. The initial sensitivities change with stock, time and volatility, and the larger joint move is outside the simple local exercise. Reprice with the product-appropriate model, inspect assumptions and compare executable sides. The $69 figure is a modeled value change, not a realized profit after entry cost and execution.

### Weak — unsupported submission

Delta 0.50 means the call has a guaranteed 50% chance of profit. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

The local change is 0.50×1 + 0.5×0.04×1² + 0.10×2 − 0.03 = $0.69 per share, or $69 per standard contract. The model value estimate is $4.69. The initial sensitivities change with stock, time and volatility, and the larger joint move is outside the simple local exercise. Reprice with the product-appropriate model, inspect assumptions and compare executable sides. The $69 figure is a modeled value change, not a realized profit after entry cost and execution. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The local model change is $69 per contract with stated units. I would reprice the gap case and separate model value from bid/ask execution and realized P&L.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Use local sensitivities with explicit units and explain when approximation fails. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'A Greek estimate is challenged'. Compute the delta/gamma/vega/theta estimate per share and per contract. Identify which inputs need a full repricing or market quote before calling the estimate tradable.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Reverse the local stock move to −$1 and IV move to −2 points. Calculate the expansion, keeping the gamma contribution positive for a long plain call.
- Teach the central distinction of 'A Greek estimate is challenged' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OIC explicitly cautions that Greeks do not guarantee exact price changes](https://www.optionseducation.org/advancedconcepts/understanding-options-greeks)
- [OIC's delta lesson](https://prd-web.optionseducation.org/advancedconcepts/delta)
- [OIC describes the five common Greeks and their units](https://prd-web.optionseducation.org/advancedconcepts/volatility-the-greeks)
- [OIC's delayed calculator](https://www.optionseducation.org/options-quotes-calculators)

## Module 8: Volatility measures movement, not direction

Interpret volatility comparisons without equating a high number with a trading edge.

Stage: Price behavior and trade decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 7.

### Decision, intuition and learning outcome

## Begin with a decision

Compare like with like: period, annualization, contract, information set and event calendar. A backward realized measure and a forward-looking price-implied input answer different questions. Their gap is a research starting point, not an automatic instruction.

**Learning outcome:** Interpret volatility comparisons without equating a high number with a trading edge.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

When someone says a stock is “volatile,” they usually mean its price moves around a lot. That does not say whether it will rise or fall. For options, separate two different questions. **Realized** or **historical volatility** summarizes price movement that already occurred over a chosen window. **Implied volatility** is a model input reverse-engineered from today's option price: choose the volatility that makes the model price match the observed option premium. It reflects the option market's pricing of future uncertainty under a model, including risk compensation and demand; it is not a guaranteed forecast of actual future movement. OIC distinguishes historical and implied volatility and notes that past movement need not repeat ([OIC volatility and Greeks](https://www.optionseducation.org/advancedconcepts/volatility-the-greeks), [OIC vega](https://www.optionseducation.org/advancedconcepts/vega)).

To calculate a simple realized-volatility measure, take a sequence of daily percentage returns, compute their standard deviation, and often multiply by `√252` to express a daily value on a trading-year scale. That multiplication is a *convention* under simplifying assumptions, not a claim that each future day is independent or normally distributed. For a tiny illustration, imagine four daily returns of +1%, −1%, +1%, −1%. Their average is 0%; treating these four as the entire example population, their standard deviation is 1%. Annualizing gives `1% × √252 ≈ 15.9%`. A four-day estimate is far too fragile to trade from. A different lookback, return definition, adjustment, or sampling convention changes the result.

Implied volatility must always be compared like with like. A 30-day at-the-money (ATM) option and a six-month far-out-of-the-money (OTM) option do not answer the same question. **Moneyness** describes strike relative to the underlying. A **term structure** shows implied volatility across expirations for similar moneyness. **Skew** shows implied volatility across strikes for the same expiration. An earnings announcement inside one expiration can lift its IV relative to a nearby expiration without proving it is “overpriced.” The event may truly have a wide range of outcomes. An option can lose value after IV falls even if the stock moves in the direction the buyer hoped; the stock move, IV move, time, and bid/ask all matter.

Two common context measures are **IV rank** and **IV percentile**. If 52-week IV minimum is 15%, maximum 35%, and current IV is 25%, rank is `(25 − 15)/(35 − 15) = 50%`. Percentile asks how many days in the lookback had lower IV than today. If 180 of 252 observations were below 25%, percentile is `180/252 ≈ 71.4%`. Rank is 50% while percentile is about 71% because one uses range endpoints and the other uses the whole distribution. OIC gives these definitions ([OIC IV rank and percentile](https://prd-web.optionseducation.org/news/april-webinar-key-takeaways-understanding-volatility-and-options-skew)). Neither says whether IV is above *future* realized volatility or whether buying or selling the option has positive expected return after costs.

Do not use “high IV” as a trade plan. Ask *high compared with what, for which strike and expiration, around which event, and with what loss if the event exceeds the price embedded in options?* Record both the model's story and the uncertainty it leaves out.

**Common mistakes:** Calling IV rank a forecast, comparing different strikes or expirations as if they were identical contracts, and treating past realized volatility as the next period's outcome.

### Four-week teaching plan

| Week | Work for the 10-hour allocation described at the start |
| --- | --- |
| 29 | Learn returns and standard deviation; calculate a small return series by hand and with a calculator. Note the lookback and price-adjustment choices. |
| 30 | Read IV from two dated option chains. Compare the same underlying's similar-moneyness options at two expirations; list events between those dates. |
| 31 | Compare strikes within one expiration and draw a basic skew chart. Label it as observed prices/model IV, not a forecast distribution. |
| 32 | Calculate IV rank and percentile from a sample history. Write a two-page memo on why neither proves an option is “cheap” or “expensive.” |

### Try it before the answers

1. A stock rose 8% last month. Does that fact determine next month's direction or volatility? Explain.
2. In the four-return example above, compute the population-style daily standard deviation and annualized figure using `√252 ≈ 15.87`.
3. IV has a 52-week low of 12%, high of 42%, and current value 27%. Compute IV rank.
4. Current IV is above 150 of 250 historical observations. Compute IV percentile. Is it the same as rank in question 3?
5. A one-month call has IV 35% before earnings and 25% afterward. The stock rises. Must a long call gain value? Name at least two other things to check.

<details><summary>Worked answers — Module 8</summary>

1. No. A past return is an observed outcome. It neither fixes the sign nor the size of future price changes; one month is also a small sample.
2. Mean return is 0. Squared returns average to `(1²+1²+1²+1²)/4 = 1` in percent-squared units, so daily standard deviation is **1%**. Annualized illustration is `1% × 15.87 = 15.87%`. This uses a four-observation population convention, not a statistically reliable estimate.
3. `(27 − 12)/(42 − 12) = 15/30 = **50%**`.
4. `150/250 = **60%**`. It need not equal rank, which uses only the historical minimum and maximum.
5. No. Check how far the stock rose relative to the strike and premium, the IV decline's vega effect, remaining time/theta, and executable bid/ask prices. A favorable direction alone does not guarantee a gain.

</details>

**Pass gate:** Explain realized versus implied volatility without calling either a promise, calculate rank and percentile correctly, and produce a dated strike/expiration comparison with its event calendar and limitations.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** IV is 28%, its recorded range is 18–38%, and 60 of 100 observations are below it. Compute rank and percentile and explain why equality between them is not required.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: High IV, unclear value

**Fictional teaching case.** A fictional research group observes 30-day realized volatility of 20% and a one-month option IV of 35%. A member wants to sell because IV is much higher. An earnings event is scheduled during the option life.

The supplied annualized figures are coherent within their own methods. IV has a 52-week minimum of 15% and maximum of 55%. Of 100 recorded daily IV observations, 80 are below 35%; the percentile convention for this exercise is fraction strictly below.

### Initial decision

Calculate the IV-minus-realized gap, proportional increase, IV rank and supplied percentile. Explain which additional evidence is needed to evaluate an alleged edge.

### New information — commit your first decision before reading

A second contract has 35% IV but a different strike and expiry. Decide whether the first contract’s rank, percentile and event exposure can simply be copied to it.

### Defense

- What is the strongest reason to disagree with your recommendation in 'High IV, unclear value'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

The gap is 15 percentage points; 35/20−1 = 75% proportionally. The given min/max rank is (35−15)/(55−15)=50%, while the supplied percentile is 80%. Those statistics use different summaries. An upcoming event may make past realized movement a poor comparator. A different strike/expiry can have different implied and historical behavior. Research needs matched horizons, a repeatable selection rule, costs, payoff distribution and later evidence, not a label that options are expensive.

### Weak — unsupported submission

IV exceeds realized volatility, so option selling has positive expected profit. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

The gap is 15 percentage points; 35/20−1 = 75% proportionally. The given min/max rank is (35−15)/(55−15)=50%, while the supplied percentile is 80%. Those statistics use different summaries. An upcoming event may make past realized movement a poor comparator. A different strike/expiry can have different implied and historical behavior. Research needs matched horizons, a repeatable selection rule, costs, payoff distribution and later evidence, not a label that options are expensive. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The 15-point gap, 50% rank and 80% percentile describe inputs but do not establish mispricing. I would define a matched, event-aware test and reject any profitability claim based only on the gap.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Interpret volatility comparisons without equating a high number with a trading edge. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'High IV, unclear value'. Calculate the IV-minus-realized gap, proportional increase, IV rank and supplied percentile. Explain which additional evidence is needed to evaluate an alleged edge.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- IV is 28%, its recorded range is 18–38%, and 60 of 100 observations are below it. Compute rank and percentile and explain why equality between them is not required.
- Teach the central distinction of 'High IV, unclear value' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OIC volatility and Greeks](https://www.optionseducation.org/advancedconcepts/volatility-the-greeks)
- [OIC vega](https://www.optionseducation.org/advancedconcepts/vega)
- [OIC IV rank and percentile](https://prd-web.optionseducation.org/news/april-webinar-key-takeaways-understanding-volatility-and-options-skew)

## Module 9: Add exposures across legs; understand calendars

Separate aggregate Greek exposure from expiry-specific obligations.

Stage: Price behavior and trade decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 8.

### Decision, intuition and learning outcome

## Begin with a decision

Adding Greeks is bookkeeping at a timestamp; it does not make legs with different expiries interchangeable. A calendar spread cannot be reduced to a final payoff at the first expiry because a later-dated asset or obligation remains.

**Learning outcome:** Separate aggregate Greek exposure from expiry-specific obligations.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

In a multi-leg position, you own some options and owe on others. The position's *model sensitivities* are the signed sum of its legs' sensitivities. This follows ordinary arithmetic: a long option's value rising helps you, while the same rise hurts if you are short it. The position's actual P&L still depends on executable prices, changing Greeks, exercise, assignment, and what happens if a leg disappears. OIC emphasizes **net** rather than short-leg-only exposure for spreads ([OIC Greek exposure FAQ](https://www.optionseducation.org/news/may-office-hours-faqs)).

Suppose you buy one call whose current per-share delta is +0.55, gamma +0.04, vega +$0.12 per IV point, and theta −$0.04/day. You also sell one different call whose *long-contract* model readings are delta +0.25, gamma +0.02, vega +$0.06, and theta −$0.03. Because the second call is short in your account, multiply its readings by −1. The combined position has delta `0.55 − 0.25 = +0.30`, gamma `0.04 − 0.02 = +0.02`, vega `0.12 − 0.06 = +$0.06/IV point`, and theta `−0.04 − (−0.03) = −$0.01/day`. With 100-share multipliers, its delta-only modeled value change for a $1 stock rise is about +$30. Do not multiply one leg by 100 and forget the other. If quantities or deliverables differ, convert all legs to the same dollar basis before adding them.

Net Greeks help answer *which small change hurts*, but they do not specify the worst loss. Consider a position with almost zero net delta. A large move can make its gamma change delta rapidly; a jump can leap over every small-step approximation. Nor does “positive theta” mean daily profit is due. A short option's time decay may be outweighed by a sudden price or IV move.

Work the [discrete hedge and P&L lab](DYNAMIC_HEDGING_LAB.md) after this net-Greek calculation. It follows a call, stock hedge, cash, rebalance, and executable close through changing prices, then reconciles the difference between a local Greek estimate and the option's observed mark. Keep it as a shadow calculation; the stock short is not part of the beginner live policy.

A **calendar spread** uses options with different expirations, often at the same strike. Consider a fictional long calendar: buy a 60-day $100 call for $5 and sell a 30-day $100 call for $3, both standard contracts. Your initial debit is `$5 − $3 = $2 per share`, or $200. At the front option's expiration, if the stock is exactly $100, the short call might expire without intrinsic value. The back call still has **30 days left** and must be valued then. If its *actual tradable sale price* at that moment were $2.50, closing it would yield `$250 − $200 = $50` before fees. If it were worth $1.50, the same stock price would produce a $50 loss. There is no single expiration payoff formula from stock price alone while the back leg still has time value. Different IV, time, and spreads change its price. Do not read either hypothetical $2.50 or $1.50 as a prediction.

For physically settled American-style calls, the short front call can be assigned early. You may then have a stock delivery obligation while still holding the later call. The later call does **not** automatically exercise to settle the stock position. [FINRA explains one-leg assignment in multi-leg options](https://www.finra.org/investors/insights/trading-options-understanding-assignment). Every scenario worksheet should include stock and cash requirements, not only an idealized line on a payoff chart.

**Common mistakes:** Forgetting the minus sign on short legs, reading near-zero net delta as low risk, and drawing a calendar's value as if both legs expired together.

### Four-week teaching plan

| Week | Work for the 10-hour allocation described at the start |
| --- | --- |
| 33 | Make a signed-position table for ten two-leg examples; calculate position delta, gamma, theta, and vega after quantities and multipliers. |
| 34 | Draw five price/IV/time scenario matrices. Complete the [hedge ledger](DYNAMIC_HEDGING_LAB.md), including its fresh checks and model-residual explanation. |
| 35 | Work through the calendar example at several possible back-leg market prices; record the assumptions required for each result. |
| 36 | Rehearse short-leg assignment and expiration with the [FINRA case study](https://www.finra.org/investors/insights/trading-options-understanding-assignment) and [operational casebook](OPERATIONAL_CASEBOOK.md). Produce the module's scenario worksheet. |

### Try it before the answers

1. You own two calls with per-share delta +0.40 each and are short one put whose *long-option* delta is −0.30. What is net position delta in standard-share equivalents?
2. A long call's vega is +$0.10 per point; a short call's corresponding long-option vega is +$0.07. What is net position vega for one of each? What is the rough model change for a two-point IV fall?
3. In the calendar example, the far call sells for $1.50 when the front call expires worthless. What is the calendar's total P&L before fees?
4. Why is “both calls have a $100 strike, so the calendar is worth zero when the stock is $100” wrong?
5. A short stock call is assigned while a later long call remains. Does the long call automatically deliver the shares? What obligation must you identify immediately?

<details><summary>Worked answers — Module 9</summary>

1. Long calls contribute `2 × +0.40 = +0.80`. The short put contributes `−1 × (−0.30) = +0.30`. Total is **+1.10 share-price delta per share of contract quote**, or roughly **+110 stock-share equivalents** with standard 100-share contracts. This is local, not a fixed hedge.
2. Net vega is `+$0.10 − $0.07 = +$0.03 per share per IV point`, or $3 per standard contract pair per point. A two-point fall suggests `−$0.06 per share`, about **−$6** for the position, with all else fixed.
3. Initial debit is $200; sale proceeds are $150. P&L is **−$50** before fees.
4. The near call may be expiring, but the far call still has time and can retain market value. Its sale price depends on IV and other inputs as well as stock price.
5. No. Identify the resulting short-stock delivery obligation, number of shares, funding/margin, and broker deadline. Contact the broker if procedures are unclear; the long call is a separate position.

</details>

**Pass gate:** Correctly sign and scale each leg, reconcile its net Greeks and the hedge lab's cash/option/stock ledger, price a calendar only with an explicit far-leg value assumption, and solve an assignment scenario without assuming the long leg acts automatically.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Change the long delta to 0.70 and short position delta to −0.55 for two long and one short contracts. Compute the net share-equivalent exposure.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The calendar still has a live leg

**Fictional teaching case.** A fictional portfolio is long one later-dated call and short one near-dated call. The manager calls it a neutral position because it has two offsetting contract names and expects the first expiry to finish the trade.

Both use 100-share multipliers and $100 strikes. Long later call: delta +0.60, vega +$0.18 per IV point. Short near call position: delta −0.45, vega −$0.10 per IV point. At the near expiry assume that short call expires worthless, while the later call remains open.

### Initial decision

Compute net local delta in share equivalents and net vega dollars per point. Describe the account after the near expiry and the information required to value or close it.

### New information — commit your first decision before reading

Instead, the near short call is assigned while the later long call remains unexercised. List the new shares, remaining option and gross stock transaction; do not assume the long leg automatically neutralizes it.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The calendar still has a live leg'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Initially net delta is (0.60−0.45)×100 = +15 shares; net vega is (0.18−0.10)×100 = +$8 per IV point. When the near call expires worthless, the long later call remains and must be separately valued or managed. Under assignment the short call delivers 100 shares for $10,000, creating a short share position if none were held, while the later long call stays open. Borrowing, dividends, exercise economics and broker handling need attention. A shared strike does not synchronize the two expiries.

### Weak — unsupported submission

A calendar has a long and short call, so its delta and obligations are zero. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Initially net delta is (0.60−0.45)×100 = +15 shares; net vega is (0.18−0.10)×100 = +$8 per IV point. When the near call expires worthless, the long later call remains and must be separately valued or managed. Under assignment the short call delivers 100 shares for $10,000, creating a short share position if none were held, while the later long call stays open. Borrowing, dividends, exercise economics and broker handling need attention. A shared strike does not synchronize the two expiries. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The starting exposure is +15 delta shares and +$8 vega per point. I preserve the remaining later option after first expiry and reconcile shares/cash separately if assignment occurs.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Separate aggregate Greek exposure from expiry-specific obligations. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The calendar still has a live leg'. Compute net local delta in share equivalents and net vega dollars per point. Describe the account after the near expiry and the information required to value or close it.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Change the long delta to 0.70 and short position delta to −0.55 for two long and one short contracts. Compute the net share-equivalent exposure.
- Teach the central distinction of 'The calendar still has a live leg' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OIC Greek exposure FAQ](https://www.optionseducation.org/news/may-office-hours-faqs)
- [FINRA explains one-leg assignment in multi-leg options](https://www.finra.org/investors/insights/trading-options-understanding-assignment)

## Module 10: Turn a market opinion into a testable decision

Defend a portfolio action against a mandate, fair alternatives, cash flows and new information.

Stage: Price behavior and trade decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 9.

### Decision, intuition and learning outcome

## Begin with a decision

An investment mandate changes the meaning of a good trade. The committee is choosing a distribution of portfolio outcomes, cash commitments and operational obligations. Begin by writing the objective and constraints in ordinary language. Then place every alternative on the same starting-capital basis, including retained cash, premium, fees and foregone upside. A recommendation can be defensible even when a different choice later earns more.

**Learning outcome:** Defend a portfolio action against a mandate, fair alternatives, cash flows and new information.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

“I think this stock will rise” is a beginning, not a trade plan. An option needs the move to happen by a certain time and often by enough to cover its premium, spread, and fees. You must also decide whether you expect **implied volatility** to rise or fall, whether an event can cause a gap, and what you will do when the facts change. A **thesis** is a written, falsifiable statement of what you expect and why. A **position** is one possible expression of that thesis. A good question is “What is the simplest position, including holding cash, that expresses this view at a risk I can afford?”

Return to the basic expiration equation from the first volume. A $100-strike call bought for $4 needs the stock above $104 at expiration to show a profit before fees. If the stock rises from $100 to $102, the buyer was right about *direction* but still loses $2 per share of premium at expiration. If the stock reaches $105, profit is only `$105 − $100 − $4 = $1 per share`. Buying 100 shares at $100 would gain $5 per share at $105, but it requires much more capital and has different downside, dividends, and time exposure. Neither is automatically “better.” They are different exposures and must be compared at a common cash and risk budget. [The SEC's stock-option examples show how an underlying move can still leave an option buyer with a loss](https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-63).

Expected value asks what the average payoff would be *if your probability estimates were correct*. Consider a made-up one-month scenario with stock starting at $100 and finishing at $110 with 25% probability, $100 with 50%, or $90 with 25%. A long $100 call costing $4 finishes with profits of +$6, −$4, and −$4 per share. Its hypothetical expected profit is `0.25×6 + 0.50×(−4) + 0.25×(−4) = −$1.50 per share`, before costs. Owning stock at $100 has hypothetical outcomes +$10, $0, and −$10 per share, with expected change $0. The call looks exciting in the up state, yet loses on average under these *invented* probabilities. This is a lesson in arithmetic, not a claim that either market price is mispriced. Your probabilities may be wrong; the three states omit many outcomes, early exits, volatility changes, and transaction costs. Expected value alone also hides painful drawdowns and funding needs.

Build every hypothetical **trade ticket** in this order: (1) observable thesis and horizon; (2) exact underlying and option contract terms; (3) entry and exit rules that someone else could follow; (4) what would disprove the thesis; (5) payoff across several outcomes, including a gap; (6) bid/ask and total costs; (7) maximum modeled loss and any exercise/assignment obligations; (8) stock, a different option structure, and **no trade** as alternatives. Write the ticket *before* seeing what happened. If you change a rule after an unfavorable outcome, record that as a new version rather than rewriting history.

“No trade” is a real decision. You may lack data, find the spread too wide, see an event you cannot price, or conclude one contract breaches your risk limit. Do not invent a position just because the course asks for examples. In this module you will write ten hypothetical tickets and ten documented abstentions. Your pass standard is clear reasoning, not profitable paper P&L.

**Common mistakes:** Assuming a correct direction guarantees option profit, treating guessed probabilities as facts, and changing entry or exit rules after seeing the outcome.

### Four-week teaching plan

| Week | Work for the 10-hour allocation described at the start |
| --- | --- |
| 37 | Rewrite five vague market statements as falsifiable theses with dates, observations, and a condition that would reject each. |
| 38 | For five fictional long-option tickets, calculate expiration break-even and a three-state payoff table; compare with stock or cash. |
| 39 | Draft ten hypothetical tickets using the eight-item sequence above. Check product terms and event dates, without submitting orders. |
| 40 | Write ten no-trade decisions. Review tickets from Week 39 and mark which facts were known at decision time versus learned afterward. |

### Try it before the answers

1. A stock is at $100. One $100 call costs $4. At expiration the stock is $102. What is one contract's profit before fees?
2. For the same call, calculate expiration break-even and profit if the stock is $110.
3. Compute the expected per-share payoff for the made-up $110/$100/$90 scenario with probabilities 25%/50%/25%.
4. Give two reasons the stock-versus-call expected values in that scenario are not a complete choice rule.
5. Rewrite “I like this company, so I will buy calls” as a falsifiable *research question*, naming an observation, time horizon, and potential rejection condition.

<details><summary>Worked answers — Module 10</summary>

1. Intrinsic value is $2 per share; after the $4 premium the result is **−$2 per share**, or **−$200** for a standard contract.
2. Break-even is **$104**. At $110, intrinsic value is $10, so net profit is `$10 − $4 = $6 per share`, or **$600 per contract**, before fees.
3. Payoffs are +$6, −$4, −$4. `0.25×6 + 0.50×(−4) + 0.25×(−4) = 1.5 − 2 − 1 = **−$1.50 per share**`.
4. The probabilities are guesses and omit other stock outcomes; positions have different capital, loss limits, liquidity, dividends, and path behavior. Any two of these, explained, suffice.
5. Example: “For stocks meeting prespecified criteria on the day before an earnings release, does a defined one-month call rule earn positive *net* returns over the next month versus holding the underlying at equal cash risk? Reject if the untouched test is negative or the result disappears under adverse fills.” This is a research question, **not** a suggestion to place such a trade; the full protocol comes in the research lab.

</details>

**Pass gate:** Produce ten complete hypothetical tickets and ten justified passes. Every ticket names an expiration, break-even or payoff cases, cost assumption, assignment/settlement rule, invalidation condition, and simpler alternative.

### Investment committee seminar and problem set

## A seminar that develops judgment

**Before the seminar:** Work the scenario table alone and write a 250–400 word initial recommendation. Do not read the debrief first. Your memo should begin with the committee's objective and constraints, not a prediction about the stock. Write down which source of information is absent: probabilities, executable pre-expiry prices, tax treatment, product-specific exercise details, or the committee's willingness to sell shares. Separate information needed to finish this classroom comparison from information needed to implement a real position.

**In discussion:** Give one learner the role of sponsor, one the role of skeptical risk reviewer, and one the role of execution analyst. For solo study, answer those three roles on separate pages before choosing a conclusion. The sponsor asks whether the recommendation serves the mandate. The reviewer searches for a state in which the recommendation disappoints. The execution analyst checks whether contract counts, quote sides, fees and cash agree. Each role must identify one strong part of the memo and one concrete unanswered question. Disagreement is useful when it is attached to a fact, assumption or objective.

**In the defense:** Present the recommendation in ninety seconds without relying on strategy names. A nontechnical committee member should understand what can be lost, what upside is surrendered, which money is immediately available and why the alternative was rejected. Then answer a numerical challenge from the exhibit. If you cannot reconstruct one row of the table from the cash flows, return to the calculation rather than adding more sophisticated terminology.

## Guided example: the $90 terminal state

Alternative A has $90,000 in shares plus $10,000 cash, totaling $100,000. Alternative B has $54,000 in shares plus $50,000 cash, totaling $104,000. C's shares are worth $90,000 and its ten puts pay 1,000×($95−$90)=$5,000; adding $5,990 cash gives $100,990. D has the same shares and put payoff, no call payoff at $90, and $7,980 cash, totaling $102,980. These are total wealth figures. Their changes from the common $110,000 starting point are −$10,000, −$6,000, −$9,010 and −$7,020.

This row reveals an important distinction. Buying the put produces a better severe-loss floor, but selling 400 shares produces more wealth in this moderate-decline example. Protection has a strike, premium and quantity; calling one alternative defensive does not make it best in every decline. A good recommendation specifies which downside problem the committee values and which cost it accepts to address it.

## Guided example: the $130 terminal state

The collar's shares are worth $130,000, but the written calls have $20,000 of expiration payoff against the portfolio. With $7,980 cash, terminal wealth is $117,980. The protective-put portfolio has $130,000 in stock and $5,990 cash, with puts worthless, totaling $135,990. The collar received $2,000 of call premium initially, but gives up $20,000 at this ending stock price. Comparing its premium alone with the cost of puts hides the economic exchange. The correct comparison includes every leg and cash balance.

## Misconception clinic

**“The stock recovered, so the hedge failed.”** A hedge is judged against its stated purpose and possible adverse states. Its realized cost can still have been knowingly accepted. Conversely, calling a position insurance does not excuse incorrect sizing or an objective that was never agreed.

**“The collar is zero cost.”** This collar has a positive net premium and explicit fees. Even a differently quoted zero-premium collar would exchange upside participation for downside terms and would still have operational assumptions. Describe the exact economics rather than repeating the label.

**“The case probabilities are obvious.”** The exhibit supplies scenarios, not frequencies. You may add a clearly declared probability model as a sensitivity exercise, but must show how changing it changes the recommendation. An invented probability is not a source-backed forecast.

**“All choices should use equal option premium.”** The relevant resource comparison here is equal initial portfolio wealth, including unused cash. Matching option premium while ignoring stock and cash could compare very different exposures. Other research questions can use other matching rules, but must justify them.

**“A correct final choice proves the first memo was strong.”** The record must retain what was known initially, the recommendation made, the new information and the revision. Evaluate the original decision against its information set. An attractive realized ending price does not repair a missing funding calculation.

## Independent problem set

1. Rebuild all twenty cells of the initial table without copying formulas from the debrief. Label each premium and fee line. Verify the underlying-zero boundary for C and D.
2. Explain the two states where B beats C and why that does not establish universal dominance. Identify another state where the opposite ranking holds.
3. Change the immediate cash requirement from $8,000 to $6,000 while retaining the new quote sides. Which specified alternatives are feasible? Explain why feasibility alone still cannot rank all portfolios.
4. Create a new explicitly specified alternative using a different share sale and hedge quantity. Track residual shares, every option count and cash. Compare it on the common starting-wealth basis.
5. Draft two no-action decisions: one because a hard mandate cannot be met, and one because essential evidence is missing. Explain what would reopen each decision.

## Feedback and revision standard

The reviewer marks errors in separate categories: objective interpretation, option units, complete cash flows, scenario logic, uncertainty, implementation and communication. A numerical error is corrected with a new row and a changed-number problem. An unsupported recommendation is corrected by naming the missing assumption and revising the memo. A revision must state what changed and why; silently replacing the first memo is not remediation evidence.

At a later session, use the transfer case without the original table. Record whether the work was independent, assisted or reproduced after feedback. A later correct explanation demonstrates something different from recognizing a solution immediately after seeing it. Neither result alone establishes trading profitability or an accredited qualification.


### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Fresh transfer: start with 500 shares at $80 plus $6,000 cash. A $75 put asks $3, a $90 call bids $1, and entry fees remain $1 per contract per leg. Compare holding, selling 200 shares, buying five puts and a five-contract collar at ending stock $50/$80/$110. Then impose a $5,000 immediate-cash requirement. Submit before checking another learner’s work.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The Meridian Investment Committee

**Fictional teaching case.** You are the analyst for the fictional Meridian household investment committee. It owns 1,000 shares of an imaginary company at $100, plus $10,000 cash: $110,000 total current wealth. The shares are a concentrated holding. The committee has a three-month horizon and wants to reduce downside while preserving some participation in a rise. It has not authorized borrowing or naked short options. Your job is to recommend an action using only the supplied decision-time packet, explain the tradeoffs and specify what would change your mind. All quotes, outcomes and mandates in this case are invented for teaching; no real issuer or historical episode is represented.

### Decision-time packet

All options below have the same stated three-month expiration, standard 100-share deliverable and $100 premium multiplier. For the arithmetic, use European-style expiration settlement, sufficient size for the stated alternatives, zero cash interest, zero dividends, no taxes and the explicit conservative quote sides. These simplify the first comparison; they are not assumptions about every real equity option. Fees are $1 per option contract per entry leg; there are no additional modeled settlement charges. Stock sales use the supplied $100 price with zero modeled stock commission. No midpoint fill is promised.

| Instrument | Bid | Ask | Classroom contract terms |
|---|---:|---:|---|
| $95 put | $3.60 | $4.00 | Same three-month expiry |
| $110 call | $2.00 | $2.40 | Same three-month expiry |

Compare four fully specified portfolios using the same initial $110,000 resources:

**A — Hold:** keep 1,000 shares and $10,000 cash.

**B — Reduce concentration:** sell 400 shares for $40,000; keep 600 shares and $50,000 cash.

**C — Protective puts:** retain 1,000 shares; buy ten $95 puts at the $4 ask. Premium is $4,000 and entry fees are $10. Remaining cash is $5,990.

**D — Collar:** retain 1,000 shares; buy ten $95 puts at $4 and sell ten covered $110 calls at the $2 bid. Net premium is $2,000; twenty entry contracts cost $20. Remaining cash is $7,980.

The committee asks for ending stock prices of $70, $90, $100, $110 and $130. These are stress illustrations, not probabilities or an exhaustive future distribution. Compare terminal wealth and change from $110,000. Also include an underlying-zero boundary for C and D. The covered calls are backed by the existing shares throughout this stipulated portfolio; removing shares requires reassessing that coverage.

### Initial decision

Submit an initial recommendation before reading the update or debrief. State the objective, choose among A–D or justify deferring action, show your scenario table and cash ledger, and name an observable condition that would trigger review. Explain the strongest argument against your recommendation. You may not assign probabilities to the scenarios without clearly labeling a separate assumed model.

### New information — commit your first decision before reading

### New information — preserve your initial memo

The committee now requires **$8,000 of accessible cash immediately after implementation** for a known bill. It clarifies that the bill is separate from the three-month portfolio goal. The put market widens to $3.40/$4.50 and the call market to $1.50/$2.70. No order has filled. Keep the same $1 per entry contract fee. The committee also asks whether the shares could be required for sale before expiry, and requests a later operational rehearsal using American-style physical settlement rather than the European classroom comparison.

Recompute cash feasibility at the new quote sides before discussing terminal performance. Do not label an old quote a fill. Revise the recommendation, distinguish mandate failure from an unattractive expected return, and list what product/broker facts are needed for the separate American-style rehearsal.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The Meridian Investment Committee'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

### Initial comparison — checked cash-flow answer

For stock price S at expiration, A has wealth 1,000S+10,000 and B has wealth 600S+50,000. C has 1,000S+1,000 max(95−S,0)+5,990. D adds the same put payoff and subtracts 1,000 max(S−110,0), with cash 7,980.

| Ending stock | A hold | B reduce | C put | D collar |
|---|---:|---:|---:|---:|
| $70 | $80,000 | $92,000 | $100,990 | $102,980 |
| $90 | $100,000 | $104,000 | $100,990 | $102,980 |
| $100 | $110,000 | $110,000 | $105,990 | $107,980 |
| $110 | $120,000 | $116,000 | $115,990 | $117,980 |
| $130 | $140,000 | $128,000 | $135,990 | $117,980 |

Subtract $110,000 from each entry to obtain change in wealth. C's idealized floor is $100,990 even at S=0; D's is $102,980 and its cap is $117,980. B has a different severe boundary: at S=0 its wealth is $50,000, because reducing shares cushions rather than fully insures the remaining shares. An expensive hedge can reduce losses in the severe scenarios while lowering wealth in a flat or rising state. The collar finances part of protection by surrendering upside above $110. No alternative dominates every stated state and objective.

### Response to the update

At the new sides, ten puts cost $4,500 plus $10 fees, leaving C with $5,490. D pays $4,500, receives $1,500 and pays $20 fees, leaving $6,980. Both fail the newly stated immediate $8,000 cash constraint as specified. A and B retain $10,000 and $50,000 respectively and satisfy that particular condition. This is a feasibility conclusion; it does not establish their optimality for every risk objective. If the $8,000 bill is then paid, subtract it from each feasible portfolio's cash and future total wealth; do not compare a post-bill alternative with another portfolio that still includes bill money.

A defensible revision is B if its remaining downside fits the clarified mandate; retaining A while requesting a revised mandate or designing a newly specified alternative can also be defended. A smaller hedge or different share sale is a new portfolio and needs a new calculation. Do not quietly substitute fewer contracts while keeping the original table. Under the separate American-style extension, covered-call assignment can transfer shares before planned expiry; that affects a mandate to retain them. Funding, exercise choice, ex-dividend information and broker procedures require exact specifications. A European terminal floor does not replace those operational checks.

### Teaching debrief

Grade what the analyst knew at each stage. A learner who initially favors the collar for a protection-focused mandate can reason well, and then correctly change course when the cash constraint appears. Another can prefer a simple reduction because it avoids option costs and preserves flexibility. Neither earns full credit by naming a structure alone. Full credit requires a coherent objective, fair resource comparison, correct cash and scenario accounting, a source of uncertainty, an operational limitation and a clear revision. Do not select a winner after revealing an ending stock price and call that foresight.

### Weak — unsupported submission

Sell the call because premium is income, and the collar is free protection with unlimited upside. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

I compare all four alternatives from the same $110,000 starting wealth, include premium and fees, and identify that protection and upside participation trade off. I compute initial cash and recognize that the new cash requirement changes feasibility. My memo still needs a stronger justification of the chosen downside objective and a separate implementation rehearsal. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

I compare complete portfolios from $110,000, identify the put floor and collar cap, and initially favor a structure only under an explicit downside objective. Once the $8,000 immediate-cash constraint and new quotes arrive, the specified put and collar alternatives fail feasibility; I revise rather than reuse stale quotes or silently resize the hedge.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Defend a portfolio action against a mandate, fair alternatives, cash flows and new information. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The Meridian Investment Committee'. Submit an initial recommendation before reading the update or debrief. State the objective, choose among A–D or justify deferring action, show your scenario table and cash ledger, and name an observable condition that would trigger review. Explain the strongest argument against your recommendation. You may not assign probabilities to the scenarios without clearly labeling a separate assumed model.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Fresh transfer: start with 500 shares at $80 plus $6,000 cash. A $75 put asks $3, a $90 call bids $1, and entry fees remain $1 per contract per leg. Compare holding, selling 200 shares, buying five puts and a five-contract collar at ending stock $50/$80/$110. Then impose a $5,000 immediate-cash requirement. Submit before checking another learner’s work.
- Teach the central distinction of 'The Meridian Investment Committee' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [The SEC's stock-option examples show how an underlying move can still leave an option buyer with a loss](https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-63)

## Module 11: A good idea can be lost in execution

Use confirmed fills and order status to reconcile actual exposure.

Stage: Price behavior and trade decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 10.

### Decision, intuition and learning outcome

## Begin with a decision

Execution is a sequence of messages and events. A submitted order is an intention, a fill is a transaction, and a cancellation request is a request until confirmed. Quantity reconciliation prevents a second order from accidentally doubling exposure.

**Learning outcome:** Use confirmed fills and order status to reconcile actual exposure.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

The **bid** is the displayed price at which someone is currently willing to buy; the **ask** or **offer** is the displayed price at which someone is currently willing to sell. The **bid/ask spread** is ask minus bid. The midpoint is halfway between them, but a midpoint is just arithmetic. A displayed option chain often shows a last trade too; that trade may have happened earlier under different stock and volatility conditions. [Cboe describes liquidity through the ease of entry and exit and the width of bid/ask quotes](https://optionsfacts.cboe.com/). OIC's [FAQ](https://www.optionseducation.org/referencelibrary/faq/basics) notes that an option's last trade may be hours or even days old. A dated quote with bid, ask, and size is usually a better starting observation than “last.”

The **national best bid and offer** (NBBO) gathers the best displayed bid and ask from eligible U.S. option markets at that moment. It is not a promise that you can trade any quantity at those prices forever. Quote sizes, prices, exchange participation, and the underlying move. For a buy, a **limit order** sets the highest price you are willing to pay; for a sell, it sets the lowest price you will accept. The limit controls your worst stated *price if executed*, but the order may not fill. A marketable order can fill quickly yet pay the spread and possibly more if displayed size is small or quotes move. Learn the precise order behavior of the platform before relying on it.

Suppose a standard option shows `$2.10 bid / $2.30 ask`, with enough displayed size for the illustration. Buying one at $2.30 costs $230. Immediately selling at $2.10 brings back $210: **−$20 before any underlying move or fees**. For ten contracts, the same simple quote-side round trip is −$200 before fees, assuming the quote sizes actually support ten contracts. If fictional fees are $0.65 per contract on each side, ten round trips add `$0.65 × 10 × 2 = $13`, for a total −$213. A limit buy at $2.20 might fill at or below $2.20, but it might never fill. A backtest that credits every hypothetical midpoint order as a trade creates a winner that may not have existed in the market.

Execution becomes harder with a **multi-leg order**. A two-leg spread can be sent as a package at a net limit where the broker supports it, or individual legs might be executed separately. If you execute one leg and the other does not fill, you have **leg risk**: an unintended position, perhaps with much larger exposure. Even an intact package can be hard to close if one leg's market becomes thin. A theoretical payoff chart assumes a position exists at the specified prices; it does not guarantee a way in or out. Read [FINRA's assignment discussion](https://www.finra.org/investors/insights/trading-options-understanding-assignment) for why closing the entire short exposure matters.

Execution study means timestamping what you *could see* and what a proposed order might plausibly have done. Record underlying price, exact option symbols, bid, ask, size if available, quote age, fees, order limit, and whether the order actually filled. A 20-minute-delayed educational quote from [OIC's tools](https://www.optionseducation.org/options-quotes-calculators) is fine for learning mechanics but not evidence of a live executable price. For research, model nonfills and adverse prices and preserve rejected opportunities; otherwise you select only situations that looked good in hindsight.

The [synthetic execution replay](EXECUTION_PRACTICE.md) adds broker order reports to changing quotes. Reconcile its confirmed fills, nonfills, partial fills, pending cancellation, and platform-outage drill before interpreting paper-trading results. For a spread whose leg status is uncertain, use the [account casebook](OPERATIONAL_CASEBOOK.md) to find the actual exposure.

**Common mistakes:** Assuming midpoint execution, using the last trade as a current quote, and counting only hypothetical limit orders that would have filled.

### Four-week teaching plan

| Week | Work for the 10-hour allocation described at the start |
| --- | --- |
| 41 | Collect ten dated single-option quote observations; compute spread in dollars and as a percentage of midpoint, and note stale last trades. |
| 42 | Draft ten hypothetical buy and sell limits; for each, state the permitted fill price and what happens if it never fills. |
| 43 | Build five hypothetical two-leg orders and calculate net debit or credit from quote sides and from midpoint. Identify the gap between them. |
| 44 | Complete 30 total quote observations and the [execution replay](EXECUTION_PRACTICE.md). Summarize typical, widest, and event-day spreads and write rules for when an order is rejected. |

### Try it before the answers

1. A bid is $1.40 and ask $1.70. What is the spread and midpoint per share and per standard contract?
2. You buy five contracts at the $1.70 ask and immediately sell at the $1.40 bid. What is the quote-side result before fees?
3. A buy limit is $1.55 while the best displayed ask is $1.70. Can you assume the order fills immediately? What price ceiling applies *if* it fills?
4. Why might a last trade of $1.50 be a poor current entry estimate when the displayed market is $1.40/$1.70?
5. One leg of a planned two-leg spread fills and the other does not. What are the first three things to recheck before any further action?

<details><summary>Worked answers — Module 11</summary>

1. Spread is `$1.70 − $1.40 = **$0.30/share**`, or $30 per contract. Midpoint is `($1.40 + $1.70)/2 = **$1.55/share**`, or $155 per contract. The midpoint is not an offered fill.
2. `($1.40 − $1.70) × 100 × 5 = **−$150**` before fees.
3. No. $1.55 is below the displayed ask, so nonfill is possible. If the buy limit fills under ordinary limit-order operation, it should not execute above **$1.55**; verify platform and order status rather than assuming an outcome.
4. The last trade may have occurred when the stock, IV, and quotes were different; it says what traded earlier, not what is now offered to you.
5. Confirm the *actual* filled position and size, its immediate directional/Greek and assignment exposure, and the current bid/ask plus available funds or buying power. Then follow the written contingency process; this exercise is not a live order instruction.

</details>

**Pass gate:** Reconcile 30 quote records and all seven execution-replay answers, correctly calculate per-contract cost, identify stale last prices and nonfills, and explain the added risk of a partial multi-leg fill. A pending cancellation or missing acknowledgement never counts as a confirmed zero position.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** A four-contract order has two fills, one further late fill and one confirmed cancellation. What is the maximum replacement quantity for an unchanged four-contract target?

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The cancellation race

**Fictional teaching case.** A fictional trader submits a limit buy for three contracts at $2.20. One fills. The trader requests cancellation of the remaining two, sees a quote move, and immediately submits a replacement for three.

All standard 100-share contracts. Confirmed report 1: one contract bought at $2.20. Cancellation request acknowledged as pending. Confirmed report 2 later shows another contract bought at $2.20 before cancellation became effective. The final remaining one is cancelled. Ignore fees initially.

### Initial decision

Reconstruct filled quantity, cash paid and cancelled quantity. Explain what replacement quantity could have been justified only after resolving the first order.

### New information — commit your first decision before reading

The replacement three-contract order also fills entirely at $2.30. Compute total exposure and cash paid; propose an operational response without assuming an exit price.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The cancellation race'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

The original order bought two contracts for $440 and cancelled one. A target of three would leave only one contract still needed after that final reconciliation. Replacing all three creates five total contracts after the new fills, costing $440 + $690 = $1,130 before fees. A response begins by verifying the account, cancelling any other live orders and reviewing the excess exposure against policy. A hypothetical corrective sale needs its own quote, fill and fees. The error is order-state control, not simply a poor entry price.

### Weak — unsupported submission

The cancellation request means the old order is gone; replace all three. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

The original order bought two contracts for $440 and cancelled one. A target of three would leave only one contract still needed after that final reconciliation. Replacing all three creates five total contracts after the new fills, costing $440 + $690 = $1,130 before fees. A response begins by verifying the account, cancelling any other live orders and reviewing the excess exposure against policy. A hypothetical corrective sale needs its own quote, fill and fees. The error is order-state control, not simply a poor entry price. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

I reconcile two original fills and one confirmed cancellation before replacing the remaining target quantity. The update creates five contracts and $1,130 paid; I document and manage the excess using actual order information.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Use confirmed fills and order status to reconcile actual exposure. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The cancellation race'. Reconstruct filled quantity, cash paid and cancelled quantity. Explain what replacement quantity could have been justified only after resolving the first order.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- A four-contract order has two fills, one further late fill and one confirmed cancellation. What is the maximum replacement quantity for an unchanged four-contract target?
- Teach the central distinction of 'The cancellation race' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [Cboe describes liquidity through the ease of entry and exit and the width of bid/ask quotes](https://optionsfacts.cboe.com/)
- [FAQ](https://www.optionseducation.org/referencelibrary/faq/basics)
- [FINRA's assignment discussion](https://www.finra.org/investors/insights/trading-options-understanding-assignment)
- [OIC's tools](https://www.optionseducation.org/options-quotes-calculators)

## Module 12: Paper trading is a laboratory, not a track record

Audit a simulation record including rejected, unfilled and empty decisions.

Stage: Price behavior and trade decisions. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 11.

### Decision, intuition and learning outcome

## Begin with a decision

A simulation tests a specified process under its fill assumptions. Its equity curve becomes interpretable only after you preserve the full opportunity set, costs and operational exceptions. Missing nonfills can change both the apparent return and the strategy being studied.

**Learning outcome:** Audit a simulation record including rejected, unfilled and empty decisions.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

A **paper trade** is a simulated order with no real financial settlement. It lets you rehearse contract selection, order entry, operational checks, and recordkeeping. It does **not** prove that a strategy will fill or earn money with live capital. [IBKR's own paper-account guide](https://www.ibkrguides.com/orgportal/aboutpapertradingaccount.htm) says fills are simulated from the top of the book, deep-book access is absent, combo trading is limited, and some order types differ from production behavior. If you do not have a paper platform, a dated **shadow ledger** of hypothetical decisions can still teach the process; label every fill assumption honestly.

The most important paper-trading habit happens *before* the hypothetical order: write down what you knew at that time. Save the date and time zone, underlying and exact option series, current bid/ask and size, thesis, event calendar, intended limit, maximum modeled loss, and the condition for exit. Then record whether the order filled, partly filled, or did not fill. Do not backfill an order because the market later moved favorably. Include **no-trade decisions**, especially when the option spread is wide, the contract is unclear, or the rule does not produce a signal. Without rejected and unfilled opportunities, your journal will flatter your decision process.

Separate **gross P&L** from **net P&L**. Gross is sale proceeds minus purchase cost for a long option, or initial credit minus repurchase cost for a short option, before fees. Net subtracts broker/exchange fees, financing when relevant, and any other actual costs. An example using fictional fills: Paper trade A buys one call at $2.30 and later sells at $2.60, producing `($2.60 − $2.30) × 100 = +$30` gross. If fees total $2, net is **+$28**. Paper trade B buys one put at $1.80 and sells at $1.20, producing `($1.20 − $1.80) × 100 = −$60` gross and **−$62** after the same $2 fees. Across both, net P&L is `28 − 62 = −$34`, even though **win rate** is one winner out of two, or 50%. Two observations say nearly nothing about expected performance; they do show how to keep an honest ledger.

Also measure **drawdown**, the decline from the highest account value or cumulative P&L reached so far. A 50% win rate, a high premium collected, or a pretty ending balance can hide severe interim losses. Track rule violations separately from P&L. A winning trade that broke the pretrade risk limit is a process failure. A losing paper trade that followed the plan may be valuable evidence. The review question is not “Did I win?” but “Was the decision recorded beforehand, were the fills plausible, and what would I do differently *before the next comparable decision*?”

For these four weeks, your goal is a complete decision log, not a quota of trades. At the end, write a one-page audit: number of eligible signals, orders submitted, nonfills, no-trade decisions, total gross and net hypothetical P&L, fees, largest modeled loss, largest drawdown, and rule violations. Put “unknown” beside any measure a simulator cannot provide credibly. This first month starts the **eight-week minimum** in [Risk Gate 2](RISK_AND_OPERATIONS.md); keep the same record during at least weeks 49–52 of the probability module, or longer until all gate evidence is complete. The later forward-validation research record is a separate, frozen-protocol study.

**Common mistakes:** Deleting no-trade days, reporting gross P&L as if it were take-home gain, and declaring an edge from a short paper record.

### Four-week teaching plan

| Week | Work for the 10-hour allocation described at the start |
| --- | --- |
| 45 | Set up a paper account or shadow ledger. Rehearse every pretrade field with two fictional examples before logging any market observations. |
| 46 | Log every eligible observation, including no trades and nonfills. Reconcile hypothetical entry prices against timestamped bid/ask. |
| 47 | Continue the log. Review one decision each day for an unrecorded assumption, event, exercise/assignment path, or unrealistic fill. |
| 48 | Reconcile the ledger and write the one-page audit. Correct the process, freeze the next version of the rules, and keep all original entries. |

### Try it before the answers

1. Recalculate gross and net P&L for paper trade A above if the total fees are $2.
2. Recalculate paper trade B and the two-trade total. What is the win rate? Does it tell you the strategy's edge?
3. A simulated buy order fills at a midpoint that no real order reached. What do you record?
4. Your rules signaled a trade, but the observed spread exceeded your written maximum. Do you delete this opportunity from the journal because you did not trade it?
5. You break a position-size rule and make a paper profit. Did you pass the process check? Explain.

<details><summary>Worked answers — Module 12</summary>

1. `($2.60 − $2.30) × 100 = +$30` gross; `30 − 2 = **+$28 net**`.
2. B is `($1.20 − $1.80) × 100 = −$60` gross and **−$62 net**. Combined net is **−$34**. One of two trades won, so win rate is **50%**. With two trades and no fair benchmark, it says almost nothing about a persistent edge.
3. Preserve the simulator's reported fill *and* a separate conservative quote-side or nonfill scenario. Mark the discrepancy; do not silently treat the midpoint as live execution evidence.
4. No. Record the signal and the **no-trade decision**, with the spread and the rejection rule. Removing it would hide the strategy's actual opportunity set.
5. No. The profit does not erase a rule violation. Mark the trade as a process failure and explain how the size check will work next time.

</details>

**Pass gate:** Four complete weeks of time-stamped decisions, including passes and nonfills; a reconciled gross/net ledger; a drawdown and rule-violation report; and a clear statement of which paper outcomes cannot be treated as live evidence. Continue the record through at least four further weeks under [Risk Gate 2](RISK_AND_OPERATIONS.md), including its final four weeks of full policy adherence, before treating the paper gate as passed.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** A paper record contains twelve eligible setups, eight fills and four nonfills. Design a summary that retains all twelve without forcing hypothetical fills on the four.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The beautiful paper equity curve

**Fictional teaching case.** A fictional student reports $900 paper profit from six winning simulated trades. The original rule generated ten eligible setups, but the submitted journal includes only the six that received favorable midpoint fills.

Four omitted setups have unknown outcomes and no confirmed fills. For the six reported trades, gross midpoint P&L totals $900. An adverse-fill sensitivity adds $180 execution cost and $12 fees. The sample covers two weeks and one market environment.

### Initial decision

Reconcile the reported subset, identify missing evidence and write an appropriate conclusion about what the simulation demonstrates.

### New information — commit your first decision before reading

The student wants to delete a rejected setup after finding it would have lost money. Explain how the journal should preserve this information without pretending a rejected order was a trade.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The beautiful paper equity curve'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

The reported six-trade sensitivity is $900−$180−$12 = $708. That remains a result for a selected subset, not an audited ten-setup rule. Missing or rejected setups must retain eligibility, known timestamps and order states; unknown outcomes remain unknown. A rejected opportunity is not assigned a fictional fill, but removing it obscures how the rule behaved. The two-week record cannot resolve regime dependence or establish executable future performance. A strong submission can conclude that the process needs repair before interpreting the curve.

### Weak — unsupported submission

Six winners prove the strategy works; delete opportunities that were not traded. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

The reported six-trade sensitivity is $900−$180−$12 = $708. That remains a result for a selected subset, not an audited ten-setup rule. Missing or rejected setups must retain eligibility, known timestamps and order states; unknown outcomes remain unknown. A rejected opportunity is not assigned a fictional fill, but removing it obscures how the rule behaved. The two-week record cannot resolve regime dependence or establish executable future performance. A strong submission can conclude that the process needs repair before interpreting the curve. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The stated cost sensitivity leaves $708 on six selected fills. I restore all ten eligible decisions, label unknowns and nonfills, preserve rejected setups, and restrict the conclusion to simulation-process evidence.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Audit a simulation record including rejected, unfilled and empty decisions. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The beautiful paper equity curve'. Reconcile the reported subset, identify missing evidence and write an appropriate conclusion about what the simulation demonstrates.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- A paper record contains twelve eligible setups, eight fills and four nonfills. Design a summary that retains all twelve without forcing hypothetical fills on the four.
- Teach the central distinction of 'The beautiful paper equity curve' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [IBKR's own paper-account guide](https://www.ibkrguides.com/orgportal/aboutpapertradingaccount.htm)

## Module 13: Probability is about possible outcomes

Use expected value, base rates and dependence to challenge an attractive claim.

Stage: Quantitative reasoning and models. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 12.

### Decision, intuition and learning outcome

## Begin with a decision

Expected value weights every outcome by its assumed probability. A high hit rate can coexist with a negative expectation and a severe funding problem. Before computing, ask where the probabilities came from and whether the outcome list omits a larger loss.

**Learning outcome:** Use expected value, base rates and dependence to challenge an attractive claim.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

Imagine that you will toss a coin. Before the toss, the possible outcomes are heads and tails. That list is a **sample space**. An **event** is a set of outcomes, such as “heads.” A probability is a number from zero to one attached to an event. In this finite coin model, impossible events have probability zero and the whole sample space has probability one. Continuous models need more care: an exact value can have probability zero without being impossible, as with one exact point in a continuous price distribution. Probability one is then called *almost sure*, rather than a guarantee about every conceivable outcome. When you say an event has probability 0.20, you mean 20 chances in 100 *under the stated model*. You have not proved that nature follows the model.

Trading introduces more outcomes than a coin toss. A long option could lose its full premium, return some of it, or make more. A short position can have a large loss even when small gains happen often. This is why **win rate** is a poor standalone measure. To compare outcomes, use **expected value**, the probability-weighted average: multiply each possible payoff by its assumed probability and add the results. All payoffs in this chapter are after the assumed costs unless stated otherwise.

Suppose a hypothetical trade wins $1 with probability 0.90 and loses $12 with probability 0.10. Its expected value is 0.90 × $1 + 0.10 × (−$12) = **−$0.30 per attempt**. Nine wins and one loss in ten attempts would also produce $9 − $12 = −$3. A 90% win rate can therefore coexist with a losing process. The actual sequence may be better or worse than this average. A trader must be able to survive the possible loss, not merely quote the average.

You can turn this around and ask for the *break-even* win probability before costs. Let p be the chance of winning $1; then 1 − p is the chance of losing $12. Expected value is p × 1 + (1 − p) × (−12) = 13p − 12. Set that expression to zero: p = 12/13 ≈ **92.3%**. Once commissions or slippage are included, the required win probability rises further. This calculation still assumes the two payoff sizes and probabilities are stable, which is often least plausible when markets become stressed.

Sometimes a probability depends on information. The notation **P(A | B)** means “probability of event A given that B has happened.” For example, consider an event that happens on 10% of days. A warning lights up on 80% of event days and on 20% of non-event days. In 1,000 hypothetical days, about 100 are event days and 900 are non-event days. The warning appears on 80 event days and 180 non-event days. Among the 260 warning days, only 80 are event days. Thus P(event | warning) = 80/260 ≈ **30.8%**. The warning can be useful yet still wrong more often than right after it appears. The starting 10% **base rate** matters.

A **distribution** lists outcomes and their probabilities. Its mean is the expected value. Its **variance** describes how far outcomes tend to be from that mean, but a single variance number may conceal rare, severe losses. If two losses each have a 10% chance, their joint chance is 1% **only if the events are independent**. Market losses often arrive together; do not multiply probabilities without checking that assumption. A forecast of “a one-standard-deviation move” also relies on a model of returns. It is not a hard boundary.

In options, distinguish **real-world probabilities** (attempts to describe future outcomes) from prices. An option's implied volatility comes from market option prices through a model; it is not a reliable promise that a particular price path will occur. You will learn the pricing distinction in Sprints 17–18. For now, write down the possible payoff amounts, the assumptions behind any probabilities, and what happens if the tail outcome is worse than estimated.

### Four weeks of guided work

| Week | Ten hours of work |
| --- | --- |
| 49 | 2 h read this lesson and Khan's basic probability unit; 3 h solve fraction/probability drills; 3 h invent ten sample spaces; 2 h explain “event” and “probability” aloud without notes. |
| 50 | 2 h conditional probability lessons; 3 h draw 2×2 event tables; 3 h redo the warning example at 5% and 20% base rates; 2 h write why a warning is not certainty. |
| 51 | 2 h expected-value lessons; 3 h solve 20 payoff tables; 3 h compare win rates with expected values after fees; 2 h teach back the $1/−$12 example. |
| 52 | 2 h distributions and spread; 3 h exercises below; 3 h create three severe-loss scenarios; 2 h closed-note quiz and error review. |

### Practice — answer before reading the key

1. A game pays +$2 on 70% of attempts and −$6 on 30%. Find its expected value.
2. A game wins 90% of the time for +$1 and loses 10% for −$12. What happens over exactly nine wins and one loss?
3. Recalculate the warning example for 1,000 days if the event base rate is 20%, warning sensitivity remains 80%, and the false-warning rate remains 20%.
4. Two losses each occur with probability 0.10. When may you say their joint probability is 0.01? Why might that fail in a portfolio?
5. A distribution has outcomes +$2 with probability 0.50, $0 with probability 0.25, and −$3 with probability 0.25. Find expected value and probability of a loss.

<details><summary>Worked answer key</summary>

1. 0.70 × 2 + 0.30 × (−6) = 1.40 − 1.80 = **−$0.40**.
2. 9 × $1 − $12 = **−$3**. The high win rate did not cover the loss.
3. Event days: 200; warning on 0.80 × 200 = 160. Non-event days: 800; false warning on 0.20 × 800 = 160. P(event | warning) = 160/(160+160) = **50%**.
4. **Only if independent:** 0.10 × 0.10 = 0.01. Shared market shocks make portfolio losses dependent, sometimes strongly.
5. Expected value = 0.50 × 2 + 0.25 × 0 + 0.25 × (−3) = **+$0.25**. Loss probability is **25%**.

</details>

**Pass gate:** Explain expected value, base rates, conditional probability, and dependence without notes; solve all five exercises and two new payoff tables correctly. Complete the relevant Khan probability unit checks. A guessed probability must be labeled an assumption, never a fact.

---

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** A fictional trade wins $80 with probability 0.85 and loses $500 otherwise. Compute expected value and explain how the conclusion changes if the rare loss was understated.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: A high hit rate meets the tail

**Fictional teaching case.** A fictional strategy presentation advertises a 90% win probability. Each modeled win earns $100; each modeled loss loses $1,200. The manager calls the strategy reliable because most periods are positive.

Two-outcome classroom model; probabilities 0.90/0.10; amounts already net of modeled costs. Assume stable independent trials only for the first calculation. A second proposal contains two identical exposures to the same underlying event.

### Initial decision

Compute expected value and the break-even win probability. Explain why a favorable average, even if found, would not by itself answer whether the portfolio can bear the tail.

### New information — commit your first decision before reading

The manager says the two positions diversify because each separately has a 10% loss probability. Their loss events are actually the same event. Recompute the joint-loss probability and combined loss amount.

### Defense

- What is the strongest reason to disagree with your recommendation in 'A high hit rate meets the tail'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Expected value is 0.90×$100 + 0.10×(−$1,200) = −$30 per attempt. Setting 100p−1,200(1−p)=0 gives p=12/13≈92.31% before any unmodeled cost. Identical event losses occur together with 10% probability, not 1%; the combined loss is $2,400. The probability inputs remain assumptions. Good reasoning separates expectation, tail size, dependence and ability to survive the loss. A capital plan must also identify how the $2,400 joint loss would be funded and what happens if the modeled tail is exceeded; those questions are not answered by the average alone.

### Weak — unsupported submission

A 90% hit rate means the strategy is safe and profitable. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Expected value is 0.90×$100 + 0.10×(−$1,200) = −$30 per attempt. Setting 100p−1,200(1−p)=0 gives p=12/13≈92.31% before any unmodeled cost. Identical event losses occur together with 10% probability, not 1%; the combined loss is $2,400. The probability inputs remain assumptions. Good reasoning separates expectation, tail size, dependence and ability to survive the loss. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The model expectation is −$30, and matching event exposures lose $2,400 together with 10% probability. I challenge the probabilities and tail specification rather than using hit rate as the decision rule.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Use expected value, base rates and dependence to challenge an attractive claim. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'A high hit rate meets the tail'. Compute expected value and the break-even win probability. Explain why a favorable average, even if found, would not by itself answer whether the portfolio can bear the tail.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- A fictional trade wins $80 with probability 0.85 and loses $500 otherwise. Compute expected value and explain how the conclusion changes if the rare loss was understated.
- Teach the central distinction of 'A high hit rate meets the tail' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OCC characteristics and risks disclosure](https://www.theocc.com/company-information/documents-and-archives/options-disclosure-document)

## Module 14: Statistics tells you how uncertain your evidence is

Recognize selection, dependence and uncertainty before interpreting significance.

Stage: Quantitative reasoning and models. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 13.

### Decision, intuition and learning outcome

## Begin with a decision

A statistical headline has a research history. If the analyst searched until a result appeared, the relevant experiment includes those unsuccessful searches. Overlapping observations also do not become independent information merely because a spreadsheet has many rows.

**Learning outcome:** Recognize selection, dependence and uncertainty before interpreting significance.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

Probability starts with a model and asks what outcomes it implies. **Statistics** starts with observed outcomes and asks what you can reasonably infer. If a strategy shows 60 wins in 100 observations, the observed win rate is 60%. That number is an **estimate** from a **sample**, not the permanent win probability of a market process. A different set of 100 trades might show a different rate even if nothing fundamental changed. More importantly, option trade payoffs differ in size; a win-rate estimate does not answer whether the strategy makes money after costs.

A useful starting question is “What would we observe if there were no edge?” This is a **null hypothesis**. Suppose, in a deliberately simple coin-like example, the true win probability under the null is 50%, the 100 observations are independent, and every observation uses the same rule. The standard deviation of the win count is approximately the square root of 100 × 0.5 × 0.5 = **5 wins**. Sixty wins is 10 above the expected 50, or roughly two standard deviations away. A conventional two-sided normal approximation gives a p-value near 0.05. That is not a 95% probability that the strategy is good. It means an outcome at least this far from 50 could occur around 5% of the time under the *idealized null and assumptions*. Options trades often overlap, are regime dependent, and differ in size, so the coin-like calculation is not a valid final trading test.

Now imagine testing 20 independent, useless ideas at a 5% false-alarm threshold. Even when all ideas have no edge, the chance that at least one passes is 1 − 0.95^20 ≈ **64%**. Actual strategies are not independent either, but trying many variants and reporting the winner still creates a serious selection problem. Record every idea and parameter tried. Freeze the final rule before looking at the final test sample. A test that influenced your rule is development data, however you label it.

A **confidence interval** is a range made by a procedure with a stated long-run coverage rate under its assumptions. It is not a guarantee that a fixed unknown parameter lies inside the range for this particular sample. In the 60/100 example, a rough normal interval is 0.60 ± 1.96 × square root of (0.60 × 0.40 / 100), or about **0.50 to 0.70**. With small samples or extreme rates, use a better interval method; the rough calculation is for intuition. It already shows that a single observed 60% rate is imprecise.

**Worked dependence check:** Suppose six five-day returns were measured on six consecutive days. Each adjacent pair shares four of its five daily observations. Counting them as six independent five-day bets would overstate the information. In the [lab's statistics stage](labs/README.md), compare an independent-observation standard error with a moving-block resample of the dated P&L series. Vary block length and record the interval each time. The block method still relies on assumptions about how much dependence carries through time; its output is a sensitivity check, not an automatic certificate of significance. Preserve the original portfolio time series and every attempted rule in the trial log.

Financial data create special traps. **Autocorrelation** means today's observation can relate to yesterday's. Two five-day returns measured on adjacent days share four of five daily returns; treating them as independent exaggerates information. **Selection bias** occurs when your sample was chosen because its outcome looked appealing. **Survivorship bias** occurs when failed or delisted assets are missing. **Look-ahead bias** occurs when a test uses information not available at the simulated decision time. A strategy built only from today's surviving stocks and yesterday's final option settlement data may look attractive even though no trader could have followed it then.

Statistics cannot replace economic reasoning. Before testing, explain why a counterparty would repeatedly pay for your proposed exposure, why the reward may compensate for risk, and why competition has not removed it. After testing, examine average **net** payoff, drawdown, tail losses, costs, and a fair benchmark as well as uncertainty. The [original backtest-overfitting paper](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2326253) shows why repeatedly searching historical tests can select strategies that disappoint later. This is motivation to keep a complete experiment log, not a claim that any one statistical correction proves an edge.

### Four weeks of guided work

| Week | Ten hours of work |
| --- | --- |
| 53 | 2 h Khan sampling lessons; 3 h compute sample means and rates; 3 h compare multiple toy samples from one assumed process; 2 h describe “sample” versus “population.” |
| 54 | 2 h confidence interval and hypothesis lessons; 3 h reproduce the 60/100 example; 3 h study how changing sample size alters uncertainty; 2 h write what a p-value does and does not mean. |
| 55 | 2 h multiple testing; 3 h calculate false alarms for 5, 10, and 20 searches; 3 h inspect overlapping returns and a selection-bias story; 2 h create an experiment log. |
| 56 | 2 h read [RESEARCH_LAB.md](RESEARCH_LAB.md); 3 h exercises; 3 h critique three published or invented “high win-rate” claims; 2 h closed-note review. |

### Practice

1. A system has 6 wins in 10 trades. Is a 60% observed rate enough to establish a true 60% win probability? Explain.
2. Under a 50% independent-win null, what is the expected number of wins in 100 trials and the approximate standard deviation of that count?
3. With 20 independent tests, each at a 5% false-positive threshold, find the chance of at least one false positive.
4. Why are two consecutive rolling five-day returns not independent pieces of five-day evidence?
5. A researcher tunes an entry threshold after seeing performance from 2020–2024, then calls those same years “out of sample.” What is wrong?
6. An options study includes only stocks still listed today. Name the bias and one consequence.

<details><summary>Worked answer key</summary>

1. **No.** Ten observations carry large sampling uncertainty; costs, payoff size, dependence, and selection also matter.
2. Expected wins = 100 × 0.5 = **50**. Standard deviation = square root of (100 × 0.5 × 0.5) = **5**.
3. Probability none passes by chance = 0.95^20 ≈ 0.3585. At least one = **1 − 0.3585 ≈ 64.2%**, under the independence assumption.
4. They share four daily observations, so they carry overlapping information.
5. The years affected the rule. They are development data. An untouched later period is needed for a final test.
6. **Survivorship bias.** Excluding delisted or failed firms can exaggerate historical performance and understate losses.

</details>

**Pass gate:** Correct all six answers, present three critiques that identify costs, sample selection, and an unseen test period, and complete relevant Khan inference units. In the [statistics lab](labs/README.md), show how an overlapping event can cross a date split and how a chosen block length changes the illustrative uncertainty interval. Never translate a p-value into “probability this trade will win.”

---

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Explain the difference between forty disjoint five-day periods and forty consecutive rolling five-day returns; design a trial log that would reveal a stopped search.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: Twenty searches and one headline

**Fictional teaching case.** A fictional researcher tried twenty parameter variants, found one with a nominal p-value below 0.05, and reports only that variant. Its 100 observations are rolling five-day returns measured on consecutive days.

For a teaching calculation only, assume twenty independent tests under true nulls with a 5% false-positive rate each. In the actual study, variants and returns may be dependent. The researcher altered the winning rule after viewing all dates.

### Initial decision

Calculate the illustrative chance of at least one false positive. Explain why neither that number nor the reported p-value is a posterior probability that the strategy works.

### New information — commit your first decision before reading

The researcher renames the same history “validation data” after freezing the final rule. Specify what evidence has actually remained unseen and what must be collected next.

### Defense

- What is the strongest reason to disagree with your recommendation in 'Twenty searches and one headline'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Under the supplied independent-null illustration the chance is 1−0.95^20≈64.15%. The real variants need not satisfy independence, so that is a warning example rather than a calibrated correction. Consecutive rolling five-day returns share observations; 100 rows do not give 100 independent five-day trials. History used for tuning stays development data. Renaming it does not create unseen evidence; use genuinely reserved or later data, preserve the trial log and report dependence-aware uncertainty.

### Weak — unsupported submission

One p-value below 0.05 means there is a 95% chance the strategy is profitable. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Under the supplied independent-null illustration the chance is 1−0.95^20≈64.15%. The real variants need not satisfy independence, so that is a warning example rather than a calibrated correction. Consecutive rolling five-day returns share observations; 100 rows do not give 100 independent five-day trials. History used for tuning stays development data. Renaming it does not create unseen evidence; use genuinely reserved or later data, preserve the trial log and report dependence-aware uncertainty. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The independent-null illustration gives about 64% chance of at least one false positive. I retain all variants, flag overlap and tune/test reuse, and reserve later evidence before making a narrower claim.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Recognize selection, dependence and uncertainty before interpreting significance. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'Twenty searches and one headline'. Calculate the illustrative chance of at least one false positive. Explain why neither that number nor the reported p-value is a posterior probability that the strategy works.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Explain the difference between forty disjoint five-day periods and forty consecutive rolling five-day returns; design a trial log that would reveal a stopped search.
- Teach the central distinction of 'Twenty searches and one headline' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [original backtest-overfitting paper](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2326253)

## Module 15: Python makes your calculations repeatable

Produce a reproducible calculation with independent checks and explicit input conventions.

Stage: Quantitative reasoning and models. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 14.

### Decision, intuition and learning outcome

## Begin with a decision

Reproducibility means another person can start from declared inputs and reproduce the result, including failures. A saved chart is useful evidence only when its data, transformations and units can be reconstructed. A hand-check is an independent route to the answer.

**Learning outcome:** Produce a reproducible calculation with independent checks and explicit input conventions.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

You can compute returns with a calculator, but a research project may contain thousands of dated prices. A **program** is a set of exact instructions that can be rerun. It helps another person check your work and helps you catch mistakes that a spreadsheet may hide. Programming is not a source of trading advantage by itself; it is a way to make definitions and assumptions explicit.

If you have never coded, begin with [MIT 6.100L](https://ocw.mit.edu/courses/6-100l-introduction-to-cs-and-programming-using-python-fall-2022/). It was designed for students with little or no programming experience and includes videos and problem sets. The [official Python tutorial](https://docs.python.org/3/tutorial/) is useful afterward, but it explicitly assumes you already understand general programming. You need not finish all of MIT 6.100L in four weeks. Extend the sprint until loops, functions, lists, file reading, and errors feel routine.

Start with three ideas. A **variable** stores a value under a name. A **list** holds ordered values. A **function** accepts inputs and returns an output. A **loop** applies the same steps repeatedly. With closing prices 100 and 102, the simple return is (102/100) − 1 = 0.02, or 2%. With 102 and 101, it is (101/102) − 1 ≈ −0.98%. Returns are ratios, so a $2 move has a different percentage meaning when the starting price changes.

There are several ways to summarize a price path. A **simple return** is useful for the gain on one period of invested capital. A **log return** is ln(new price/old price), where ln is the natural logarithm. Consecutive log returns add across time, which simplifies some models; consecutive simple returns compound by multiplication. For example, a move from 100 to 110 and back to 100 has +10% and about −9.09% simple returns, whose sum is misleadingly positive. Their compounded wealth factor is 1.10 × 0.90909 ≈ 1.00. The log returns sum to zero. State which return definition you use before comparing studies.

The example below creates a tiny *synthetic* CSV file and reads it back. It checks date order and positive prices. It calculates simple returns and a sample estimate of annualized historical volatility from daily **log returns**. Log return means the natural logarithm of today's price divided by yesterday's. The square root of 252 is a conventional trading-day annualization factor. Four observed daily returns are far too few for a useful market estimate; here they merely test the code. Save the following indented code as a Python file named sample_returns.py and run it with Python 3:

    from pathlib import Path
    from datetime import date
    import csv
    import math
    import statistics

    rows = [
        ("2026-01-05", 100.0),
        ("2026-01-06", 102.0),
        ("2026-01-07", 101.0),
        ("2026-01-08", 103.0),
        ("2026-01-09", 102.0),
    ]
    path = Path("synthetic_prices.csv")
    with path.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["date", "close"])
        writer.writerows(rows)

    with path.open(newline="") as handle:
        loaded = list(csv.DictReader(handle))
    dates = [date.fromisoformat(row["date"]) for row in loaded]
    prices = [float(row["close"]) for row in loaded]
    assert dates == sorted(dates) and len(dates) == len(set(dates))
    assert all(math.isfinite(price) and price > 0 for price in prices)

    simple_returns = [
        prices[i] / prices[i - 1] - 1
        for i in range(1, len(prices))
    ]
    log_returns = [
        math.log(prices[i] / prices[i - 1])
        for i in range(1, len(prices))
    ]
    annualized_vol = statistics.stdev(log_returns) * math.sqrt(252)
    print("simple returns:", [round(x, 4) for x in simple_returns])
    print("annualized sample volatility:", round(annualized_vol, 4))

The **assert** lines are small tests. If a date repeats or a price is nonfinite or nonpositive, the program stops rather than silently producing a result. In real data you must also parse time zones, missing dates, splits, dividends, and option contract changes. This snippet is not yet an options backtest. It is a foundation for one. The [executable lab](labs/README.md) adds contract accounting, quote quality, timing, and research checks with supplied synthetic fixtures.

One frequent mistake is to confuse a code result with a correct answer. A script can faithfully repeat a wrong formula, wrong timestamp, or survivorship-biased universe. Write a hand calculation for one row and compare it with the program. Save the input data and code version. If you change a cleaning rule, record the change. Reproducibility means another person can obtain the same result from the same inputs; credibility also requires that those inputs were available when the simulated decision was made.

### Four weeks of guided work

| Week | Ten hours of work |
| --- | --- |
| 57 | 3 h MIT beginner lessons on variables, types, and conditionals; 3 h short programs; 2 h run and modify sample_returns.py; 2 h explain each line. |
| 58 | 3 h loops, lists, functions; 3 h rewrite the return calculation as a function; 2 h deliberately trigger an assertion; 2 h write what failed and why. |
| 59 | 3 h CSV/file lessons; 3 h add five synthetic rows; 2 h compare hand and program returns; 2 h save code and data with descriptive filenames. |
| 60 | 2 h plotting tutorial of your choice; 3 h make a dated closing-price plot; 3 h exercises and a reproducibility check; 2 h teach back why four returns cannot validate a volatility forecast. |

### Practice

1. A price rises from 100 to 110. Find its simple return.
2. It then falls from 110 to 100. Find that return. Does a +10% followed by this loss leave a gain?
3. What happens if the example CSV contains the same date twice? Why is stopping useful?
4. Which line would you change to use 365 calendar days rather than 252 trading days in the illustrative annualization? Does doing so alone make the estimate more reliable?
5. A program reads tomorrow's close to decide whether it would have bought today. Is it reproducible? Is it a valid historical decision rule?

<details><summary>Worked answer key</summary>

1. 110/100 − 1 = **+10%**.
2. 100/110 − 1 ≈ **−9.09%**. The final price is 100, so the net price gain is zero.
3. The uniqueness assertion fails and stops the script. A duplicate date could otherwise double-count one observation.
4. Change math.sqrt(252) to math.sqrt(365) **only if the observation interval and model warrant that convention**. It does not repair a four-return sample.
5. The code may be reproducible, but the rule has **look-ahead bias** because tomorrow's close was unavailable today.

</details>

**Pass gate:** Run the code as written; explain and hand-check every calculation; produce a CSV, a price plot, and a rerunnable script. If you already program well, demonstrate the same skill on an unseen CSV and complete the [lab's payoff, ledger, and quote-QA stages](labs/README.md) instead of repeating beginner syntax drills. If introductory programming remains difficult, repeat the sprint before working with option-chain data.

---

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Use prices $50, $55, $52.25. Calculate both simple returns and design a failure case involving reversed dates.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The notebook that only works once

**Fictional teaching case.** A fictional analyst shares a notebook showing daily percentage returns and volatility. It runs only after several cells are manually executed out of order, and a cached variable supplies the price series.

Fixture closing prices: $100, $102, $101. Use simple returns, no missing values and exact supplied order. The two simple returns are 0.02 and −1/102≈−0.00980392. Do not annualize a two-return fixture into market evidence.

### Initial decision

Specify a clean-run calculation, data manifest and tests. Reproduce the two returns by hand and explain which transformations must be frozen before using a larger sample.

### New information — commit your first decision before reading

The second price is changed from $102 to $0. The old notebook silently drops the row. Decide which check should fail and why a filter chosen after results is a methodological change.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The notebook that only works once'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

A clean run must load declared prices, preserve ordering and compute (P_t/P_(t−1))−1. The first return is +2%; the second is about −0.980392%. A zero predecessor makes the next simple-return division undefined; the fixture should fail its stated positive-price assumption rather than silently produce a flattering chart. Tests should check input order, finite values, units and at least one independently derived result. Any filtering policy belongs in the versioned method and its exclusions log.

### Weak — unsupported submission

The chart looks correct on my laptop, so the analysis is reproducible. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

A clean run must load declared prices, preserve ordering and compute (P_t/P_(t−1))−1. The first return is +2%; the second is about −0.980392%. A zero predecessor makes the next simple-return division undefined; the fixture should fail its stated positive-price assumption rather than silently produce a flattering chart. Tests should check input order, finite values, units and at least one independently derived result. Any filtering policy belongs in the versioned method and its exclusions log. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

I supply a clean executable path, input manifest and hand-checked +2%/−0.980392% returns. The zero input fails an explicit data assumption and remains visible in the exclusion record.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Produce a reproducible calculation with independent checks and explicit input conventions. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The notebook that only works once'. Specify a clean-run calculation, data manifest and tests. Reproduce the two returns by hand and explain which transformations must be frozen before using a larger sample.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Use prices $50, $55, $52.25. Calculate both simple returns and design a failure case involving reversed dates.
- Teach the central distinction of 'The notebook that only works once' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [MIT 6.100L](https://ocw.mit.edu/courses/6-100l-introduction-to-cs-and-programming-using-python-fall-2022/)
- [official Python tutorial](https://docs.python.org/3/tutorial/)

## Module 16: Bad option data can create a fake edge

Apply point-in-time data checks while preserving held positions and unresolved exits.

Stage: Quantitative reasoning and models. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 15.

### Decision, intuition and learning outcome

## Begin with a decision

Data cleaning changes the experiment. An impossible observation and an inconvenient genuine market condition require different treatment. A zero bid can be a real liquidity problem; deleting it can erase exactly the exit difficulty the research should measure.

**Learning outcome:** Apply point-in-time data checks while preserving held positions and unresolved exits.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

Before researching an options strategy, ask a simpler question: **What exactly was available at the decision time?** A daily closing stock price is not enough to reconstruct an option order. An option is identified by its underlying, call or put type, strike, expiration, and contract deliverable. A quote has a bid, ask, sizes, and timestamp. A signal also needs the underlying price, calendar, and information that was already public. If these pieces do not line up in time, a backtest can give itself knowledge no trader possessed.

A **point-in-time** dataset preserves the world as it appeared then. Imagine computing a strategy on January 10 using an earnings report published January 11. The program may run perfectly, but the simulated trade is impossible. Another subtle error is using an option's final end-of-day quote to decide a trade said to occur earlier that day. State the decision timestamp and the earliest executable timestamp separately. If data sources use New York time, UTC, or local computer time, convert them explicitly. Around daylight-saving changes, a fixed offset is not always enough.

For an option chain row, write a data dictionary. For example: underlying symbol and identifier; option root; call/put; strike; expiration; standard or adjusted deliverable; multiplier; quote date and time zone; bid/ask and displayed sizes; underlying price timestamp; volume; open interest; and source/license. The distinction between an ordinary 100-share contract and an adjusted contract matters because multiplying every premium by 100 can be wrong. Corporate actions such as splits, mergers, and special dividends may alter deliverables or symbols. [OCC information memos](https://infomemo.theocc.com/infomemo/search-memo) are the source for the particular contract adjustment; do not invent one generic split rule.

Consider these invented observations for the same standard 100-share call when you plan to decide at 15:45 New York time:

| Row | Quote time | Bid | Ask | First action |
| --- | --- | ---: | ---: | --- |
| A | 15:45 | $2.10 | $2.30 | Keep for inspection |
| B | 15:45 | $2.40 | $2.20 | Flag as crossed; investigate |
| C | 09:31 | $2.00 | $2.20 | Flag as stale for a 15:45 decision |
| D | 15:45 | $0.00 | $0.15 | Flag zero bid; determine whether an exit was possible |

For row A, buying at the displayed ask and immediately selling at the bid would lose ($2.30 − $2.10) × 100 = **$20 before fees**. That arithmetic is a conservative *illustration*, not a promise that either order would fill. Row B has bid above ask; this may reflect a crossed or asynchronous record and cannot be silently treated as an ordinary market. Row C is many hours old. Row D may be a real quote, but a long holder assuming it can sell at the $0.075 midpoint would be making an unsupported fill assumption. You can flag rather than automatically delete such records. The choice must be written before seeing strategy results, and the report must say how many rows each rule affects.

Two common biases require more than quote cleaning. **Survivorship bias** arises if you study only stocks listed today and omit names that disappeared. **Corporate-action bias** arises if you connect modern symbols or standard contract terms backward through splits or mergers. A historical option universe must include the contracts that existed on each date. The [Cboe DataShop EOD description](https://datashop.cboe.com/option-eod-summary) describes 15:45 and end-of-day option snapshots and says optional implied volatilities and Greeks are calculated at 15:45. It does not mean every historical quote is an executable opportunity; there is displayed size, latency, and potentially costly access. Confirm the product's fields and license before any purchase.

Data quality is not a glamorous strategy, but it is a prerequisite for honest research. Keep raw data untouched, produce a cleaned copy, write every exclusion rule, and manually reconcile sample rows against contract specifications. Report coverage by date, underlying, expiration, and moneyness; a strategy that works only where data are sparse or stale deserves extra suspicion. A missing observation is missing. It is not a zero return.

### Four weeks of guided work

| Week | Ten hours of work |
| --- | --- |
| 61 | 2 h read this lesson and Cboe product description; 3 h design a data dictionary; 3 h inspect ten delayed option-chain rows; 2 h identify each contract's deliverable. |
| 62 | 2 h learn timestamp and time-zone rules; 3 h flag stale/crossed/zero-bid cases in a toy table; 3 h compare underlying and option times; 2 h explain why same-day data may still leak. |
| 63 | 2 h read OCC corporate-action guidance; 3 h find an adjusted-contract memo; 3 h document what changed and what is unknown; 2 h make a decision-time checklist. |
| 64 | 2 h review survivorship; 3 h exercises; 3 h create a QA report on a small sample; 2 h redo a random five rows manually. |

### Practice

1. Why may a 09:31 option quote be unacceptable for a strategy that claims a 15:45 fill?
2. Row A above has a 100-share multiplier. What is the ask-to-bid round-trip cost before fees?
3. Should row B be accepted at face value? What should your report record about it?
4. An option root has changed after a merger. May you assume the old contract still delivers 100 shares of the old stock? Where do you check?
5. A program uses the full day's high and low to decide a trade at 10:00 that morning. Name the error.
6. Why can a universe of only companies listed today overstate a historical strategy's results?

<details><summary>Worked answer key</summary>

1. It may no longer describe the market at 15:45; bids, asks, sizes, underlying price, and volatility could have changed. Mark it stale under a predefined rule.
2. (2.30 − 2.10) × 100 = **$20**, before commissions and other costs.
3. **No.** Bid exceeds ask. Flag or investigate it and report how many such observations exist and how the cleaning rule affects results.
4. **No.** Check the exact series terms and relevant [OCC information memo](https://infomemo.theocc.com/infomemo/search-memo).
5. **Look-ahead bias:** later prices were unavailable at 10:00.
6. It omits firms that failed, merged, or delisted and may understate past losses: **survivorship bias**.

</details>

**Pass gate:** Deliver a data dictionary, raw-to-clean rule list, counts of every rejected or flagged condition, and a manual reconciliation of at least ten contract-days, including one adjusted or special-event case. Use the [supplied synthetic quote fixture](labs/README.md) to show that a later invalid quote cannot be silently replaced by an earlier favorable one. Stop if contract terms or timestamps cannot be explained.

---

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Create one valid zero-size row, one stale row and one adjusted contract identifier; describe separate validation rules and what remains unresolved.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The zero bid that disappeared

**Fictional teaching case.** A fictional replay holds an option when its displayed bid becomes zero. A cleaning script deletes all zero-bid rows and then evaluates exits only on the remaining positive quotes.

At 10:00 a held standard call shows bid $0.00/ask $0.20, timestamp current. At 10:01 another row shows bid $1.20/ask $1.00. At 10:02 a quote has yesterday’s timestamp. The feed specification allows a genuine zero bid.

### Initial decision

Classify each observation and write a prespecified handling rule. Show how the held position remains in the ledger when an executable exit cannot be established.

### New information — commit your first decision before reading

A later settlement outcome is profitable. The researcher wants to replace the earlier missing exit with that value and label it a 10:00 fill. Explain the time-information violation.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The zero bid that disappeared'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

The current zero bid signals no displayed positive bid in this fixture; it must not erase the held exposure. The crossed $1.20/$1.00 row needs investigation under a documented policy, and yesterday’s timestamp must be flagged as stale for the intended decision. Preserve the position, available observations and unresolved exit. A later settlement value can explain later accounting but cannot become a fictional earlier fill. Report sensitivity and uncertainty instead of selecting favorable surviving rows.

### Weak — unsupported submission

Delete all zero bids and use the next profitable quote as the previous exit. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

The current zero bid signals no displayed positive bid in this fixture; it must not erase the held exposure. The crossed $1.20/$1.00 row needs investigation under a documented policy, and yesterday’s timestamp must be flagged as stale for the intended decision. Preserve the position, available observations and unresolved exit. A later settlement value can explain later accounting but cannot become a fictional earlier fill. Report sensitivity and uncertainty instead of selecting favorable surviving rows. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

I retain the held option through the zero bid, flag crossed and stale data separately, and refuse to use later settlement information as an earlier execution price.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Apply point-in-time data checks while preserving held positions and unresolved exits. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The zero bid that disappeared'. Classify each observation and write a prespecified handling rule. Show how the held position remains in the ledger when an executable exit cannot be established.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Create one valid zero-size row, one stale row and one adjusted contract identifier; describe separate validation rules and what remains unresolved.
- Teach the central distinction of 'The zero bid that disappeared' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OCC information memos](https://infomemo.theocc.com/infomemo/search-memo)
- [Cboe DataShop EOD description](https://datashop.cboe.com/option-eod-summary)

## Module 17: Replication explains an option's theoretical price

Derive a simple price from a replicating stock-cash portfolio and state its assumptions.

Stage: Quantitative reasoning and models. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 16.

### Decision, intuition and learning outcome

## Begin with a decision

Replication asks which stock-and-cash position delivers the same cash flows in every state of a stated model. When those states are exhaustive and trading/financing assumptions hold, differing prices would create an idealized arbitrage. The model is useful because every assumption is exposed.

**Learning outcome:** Derive a simple price from a replicating stock-cash portfolio and state its assumptions.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

Two positions that will pay exactly the same amount in every possible future state should have the same price today in a frictionless market. If they did not, one could theoretically buy the cheaper payoff and sell the dearer payoff. This is the **no-arbitrage** idea. It is a pricing principle, not an invitation to assume free money in a real market: bid/ask spreads, funding, stock borrowing, exercise style, dividends, and timing can erase apparent gaps.

Start with a European call and put on the same non-dividend-paying stock, with the same strike and expiration. Call the current stock price **S₀**, strike **K**, call price **C**, put price **P**, annual continuously compounded interest rate **r**, and time to expiration in years **T**. At expiration, the call pays max(S_T − K, 0) and the put pays max(K − S_T, 0), where S_T is the stock price then. Their difference is always **S_T − K**. Check both cases: if S_T is above K, the call pays S_T − K and the put zero; if S_T is below K, the call pays zero and the put K − S_T, so call minus put is again S_T − K.

Owning the call and writing the put therefore reproduces the future payoff of owning one share while owing K at expiration. A bond that pays K at expiration costs K × exp(−rT) today. Matching today's costs gives **C − P = S₀ − K × exp(−rT)**. This is *European put-call parity* under the stated assumptions. [OIC's parity explanation](https://www.optionseducation.org/advancedconcepts/put-call-parity) uses the same non-dividend formula. At zero interest, with S₀ = K = $100, the call and put must have the same theoretical price. If C = $8, then P = $8 in this idealized case.

A **binomial tree** makes replication more concrete. Assume a stock starts at $100 and, after one period, can be $110 or $90. A $100-strike European call pays $10 in the up state and $0 in the down state. Consider a portfolio of **0.5 shares** and a loan of **$45** that must be repaid at the end. In the up state it is worth 0.5 × 110 − 45 = $10. In the down state it is worth 0.5 × 90 − 45 = $0. It exactly matches the call's payoff. At zero interest the portfolio costs 0.5 × 100 − 45 = **$5 today**, so the call's no-arbitrage price is $5 under this one-period model.

You can compute the same $5 by assigning a **risk-neutral probability** of 0.5 to each branch and averaging the payoffs: 0.5 × $10 + 0.5 × $0 = $5. That 0.5 is a mathematical weight that makes the stock's discounted price consistent with the tree; it does **not** say the true chance of the stock rising is 50%. A trader's expected profit requires real-world probabilities, costs, and risk capacity. This difference between pricing weights and actual forecasts is central to options research.

For a general one-period tree, the replicating share amount is the difference between the option's up and down payoffs divided by the difference between the stock's up and down prices. The remaining part of the option payoff is reproduced with lending or borrowing. With a nonzero interest rate, both that cash leg and the expected option payoff under risk-neutral weights must be discounted consistently. The exercise teaches *why* a model price follows from assumptions. It does not mean an individual can continuously hedge one contract at negligible cost or trade the model's theoretical price.

Real equity options are often American-style, so exercise can occur before expiration. Dividends also matter. A simplified European parity equality need not hold directly for American options on dividend-paying stocks. A one-period tree ignores jumps between its two states, changes in volatility, and difficulty hedging. Treat its $5 as a model value under visible assumptions, then test how changing those assumptions changes the result. The [MIT Finance Theory I options lectures](https://ocw.mit.edu/courses/15-401-finance-theory-i-fall-2008/pages/video-lectures-and-slides/options/) provide further examples after this lesson.

### Four weeks of guided work

| Week | Ten hours of work |
| --- | --- |
| 65 | 2 h no-arbitrage lesson; 3 h compare two identical-payoff portfolios; 3 h draw call-minus-put payoffs above and below strike; 2 h explain the idea aloud. |
| 66 | 2 h OIC parity reading; 3 h solve ten zero-rate parity problems; 3 h add positive interest and present value; 2 h list every assumption. |
| 67 | 2 h binomial-tree lesson; 3 h reproduce the 100/110/90 tree; 3 h change the up/down prices and calculate the replicating shares and loan; 2 h explain risk-neutral versus real-world probability. |
| 68 | 2 h MIT option lecture; 3 h exercises below; 3 h contrast European and American exercise; 2 h closed-note model-assumption check. |

### Practice

1. At expiration with K = $100 and S_T = $120, what is call payoff minus put payoff? Repeat for S_T = $80.
2. At r = 0, no dividends, S₀ = K = $100, and C = $8, what is P under European parity?
3. In the 100/110/90 tree, show both terminal values of 0.5 share minus a $45 loan. What is its initial cost?
4. Change the tree to up = $120, down = $80, K = $100, r = 0. Find the replicating share amount, loan, and call price.
5. Is a risk-neutral probability of 0.5 a forecast that the stock will rise half the time?
6. Give two reasons an observed stock-option call-put price difference might fail the simple no-dividend European equation without offering a usable arbitrage.

<details><summary>Worked answer key</summary>

1. At 120: 20 − 0 = **+$20**. At 80: 0 − 20 = **−$20**. Both equal S_T − K.
2. C − P = S₀ − K = 0, so **P = $8**.
3. Up: 0.5 × 110 − 45 = **$10**. Down: 0.5 × 90 − 45 = **$0**. Initial cost: 0.5 × 100 − 45 = **$5**.
4. Call payoffs are $20 and $0. Shares = (20 − 0)/(120 − 80) = **0.5**. Down-state shares are worth $40, so borrow **$40**. Initial cost = $50 − $40 = **$10**.
5. **No.** It is a pricing weight under the tree and interest-rate assumption, not an estimate of the real probability.
6. Examples: American early exercise, dividends, mismatched expiration or deliverable, financing/borrow costs, bid/ask spread, stale quotes, and inability to execute all legs simultaneously.

</details>

**Pass gate:** Derive call-minus-put terminal payoff in both price regions; solve two new binomial trees by replication; state parity assumptions and explain why the risk-neutral weight is not a trading forecast. Compare a European put model with a [small American put tree](labs/README.md), checking step convergence and the different exercise rights.

---

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Use terminal stock $130/$90 with strike $100 and zero rate. Derive delta, cash and option price, and check both terminal states.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The option is replicated

**Fictional teaching case.** A fictional one-period market has stock at $100 today and only two possible terminal states: $120 or $80. A European $100 call pays $20 or $0. A committee member wants to price it using their personal 70% up probability.

Risk-free gross return is 1 for this one period; no dividends, fees, spreads or short-sale constraints; fractional stock and borrowing permitted in the classroom model. All trades occur at supplied values.

### Initial decision

Solve the stock hedge and cash position that replicate the call. Derive the call value and explain why the stated personal probability is unnecessary for this replication price.

### New information — commit your first decision before reading

Trading constraints now prohibit the short/borrow positions needed for the proposed arbitrage. Explain which implication of a quoted price discrepancy becomes weaker; do not silently keep frictionless conclusions.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The option is replicated'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Solve 120Δ+B=20 and 80Δ+B=0: Δ=0.5 and B=−40. Initial cost is 0.5×100−40=$10. Risk-neutral up weight is 0.5 in this zero-rate model, but it is a pricing weight, not proof of a real-world 50% frequency. The personal 70% estimate gives a different expected payoff question. When financing or trading constraints prevent the replicating/arbitrage implementation, a discrepancy from $10 is not automatically an executable riskless profit.

### Weak — unsupported submission

My 70% forecast makes the call worth $14, so any $10 call is guaranteed profit. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Solve 120Δ+B=20 and 80Δ+B=0: Δ=0.5 and B=−40. Initial cost is 0.5×100−40=$10. Risk-neutral up weight is 0.5 in this zero-rate model, but it is a pricing weight, not proof of a real-world 50% frequency. The personal 70% estimate gives a different expected payoff question. When financing or trading constraints prevent the replicating/arbitrage implementation, a discrepancy from $10 is not automatically an executable riskless profit. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The model replicates with half a share and −$40 cash for a $10 price. I distinguish pricing weights from forecasts and qualify implementation when financing constraints change.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Derive a simple price from a replicating stock-cash portfolio and state its assumptions. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The option is replicated'. Solve the stock hedge and cash position that replicate the call. Derive the call value and explain why the stated personal probability is unnecessary for this replication price.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Use terminal stock $130/$90 with strike $100 and zero rate. Derive delta, cash and option price, and check both terminal states.
- Teach the central distinction of 'The option is replicated' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OIC's parity explanation](https://www.optionseducation.org/advancedconcepts/put-call-parity)
- [MIT Finance Theory I options lectures](https://ocw.mit.edu/courses/15-401-finance-theory-i-fall-2008/pages/video-lectures-and-slides/options/)

## Module 18: Black–Scholes is a model, not a trading signal

Audit model scope, implied volatility and numerical sensitivities.

Stage: Quantitative reasoning and models. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 17.

### Decision, intuition and learning outcome

## Begin with a decision

Numerical precision cannot repair a contract mismatch. Start with exercise style, dividends, settlement and timestamps, then select a model. A finite-difference Greek is an independent sensitivity check only when units and changed inputs are consistent.

**Learning outcome:** Audit model scope, implied volatility and numerical sensitivities.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

The binomial tree had two possible future stock prices. A Black–Scholes–Merton model allows a continuous range of prices and assumes the stock's *log returns* follow a particular distribution with constant volatility. Under idealized conditions, continuous rebalancing of a hedge and no arbitrage lead to a formula for a **European** option. The model gives a disciplined common language for price and sensitivities. It does not reveal a “true” option value in the messy market.

Define the inputs before touching the formula. **S** is the current stock price, **K** the strike, **T** the remaining years, **r** a continuously compounded annual risk-free rate, and **σ** (sigma) an assumed annualized volatility. **N(x)** is the cumulative probability below x for a standard normal distribution. For a non-dividend-paying European call,

    d1 = [ln(S/K) + (r + σ²/2)T] / [σ√T]
    d2 = d1 − σ√T
    C = S N(d1) − K exp(−rT) N(d2)

You can use the formula without memorizing its derivation. The key is to understand its inputs and exclusions. For S = K = $100, T = 1 year, r = 0, and σ = 0.20, we obtain d1 = 0.10 and d2 = −0.10. Standard-normal tables or code give N(0.10) ≈ 0.53983 and N(−0.10) ≈ 0.46017. The model call value is 100 × (0.53983 − 0.46017) ≈ **$7.97 per share**. For a standard 100-share contract, that is approximately $797 in quoted premium if a market happened to transact at the model value. Actual bids and asks can differ.

The formula also lets you reverse the question: if the market price is observed, what σ makes the model price equal it? That σ is **implied volatility**. Implied volatility is an input backed out of a market quote using a model; it is not itself a forecast that realized volatility will equal it. Two strikes or expirations can have different implied volatilities, producing a **volatility smile or skew**. A model that assumes one constant σ for all states cannot explain every observed option price with the same σ.

The next code extends Sprint 15. Save it as bsm_demo.py. It uses only Python's standard library. The finite-difference calculation estimates the call's **delta** by repricing with S slightly above and below $100. This is a local sensitivity, not a promise about a large overnight move.

    import math

    def normal_cdf(x):
        return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))

    def european_call(S, K, T, r, sigma):
        if not all(math.isfinite(x) for x in (S, K, T, r, sigma)):
            raise ValueError("inputs must be finite")
        if S <= 0 or K <= 0 or T <= 0 or sigma < 0:
            raise ValueError("invalid price, time, or volatility")
        if sigma == 0:
            return max(S - K * math.exp(-r * T), 0.0)
        d1 = (math.log(S / K) + (r + 0.5 * sigma**2) * T) / (
            sigma * math.sqrt(T)
        )
        d2 = d1 - sigma * math.sqrt(T)
        return S * normal_cdf(d1) - K * math.exp(-r * T) * normal_cdf(d2)

    def implied_vol_call(market_price, S, K, T, r):
        if not math.isfinite(market_price):
            raise ValueError("market price must be finite")
        lower = european_call(S, K, T, r, 0)
        if market_price < lower or market_price >= S:
            raise ValueError("outside finite-volatility call bounds")
        if market_price == lower:
            return 0.0
        low, high = 0.0, 0.5
        while european_call(S, K, T, r, high) < market_price:
            high *= 2
            if high > 1024:
                raise ValueError("could not bracket volatility")
        for _ in range(90):
            middle = (low + high) / 2
            if european_call(S, K, T, r, middle) < market_price:
                low = middle
            else:
                high = middle
        return (low + high) / 2

    model_price = european_call(100, 100, 1, 0, 0.20)
    h = 0.01
    delta_estimate = (
        european_call(100 + h, 100, 1, 0, 0.20)
        - european_call(100 - h, 100, 1, 0, 0.20)
    ) / (2 * h)
    print("call value:", round(model_price, 4))
    print("delta estimate:", round(delta_estimate, 4))
    print("IV for a $10 call:", round(implied_vol_call(10, 100, 100, 1, 0), 4))

Five departures from the simple model deserve immediate attention: stock prices can jump; volatility changes; dividends affect stock options; actual hedging is discrete and costly; and some contracts permit early exercise. Bid/ask spreads, liquidity, borrowing, and contract adjustments add more. If your calculation says $7.97 and the market asks $8.50, you have not proved the option is expensive: perhaps your volatility input is wrong, a dividend or event is omitted, or the spread absorbs any apparent gap. [MIT's pricing notes](https://ocw.mit.edu/courses/15-450-analytics-of-finance-fall-2010/pages/lecture-notes/) develop the model more rigorously when your calculus and probability are ready.

The [executable model-validation lab](labs/README.md) extends this one-call teaching example to dividend-aware European calls and puts, put-call parity, an American put tree, strike-slice checks, and stress repricing. Its tests include zero stock value, nonfinite inputs, and a valid price whose implied volatility exceeds the old fixed 300% bracket. For each model, state what the price represents and which actual contract terms it leaves out.

### Four weeks of guided work

| Week | Ten hours of work |
| --- | --- |
| 69 | 2 h review the binomial tree; 3 h label every BSM input; 3 h reproduce the $7.97 example with a calculator; 2 h list model assumptions. |
| 70 | 2 h run bsm_demo.py; 3 h change S, T, and σ one at a time; 3 h compare numerical Greeks with earlier qualitative predictions; 2 h explain local approximation. |
| 71 | 2 h learn implied-volatility inversion; 3 h run the bisection function on several legal prices; 3 h draw an invented skew; 2 h separate market quote from model output. |
| 72 | 2 h read MIT's relevant pricing notes at your level; 3 h exercises; 3 h write a one-page model-limit report; 2 h closed-note Gate C review. |

### Practice

1. For S = K = 100, T = 1, r = 0, σ = 0.20, calculate d1 and d2.
2. Using N(0.10) ≈ 0.53983 and N(−0.10) ≈ 0.46017, calculate the call price to the nearest cent.
3. Run the code. What approximate call value and delta does it print? Explain the delta in words.
4. If an otherwise identical market call costs $10 rather than $7.97, is its model-implied volatility above or below 20%? Does that fact alone establish a bad trade?
5. List five concrete ways a real option or market can differ from the model.
6. A script calculates $8.00 while the displayed market is $7.90 bid/$8.50 ask. Can the script alone justify a buy or sell?

<details><summary>Worked answer key</summary>

1. d1 = (0 + 0.20²/2)/0.20 = **0.10**; d2 = 0.10 − 0.20 = **−0.10**.
2. 100 × (0.53983 − 0.46017) = **$7.966**, or about **$7.97 per share** before any contract multiplier.
3. About **7.9656** and **0.5398**. For a very small $1 stock-price rise with other inputs fixed, the model initially predicts roughly $0.54 more call value per share; the approximation changes as S changes.
4. **Above 20%**, because this call's model price rises with σ under the stated inputs. No: costs, model assumptions, event risk, and future realized outcomes remain unresolved.
5. Examples: jumps, changing volatility, dividends, early exercise, discrete hedging, transaction costs, bid/ask spreads, funding constraints, and illiquidity.
6. **No.** Buying at $8.50 or selling at $7.90 is different from transacting at $8.00; the model input may also be wrong.

</details>

**Pass gate:** Reproduce the code output, hand-calculate the at-the-money example, compute a finite-difference delta, explain implied volatility as an inversion of price, and name at least five violated assumptions. Add one [model-validation lab](labs/README.md) case that compares put-call parity or a call-strike slice with a deliberately broken input. Gate C also requires the Sprint 16 data audit and Sprint 17 replication exercise. Later, the full [MIT 15.450 syllabus](https://ocw.mit.edu/courses/15-450-analytics-of-finance-fall-2010/pages/syllabus/) is an advanced extension rather than required beginner reading.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Supplied model values at stock 49/51 are 2.20/3.00 and at IV 19%/21% are 2.45/2.75. Recompute sensitivities and list remaining validity questions.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: A precise European answer to the wrong contract

**Fictional teaching case.** A fictional team implements a European pricer and presents a precise value for an American-style dividend-paying stock option. The team also reports a vega number without saying whether volatility moved by 0.01 or 1.00.

For an independent synthetic sensitivity fixture, values at stock 99 and 101 are 4.52 and 5.62. Values at IV 24% and 26% are 4.90 and 5.30. These are supplied model outputs, not market quotes; all unmentioned inputs are fixed.

### Initial decision

Compute central-difference delta and vega per IV percentage point from the fixture. Identify the contract features the deployed European model omits and what comparison would be needed.

### New information — commit your first decision before reading

The team fits IV to the option midpoint, then calls the result a forecast of realized volatility. Explain the inversion and interpretation problem, including bid/ask uncertainty.

### Defense

- What is the strongest reason to disagree with your recommendation in 'A precise European answer to the wrong contract'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Central delta is (5.62−4.52)/(101−99)=0.55 per $1 stock move. Vega is (5.30−4.90)/2=$0.20 per IV point, or $20 per standard contract. The fixture verifies those units only. A European pricer omits the early-exercise feature in the proposed application and needs appropriate treatment of dividends and other terms. IV inversion finds the model input matching a specified price; changing bid/mid/ask can change that input. It does not establish future realized volatility.

### Weak — unsupported submission

The solver converged to six decimals, so the American contract is correctly priced. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Central delta is (5.62−4.52)/(101−99)=0.55 per $1 stock move. Vega is (5.30−4.90)/2=$0.20 per IV point, or $20 per standard contract. The fixture verifies those units only. A European pricer omits the early-exercise feature in the proposed application and needs appropriate treatment of dividends and other terms. IV inversion finds the model input matching a specified price; changing bid/mid/ask can change that input. It does not establish future realized volatility. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The fixture delta is 0.55 and vega $0.20 per IV point. I verify exercise/dividend scope, compare independent calculations and treat midpoint-implied volatility as a model inversion rather than a forecast.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Audit model scope, implied volatility and numerical sensitivities. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'A precise European answer to the wrong contract'. Compute central-difference delta and vega per IV percentage point from the fixture. Identify the contract features the deployed European model omits and what comparison would be needed.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Supplied model values at stock 49/51 are 2.20/3.00 and at IV 19%/21% are 2.45/2.75. Recompute sensitivities and list remaining validity questions.
- Teach the central distinction of 'A precise European answer to the wrong contract' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [MIT's pricing notes](https://ocw.mit.edu/courses/15-450-analytics-of-finance-fall-2010/pages/lecture-notes/)
- [MIT 15.450 syllabus](https://ocw.mit.edu/courses/15-450-analytics-of-finance-fall-2010/pages/syllabus/)

## Module 19: Read the volatility surface

Use no-arbitrage checks as qualified diagnostics rather than casual execution claims.

Stage: Research, portfolio policy and defense. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 18.

### Decision, intuition and learning outcome

## Begin with a decision

A surface fit should preserve the economic relationships its assumptions require. A shape violation is a reason to inspect quotes, timing, product terms and execution before interpreting a smooth curve or declaring a free profit.

**Learning outcome:** Use no-arbitrage checks as qualified diagnostics rather than casual execution claims.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

You already know that **implied volatility** (IV) is the volatility input that makes a pricing model reproduce an observed option price. A single stock has many options: different **strikes** and different **expirations**. Put their IVs on a grid and you have a **volatility surface**. The surface is a map of prices translated into one model language; it is not a map of guaranteed future volatility.

Look first across strikes with one expiration. Suppose the 30-day $90 put has 28% IV, the $100 at-the-money option has 22%, and the $110 call has 20%. This pattern is commonly called **downside skew**: lower strikes carry higher IV. That difference may reflect demand for downside insurance, expected jumps, or other market forces. The observation alone does not tell you an option is cheap or expensive. You would need a forecast of its eventual payoff, the costs of trading it, and a reason your forecast differs from the market. [OIC explains historical and implied volatility](https://www.optionseducation.org/advancedconcepts/volatility-the-greeks).

Now look across expirations at a comparable level of moneyness. This is the **term structure**. If 30-day IV is 20% and 90-day IV is 24%, longer maturity has higher annualized IV. A large event between those dates could contribute, but the surface alone cannot identify its cause. To compare two tenors more carefully, use **total implied variance**, approximately `IV² × time`. The 90-day period contains the first 30 days plus the next 60, so subtracting the first period's total variance isolates the later interval in this simplified model. With comparable contracts and time measured in days, 30 days at 20% contributes `30 × 0.20² = 1.20` day-variance units; 90 days at 24% contributes `90 × 0.24² = 5.184`. The implied variance for the 60-day interval between them is `(5.184 − 1.20) ÷ 60 = 0.0664` annualized variance, giving an interval volatility of about `sqrt(0.0664) = 25.8%`. This is an illustration, not a direct prediction; dividends, forward prices, strikes, exercise style, model choice, and noisy quotes matter.

A surface drawn from bad contracts is worse than no surface. Check whether quotes are fresh, spreads are narrow enough to be useful, the underlying price and option quote are simultaneous, the contracts have standard deliverables, and the comparison uses similar **moneyness** (strike relative to the forward price) across dates. A split or special dividend can change deliverables. Do not smoothly draw through missing quotes and then treat the resulting line as observed market data. [Cboe's DataShop description](https://datashop.cboe.com/option-eod-summary) shows that even professional EOD datasets specify observation times and optional model-derived Greeks.

For the advanced pricing branch, check that a same-expiry **European call** slice declines as strike increases and remains convex in strike. The [lab function](labs/README.md) checks these necessary conditions on clean model prices. A violation in displayed quotes should trigger a timestamp, bid/ask, and contract-terms investigation before anyone interprets it as executable arbitrage. Compare model Greeks with finite differences and identify the limitation of applying one volatility to the entire surface.

### A qualified calendar no-arbitrage check

First use a deliberately narrow model: two **European calls on the same non-dividend-paying stock**, with the **same strike, premium multiplier, and share deliverable**, zero interest, no fees or spreads, and frictionless stock borrowing and funding. The contracts have no adjustments and differ only in expiration, `T1 < T2`. Under these assumptions the later call cannot cost less than the earlier call: `C(K,T2) ≥ C(K,T1)`. This is a necessary check, not a guarantee that the whole surface is valid. With rates, dividends, or different forward prices, use the appropriate normalization and contract terms; [Gatheral and Jacquier derive the more general calendar condition at fixed forward moneyness](https://arxiv.org/abs/1204.0646).

**Worked violation:** the stock is initially $100, and hypothetical 30-day and 90-day $100 calls deliver 100 shares each. Assume executable frictionless premiums of $4 and $3 per share respectively. Sell the shorter call for $400 and buy the longer for $300, retaining **$100**. The longer European call cannot be exercised at the shorter expiry. Instead, follow the resulting positions:

| Event | Cash and positions, excluding any later realization of the $100 initial credit |
| --- | --- |
| At `T1`, stock is at or below $100 and the short expires without exercise | No short-call payment or shares; retain the longer call, whose eventual payoff is nonnegative. |
| At `T1`, stock is $110 and the short call is exercised | Deliver 100 borrowed shares and receive $10,000 strike cash. Now hold $10,000 cash, −100 shares, and the longer call. Stock borrowing and unrestricted use of the proceeds are assumptions of this proof. |
| At `T2`, stock is $120 after that assignment | Exercise the long call for $10,000, receive 100 shares, and return the borrowed shares. The cash and stock position is closed; the initial $100 remains. |
| At `T2`, stock is $80 after that assignment | Let the long call expire; buy 100 shares for $8,000 and return them. Keep $2,000 plus the initial $100. |

The argument covers every later stock price after assignment: the $10,000 cash and long-call payoff meet the cost of covering 100 short shares because `100 × [100 − S(T2) + max(S(T2) − 100,0)] = 100 × max(100 − S(T2),0) ≥ 0`. If the short expires without exercise, the remaining long call has nonnegative payoff. Thus the $100 entry credit with no later negative net cash flow contradicts no arbitrage **inside this model**. A later premium of $5 instead of $3 passes this particular maturity check; it does not prove every strike, expiry, or quote is consistent.

Real stock options, stock borrow, funding restrictions, settlement conventions, and executable bid/ask prices can invalidate the proof's assumptions. This is a pricing-consistency exercise, not a retail trade recommendation. A short-leg obligation does not automatically exercise a remaining European long leg. A displayed midpoint inversion is also insufficient: selling at the nearer bid and buying at the later ask may eliminate the apparent credit.

Annualized IV need not rise with maturity. For example, 30 days at 40% gives `30 × 0.40² = 4.80` day-variance units, while 90 days at 30% gives `90 × 0.30² = 8.10`. IV falls but total variance rises, so that observation alone does not violate the comparable zero-rate/no-dividend calendar check.

**Common mistake:** saying “28% IV is high, so sell it.” High relative to what: its own history, realized volatility that will occur, neighboring strikes, or a model forecast? Each comparison answers a different question, and none by itself proves an edge.

### Four-week practice

| Week | Work for the 10 hours | Evidence |
| --- | --- | --- |
| 73 | Rebuild the definitions of IV, strike, expiration, moneyness, skew, and term structure with diagrams. | One-page plain-language explanation. |
| 74 | Collect dated delayed quotes for one liquid underlying on two expirations. Record bid, ask, timestamp, and contract terms. | Raw observation table, including rejected quotes. |
| 75 | Plot IV by strike for each expiry and IV by expiry near the money. Explain the shape without claiming profit. | Two labeled charts and a caveat list. |
| 76 | Repeat on another date or underlying; check whether changes could be data artifacts. Solve the qualified calendar example and a changed-number case. | Short comparison memo, corrected charts, and the two-expiry cash/share ledger with assumptions. |

### Try it, then check

1. On one expiry, IVs at strikes 90, 100, and 110 are 28%, 22%, and 20%. Which side has greater IV? **Answer:** The lower-strike side; this is downside skew in the example.
2. If 30-day IV is 20% and 90-day IV is 24%, compute the simplified 30-to-90-day forward IV. **Answer:** `sqrt((90×0.24² − 30×0.20²)/60) ≈ 25.8%`.
3. A contract's bid is $0 and ask is $4 while nearby strikes have tight markets. Should it be used uncritically in a smooth IV curve? **Answer:** No. Flag it under a written quote-quality rule and investigate; a model IV from an unusable quote may distort the chart.
4. Does a steep put skew prove puts will earn positive returns if sold? **Answer:** No. You need a net, risk-aware forecast tested against actual outcomes and tail losses.
5. Under the calendar model above, the 30-day $100 call costs $5.50 and the 90-day $100 call costs $4.80, each with multiplier and deliverable 100. Identify the failed condition and opening credit. The short is assigned at a $115 stock value; find cash and shares excluding the initial credit. Show the final cash including the credit if the stock is $125 or $90 at the later expiry. **Answer:** The later call is $0.70 cheaper, violating the qualified maturity check. Sell near/buy far gives `$70` credit. Assignment leaves `$10,000` cash, `−100` shares, and the long call; it does not exercise the long. At $125, exercising the long for $10,000 closes the shares and leaves `$70`. At $90, buying shares for $9,000 closes the short, the long expires, and cash is `$1,000 + $70 = $1,070`. The proof assumes zero rates/costs, no dividends, and frictionless borrowing/funding; it does not establish an executable real trade.
6. In the qualified comparison, 30-day IV is 40% and 90-day IV is 30%. Is the lower later IV sufficient to flag calendar arbitrage? **Answer:** No: total variances are `4.80` and `8.10` day-variance units, so they increase. Check comparable terms, forward moneyness, prices, and the model's assumptions rather than the IV ordering alone.

**Pass gate:** Deliver two reproducible charts with raw quotes, timestamps, contract specifications, and at least five data/model caveats. Explain the forward-variance arithmetic without claiming it forecasts realized volatility. Check at least one cleaned same-expiry call slice for strike monotonicity and convexity, and investigate any violation before interpreting it. Complete the calendar transfer case with correct opening credit, assignment cash/shares, surviving long leg, and both later outcomes. State all assumptions and why falling annualized IV alone is insufficient. Correct errors in a fresh changed-number case before advancing.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Test strikes 40/50/60 with reference calls 12/7/3. Compute the butterfly cost and say whether negative-cost convexity arbitrage is shown.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The convexity alarm

**Fictional teaching case.** A fictional analyst receives same-expiry European call reference prices at equally spaced strikes and fits a smooth surface without checking convexity. A colleague spots a suspicious middle strike.

Same underlying/time/expiry; strikes $90/$100/$110; supplied frictionless reference call prices $13/$10/$4. Zero rates/dividends for the exercise. A long butterfly uses +1 low-strike call, −2 middle calls, +1 high call, each with a 100 multiplier.

### Initial decision

Compute the butterfly reference cost and terminal payoff at stock $80/$100/$120. Explain why the result flags a convexity violation in this stipulated frictionless model.

### New information — commit your first decision before reading

Executable sides are low ask $14, middle bid $8 and high ask $5. Recompute the package entry debit and reassess the executable arbitrage claim.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The convexity alarm'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Reference cost is 13−2×10+4=−$3 per share: a $300 credit for a nonnegative terminal payoff. At $80/$100/$120 the butterfly payoff is $0/$1,000/$0. This violates convexity under the common assumptions. Actual quote-side entry is 14−2×8+5=$3 debit per share, or $300, so the reference discrepancy does not survive these executable sides. Stale quotes, product differences and costs also need checking. The diagnostic is valuable even when no implementable arbitrage remains.

### Weak — unsupported submission

A surface plot looks smooth, so no-arbitrage checks are unnecessary. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Reference cost is 13−2×10+4=−$3 per share: a $300 credit for a nonnegative terminal payoff. At $80/$100/$120 the butterfly payoff is $0/$1,000/$0. This violates convexity under the common assumptions. Actual quote-side entry is 14−2×8+5=$3 debit per share, or $300, so the reference discrepancy does not survive these executable sides. Stale quotes, product differences and costs also need checking. The diagnostic is valuable even when no implementable arbitrage remains. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The reference butterfly earns a $300 entry credit under idealized assumptions, but quote-side execution costs $300. I flag the data/model inconsistency without claiming an executable free profit.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Use no-arbitrage checks as qualified diagnostics rather than casual execution claims. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The convexity alarm'. Compute the butterfly reference cost and terminal payoff at stock $80/$100/$120. Explain why the result flags a convexity violation in this stipulated frictionless model.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Test strikes 40/50/60 with reference calls 12/7/3. Compute the butterfly cost and say whether negative-cost convexity arbitrage is shown.
- Teach the central distinction of 'The convexity alarm' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OIC explains historical and implied volatility](https://www.optionseducation.org/advancedconcepts/volatility-the-greeks)
- [Cboe's DataShop description](https://datashop.cboe.com/option-eod-summary)
- [Gatheral and Jacquier derive the more general calendar condition at fixed forward moneyness](https://arxiv.org/abs/1204.0646)

## Module 20: Where could an option return come from?

Compare competing economic explanations for observed returns.

Stage: Research, portfolio policy and defense. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 19.

### Decision, intuition and learning outcome

## Begin with a decision

A positive average can reflect compensation for bearing an undesirable state, a measurement choice, or a durable forecasting advantage. These explanations have different implications for capital and persistence. A convincing memo tries to discriminate among them.

**Learning outcome:** Compare competing economic explanations for observed returns.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

Before testing a strategy, ask who is paying whom, for what risk, and why the opportunity might persist. An option position can earn or lose from several sources at once: the underlying's direction, realized movement versus IV, the changing price of insurance, time decay, dividends, interest, execution costs, and the way exposure is hedged. “Theta is positive” describes one sensitivity; it does not explain net expected profit.

Imagine a hypothetical short-option setup with a 90% chance of gaining $40 and a 10% chance of losing $500. Its expected result before costs is `0.90×40 + 0.10×(−500) = −$14` per trade. A 90% win rate can coexist with negative expectancy. If entering and exiting costs $6, expected net result is `−$20`. The numbers are invented, but the arithmetic is the discipline: list *all* outcomes, including rare ones. If probabilities are estimated from a small, calm period, stress them. For instance, a 15% loss probability changes the expectation to `0.85×40 − 0.15×500 = −$41` before costs.

Why might options sometimes have a premium? Insurance demand can make protection valuable; traders who absorb that risk may be compensated. But compensation for bearing crash risk is different from a free arbitrage. Other traders compete for the same premium. Hedging, capital, and liquidity costs can consume it. A [Dew-Becker and Giglio paper](https://www.nber.org/papers/w31833) reports a narrowing variance risk premium over the last 15 years of its sample, which ended in 2022. That is a historical finding, not a present-day trade instruction. The [original variance-risk-premium research](https://academic.oup.com/rfs/article-abstract/22/3/1311/1581057) is a starting point for understanding the mechanism.

Separate three questions in every research memo. **Mechanism:** Why would someone pay for the exposure? **Measurement:** What observable data would show you the premium existed? **Competition:** Why would the premium remain after market participants notice it? Then write a disconfirming explanation. A profitable backtest might simply have held a bull-market stock exposure, sold expensive-to-hedge crash insurance, or assumed fills that nobody could obtain. Compare it with cash, owning the underlying, or a simpler option strategy before celebrating an apparent edge.

**Common mistake:** calling premium collected “income” while ignoring the open liability. A credit received is a cash flow at entry; the final profit depends on the liability's value and what happens at exercise, assignment, or closeout.

### Four-week practice

| Week | Work for the 10 hours | Evidence |
| --- | --- | --- |
| 77 | Make a list of possible option return drivers and explain each in one sentence. | Mechanism map. |
| 78 | Work 20 expected-value problems with varied win rates and tail losses. Include fees. | Worked calculations and corrected errors. |
| 79 | Read one original paper and one exchange methodology; distinguish data finding from the authors' interpretation. | Two-page literature memo. |
| 80 | Write three competing explanations for one hypothetical strategy's backtest. | A mechanism, measurement, competition, and failure memo. |

### Try it, then check

1. A strategy wins $60 on 8 of 10 opportunities and loses $280 on 2. Average before costs? **Answer:** `0.8×60 − 0.2×280 = −$8` per opportunity.
2. If that strategy costs $5 per round trip, average net result? **Answer:** `−$13`.
3. Why is positive theta insufficient to establish an edge? **Answer:** Delta, gamma, vega, jumps, fees, and other exposures can outweigh time decay; theta is a local model sensitivity.
4. Name a fair comparator for a bullish call strategy. **Answer:** At minimum, a scaled underlying-stock position or cash, aligned by capital and risk; the exact comparator must be fixed before viewing results.

**Pass gate:** Submit a memo with one proposed mechanism, two plausible rival explanations, a fair benchmark, and a calculation that includes tail outcomes and costs.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Create two ten-period payoff series with equal totals but different loss concentration. Which additional statistics and stakeholder facts would you request?

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: Return or insurance compensation?

**Fictional teaching case.** A fictional short-option presentation reports $1,100 net profit over ten months and labels it skill. Nine months earned $300 each and one month lost $1,600. A treasury member values protection during the loss state.

All ten supplied amounts are fictional net monthly outcomes for the illustration. Initial capital, leverage, intermediate equity and comparator exposure must still be specified. No unobserved trade details may be invented.

### Initial decision

Reconcile the total, identify at least three plausible explanations and propose evidence that could distinguish a forecasting edge from compensation for tail exposure.

### New information — commit your first decision before reading

The loss month coincides with the sponsor’s largest business cash need. Explain why the same historical average could be unattractive for this sponsor even if the return premium were persistent.

### Defense

- What is the strongest reason to disagree with your recommendation in 'Return or insurance compensation?'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Nine wins contribute $2,700; one loss removes $1,600, leaving $1,100. That total alone cannot identify skill. Explanations include priced insurance/tail exposure, favorable sample selection and a genuine information advantage. Examine economic counterparties, risk-matched comparators, costs, full search history and later performance. For a sponsor needing cash in the bad state, the timing of losses matters; average profit can conflict with the mandate. The memo should distinguish this suitability judgment from an unsupported claim that the measured premium is mispricing.

### Weak — unsupported submission

Positive total profit proves an inefficiency that should continue. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Nine wins contribute $2,700; one loss removes $1,600, leaving $1,100. That total alone cannot identify skill. Explanations include priced insurance/tail exposure, favorable sample selection and a genuine information advantage. Examine economic counterparties, risk-matched comparators, costs, full search history and later performance. For a sponsor needing cash in the bad state, the timing of losses matters; average profit can conflict with the mandate. The memo should distinguish this suitability judgment from an unsupported claim that the measured premium is mispricing. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

The $1,100 total is consistent with several economic stories. I would test risk-matched alternatives and stress-state cash needs before calling it skill or recommending it for the sponsor.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Compare competing economic explanations for observed returns. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'Return or insurance compensation?'. Reconcile the total, identify at least three plausible explanations and propose evidence that could distinguish a forecasting edge from compensation for tail exposure.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Create two ten-period payoff series with equal totals but different loss concentration. Which additional statistics and stakeholder facts would you request?
- Teach the central distinction of 'Return or insurance compensation?' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [Dew-Becker and Giglio paper](https://www.nber.org/papers/w31833)
- [original variance-risk-premium research](https://academic.oup.com/rfs/article-abstract/22/3/1311/1581057)

## Module 21: Write the test before seeing the result

Preregister an auditable question at an honest data-evidence level.

Stage: Research, portfolio policy and defense. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 20.

### Decision, intuition and learning outcome

## Begin with a decision

Research begins by matching the claim to observable evidence. Synthetic ledgers can establish software behavior; published indices can support methodology-aware comparisons; historical contract execution needs appropriate contract records. A narrow feasible question is stronger than an ambitious untestable claim.

**Learning outcome:** Preregister an auditable question at an honest data-evidence level.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

Researchers can accidentally fool themselves by trying many rules and publishing only a winning one. Suppose you try three entry times, four expirations, and five exit rules. That is `3×4×5 = 60` variants, even before choosing an underlying or risk limit. The best historical result among 60 is likely to contain luck. This is **selection bias**. Bailey and coauthors show why backtest selection can overfit even with seemingly sensible holdout methods. Read their [original paper](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2326253) as you design a protocol.

A **falsifiable hypothesis** specifies a mechanism and a result that would count against it. A vague claim such as “buy cheap options” cannot be tested until “cheap,” “buy,” universe, dates, and outcomes are defined. A useful example is an *educational hedge study*: “For a hypothetical portfolio of index shares, a fixed monthly protective-put rule reduces worst drawdown during the test period, after full option costs, compared with unhedged shares; the reduction is worth the premium cost under a prespecified score.” This is a question to investigate, not a recommendation to buy puts. It requires exact strikes, dates, decision times, contracts, benchmark, and score.

Write a dated protocol for the chosen evidence level. For A/C, specify the **contract universe**, **signal**, **entry and exit** including nonfills and expiration, **risk**, **cost model**, **benchmark**, **primary metric**, **development period**, and **reserved final period**. Define missing-quote, split, holiday, and outage behavior. For B, specify published index and comparator series, methodologies, date alignment, primary comparison, known fee and financing assumptions, revision handling, and a later publication period only if you can genuinely reserve one. Exploring data to learn its structure is allowed; claiming a confirmatory test after you have seen its outcome is not.

Before freezing that protocol, complete a **data feasibility decision**. Record the data source, access and license, fields, timestamps or publication dates, coverage, relevant adjustment or methodology history, costs, and whether another person can reproduce the work. Choose level A, B, or C from the [lab's capstone table](labs/README.md). A published index series supports a descriptive comparison, but cannot supply missing option-order prices or prove a trade-by-trade backtest. A synthetic fixture can prove that your code accounts for specified cases, but cannot measure a market edge. If level C data are unavailable, write a protocol that makes a narrower claim at level A or B.

Imagine a signal generated from a 4:00 p.m. closing value. A protocol that fills an option at that same 4:00 p.m. quote may be using information that did not exist when the order would have been sent. The test must enter later or demonstrate an actual decision and execution sequence that could have occurred. This is **look-ahead bias**. In options, stale quotes, contract changes, and notional size make it easy to miss.

**Common mistake:** changing the main metric after seeing losses. A strategy can have high Sharpe, low drawdown, or high win rate by chance. Select a primary decision rule first, then report all relevant secondary outcomes honestly.

### Four-week practice

| Week | Work for the 10 hours | Evidence |
| --- | --- | --- |
| 81 | Rewrite three vague claims as falsifiable hypotheses and choose evidence level A, B, or C after checking data, access, cost, and auditability. | Before/after statements and a data feasibility sheet. |
| 82 | A/C: specify contract rules, decision times, and available fields. B: specify index/comparator sources, publication dates and methodologies. | Draft level-appropriate protocol. |
| 83 | Choose benchmark, observable costs, genuinely reserved dates if available, and stopping rules; count every variant tried. | Frozen protocol v1 and trial ledger. |
| 84 | Have a peer or the assistant challenge ambiguity and timing. Correct it before any genuinely unseen final test. | Dated protocol v2 and change log. |

### Try it, then check

1. How many variants are three entry times × four expirations × five exits? **Answer:** 60; record all of them, not just the winner.
2. Is “sell options when IV is high” testable as written? **Answer:** No. Define IV calculation, threshold, option type, selection, size, entry, exit, costs, and outcome.
3. A signal requires the 4:00 close. Can a backtest assume a fill at the 3:45 quote? **Answer:** No; the signal uses future information relative to that quote.
4. When should the untouched final period be examined? **Answer:** After development choices and the decision rule are frozen; examining it repeatedly turns it into development data.

**Pass gate:** A reader can implement the protocol without asking you to invent missing rules or inaccessible data. It identifies evidence level, source rights and observation or publication dates, one primary metric, an honest comparator, and a complete variant log. A/C reserve genuinely unseen cases or historical observations; B labels already public history descriptive and reserves later publications only where possible.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Draft one falsifiable A-level accounting question and one B-level published-index comparison with different pass/failure evidence.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: Choose the question the evidence can answer

**Fictional teaching case.** A fictional student has a synthetic option simulator and daily published buy-write index levels. The proposed thesis promises to prove that a particular contract selection rule would have been profitable after actual fills.

Budget allows no historical option quote purchase. Public index methodology and total-return comparator history are accessible. The student has already plotted all available index dates, so none of those inspected dates is an untouched holdout.

### Initial decision

Rewrite the project as a feasible A or B study, preregister the comparator, alignment rules, costs/unknowns, variants and failure criteria, and state the permitted conclusion.

### New information — commit your first decision before reading

A free CSV appears with daily option last prices but no bid/ask timestamps or corporate-action documentation. Decide whether it upgrades the project to a credible execution replay.

### Defense

- What is the strongest reason to disagree with your recommendation in 'Choose the question the evidence can answer'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

A level A project can validate synthetic accounting against independently specified expected cases. A level B project can compare published index and benchmark histories with explicit methodology assumptions, dates and drawdowns. Neither reconstructs the original contract trades or establishes account-level execution. Already inspected index dates remain descriptive. A last-price file without the needed timing/quote and contract context does not by itself support executable fill claims. Preserve the question version and improve data feasibility before making a stronger promise.

### Weak — unsupported submission

A public index chart proves my contract selector achieved its returns after costs. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

A level A project can validate synthetic accounting against independently specified expected cases. A level B project can compare published index and benchmark histories with explicit methodology assumptions, dates and drawdowns. Neither reconstructs the original contract trades or establishes account-level execution. Already inspected index dates remain descriptive. A last-price file without the needed timing/quote and contract context does not by itself support executable fill claims. Preserve the question version and improve data feasibility before making a stronger promise. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

I scope a published-series comparison with known methodology limits and label the inspected history descriptive. I decline contract-execution claims until suitable point-in-time evidence exists.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Preregister an auditable question at an honest data-evidence level. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'Choose the question the evidence can answer'. Rewrite the project as a feasible A or B study, preregister the comparator, alignment rules, costs/unknowns, variants and failure criteria, and state the permitted conclusion.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Draft one falsifiable A-level accounting question and one B-level published-index comparison with different pass/failure evidence.
- Teach the central distinction of 'Choose the question the evidence can answer' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [original paper](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2326253)

## Module 22: Build auditable research at the chosen data level

Reconcile historical or synthetic accounting with information available at each decision.

Stage: Research, portfolio policy and defense. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 21.

### Decision, intuition and learning outcome

## Begin with a decision

A historical replay is an event-time ledger. It must distinguish a quote, an order intention, a permitted fill and the subsequent mark. Profitable endpoints cannot excuse an exit rule that uses information from the future.

**Learning outcome:** Reconcile historical or synthetic accounting with information available at each decision.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

A backtest is a historical simulation of rules. Its job is to ask what would have happened *if* you had followed a rule with the information and prices then available. It is not a time machine. An option's last trade may be stale, a displayed midpoint may not fill, and a closing price cannot be used before it is known. The [research lab](RESEARCH_LAB.md) gives the complete data manifest and accounting checks. **Level C** requires these contract-level replay checks. At **level A**, demonstrate those controls on explicitly synthetic inputs and report only software behavior. At **level B**, compare published histories and their methodologies, without inventing missing fills or a fictional contract ledger. The [lab](labs/README.md) provides level A's initial fixture and tests.

Beginning this module, keep a separate **forward record** under the frozen rules through Module 26. For level C, timestamp each real new signal, no-signal day, quote, and assumed or paper fill; compare them with historical assumptions. For level B, record the dates and versions of newly published index observations and methodology changes. For level A, add previously unseen synthetic cases and preserve original outputs. Do not describe level A or B as forward evidence for an executable trading edge.

For levels A and C, begin with a **trade ledger**, one row per hypothetical action: decision timestamp, exact option symbol, underlying, strike, expiration, multiplier, bid/ask, order side, assumed fill, quantity, fees, assignment or settlement, and resulting cash and position. Keep unfilled orders and rejected signals as rows too. Otherwise the backtest silently selects easy fills. Use quotes from the correct time and quote side as one conservative case. If the option is offered at $2.20 and bid at $2.00 at entry, a long buyer normally pays at most the chosen limit, not the $2.10 midpoint by default. Suppose at exit the bid/ask is $2.90/$3.10. Buying at $2.20 and selling at $2.90 gives `($2.90−$2.20)×100=$70` before fees. A midpoint-only simulation would show `($3.00−$2.10)×100=$90`, overstating this example by $20. With $2 total fees, the conservative net is $68. Real execution can be better or worse; the purpose is to expose assumptions.

For each date, reconcile `ending equity = starting cash + all cash flows + value of open positions`, under a stated marking rule. An option bought costs cash; it is also an asset while open. When it expires, exercise or cash settlement must follow its exact contract terms. Adjusted stock options can deliver something other than 100 shares. If the code treats every option as standard, its results can be wrong even if its signal is clever. The [OCC disclosure document](https://www.theocc.com/company-information/documents-and-archives/options-disclosure-document) explains why exercise and settlement terms matter.

Two quick checks catch many errors. First, hand-calculate several trades from the ledger and compare with code. Second, run a **no-signal test**: if your system executes trades with the signal switched off, the simulator is broken. Also inspect performance under optimistic, base, and adverse modeled fills. An optimistic midpoint fill remains an assumption until independent execution evidence supports it. A small slippage change that erases apparent profit is an important result, not a nuisance to hide.

**Common mistake:** marking an entry at the bid when you are buying and an exit at the ask when you are selling. That reverses the market sides and creates imaginary profits.

### Four-week practice

| Week | Work for the 10 hours | Evidence |
| --- | --- | --- |
| 85 | Confirm the level A/B/C data manifest and its permitted claim. For C, inspect 10 raw contract-days, including an event and expiration. | Source and coverage statement; C adds quote QA log. |
| 86 | For A/C, implement cash flows and exact contract terms before the signal. For B, reproduce the published methodology and align comparator dates. | A/C hand-reconciled examples; B methodology and benchmark reconciliation. |
| 87 | For A/C, implement entry, exit, nonfill, fee, and assignment assumptions under three fill cases. For B, audit index construction and published return comparisons. | Ledger and cost table or published-index comparison. |
| 88 | Reproduce from saved inputs, hand-check sample rows, write discrepancies, and continue the level-appropriate forward record. | Versioned report with its evidence-level label. |

### Try it, then check

1. Using the entry and exit quotes above, what is conservative long-option P&L before and after $2 fees? **Answer:** $70 before fees and $68 after fees.
2. What would midpoint-only P&L be, and how much more is it? **Answer:** $90, which is $20 more than the quote-side example before fees.
3. A daily dataset includes a 16:00 closing price; the rule supposedly traded at 15:45 based on it. What is wrong? **Answer:** It uses future information at the decision time.
4. A short American-style stock option is assigned. Can the ledger simply erase the option and leave no other position? **Answer:** No. It must record the resulting share and cash obligation under the contract terms.

**Pass gate:** Another person can reproduce the report. Level A: reconcile the synthetic ledger, rejected quotes, nonfills, and three modeled fill cases without claiming market performance. Level B: reproduce the published comparison and explain index assumptions without claiming contract fills. Level C: reproduce historical contract selection and ledger, hand-check samples, identify exclusions and unfilled orders, and recompute under three fill cases. A C project may require more than four weeks or a different dataset if the required fields are unavailable.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Use entry ask $1.80, $0.65 entry fee and a confirmed exit $1.95 with $0.65 fee. Compute net P&L and name the evidence behind each cash-flow line.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The replay with an impossible exit

**Fictional teaching case.** A fictional level C study buys one call at the ask and says it exits at the next observed bid. The analyst fills a missing exit quote using the next day’s favorable closing mark, then claims a same-day realized gain.

Teaching fixture: entry ask $2.40 at 10:00, standard multiplier 100, entry fee $1. At planned 15:00 exit the bid is unavailable. Next day 16:00 a reference mark is $3.00, but no order/fill report is supplied. This fixture is invented and not actual market history.

### Initial decision

Write the account and unresolved-exit record. State which net result can be computed and which remains unknown; specify an adverse-exit sensitivity policy before evaluating it.

### New information — commit your first decision before reading

An independently supplied exit fill report later confirms $2.10 with a $1 fee at 15:05. Reconcile realized P&L using that report and preserve the earlier unknown state.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The replay with an impossible exit'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Initial cash outflow is $241 including entry fee. A later $3 reference mark does not establish an earlier $300 sale. Until a valid exit observation or modeled policy exists, the exit is unresolved and no realized profit can be asserted. The confirmed $2.10 fill receives $209 after the exit fee, so realized net is $209−$241=−$32. Preserve both records and the reason the conclusion changed. Sensitivity cases must be explicitly modeled, not mislabeled as actual fills.

### Weak — unsupported submission

Use tomorrow’s $3 mark as today’s exit because the planned quote is missing. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Initial cash outflow is $241 including entry fee. A later $3 reference mark does not establish an earlier $300 sale. Until a valid exit observation or modeled policy exists, the exit is unresolved and no realized profit can be asserted. The confirmed $2.10 fill receives $209 after the exit fee, so realized net is $209−$241=−$32. Preserve both records and the reason the conclusion changed. Sensitivity cases must be explicitly modeled, not mislabeled as actual fills. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

I retain the option and unresolved exit until valid evidence arrives. The later confirmed $2.10 exit gives −$32 net; I distinguish this realized fixture result from any modeled sensitivity.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Reconcile historical or synthetic accounting with information available at each decision. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The replay with an impossible exit'. Write the account and unresolved-exit record. State which net result can be computed and which remains unknown; specify an adverse-exit sensitivity policy before evaluating it.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Use entry ask $1.80, $0.65 entry fee and a confirmed exit $1.95 with $0.65 fee. Compute net P&L and name the evidence behind each cash-flow line.
- Teach the central distinction of 'The replay with an impossible exit' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [OCC disclosure document](https://www.theocc.com/company-information/documents-and-archives/options-disclosure-document)

## Module 23: Try to break your own result

Evaluate robustness while preserving the full research history.

Stage: Research, portfolio policy and defense. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 22.

### Decision, intuition and learning outcome

## Begin with a decision

A robustness check asks whether a conclusion survives plausible changes; it is not permission to keep changing the strategy until the final period looks good. Development choices and genuinely later evaluation must stay distinguishable.

**Learning outcome:** Evaluate robustness while preserving the full research history.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

A historical result can fail because a strategy was tuned to one period, one stock, one market regime, or one optimistic cost assumption. **Robustness testing** asks whether the result persists when reasonable conditions change. It does not mean endlessly adjusting the rule until a chart looks smooth. In Module 21 you froze a protocol and, where possible, reserved a final period. Now run the development and validation checks you declared, record *every* variation, and open a genuinely reserved final period only when the rule is frozen. Level A tests simulator behavior under new inputs. Level B checks published-index comparisons across dates, regimes, methodology assumptions, and comparator choices. A public history already examined is descriptive; track later published observations for new evidence. Level C tests the historical contract rule and its costs.

Split dates in time order. Randomly mixing days can leak information because options and market states are related across adjacent dates. If positions overlap, a single market event may affect several trades. Those trades are not fully independent observations. Separate a development period for designing the rule, a validation period for checking it, and a final later period for one honest evaluation. For level C, report each period's dates, opportunity count, net return, worst drawdown, and cost assumptions. For level B, report the published series' dates, methodology and comparator changes, returns and drawdowns. For level A, report case coverage and failures instead of a market return. If you change a rule after seeing a final result, that segment becomes development; you need new unseen cases or observations for a fresh final test.

Consider a toy result: 40 trades average **+$4** net per trade with a standard deviation of **$60**. If trades were independent and sufficiently well behaved, the standard error of the mean would be `60 ÷ sqrt(40) ≈ $9.49`. A rough 95% normal interval is `$4 ± 1.96×$9.49`, or about **−$14.60 to +$22.60** per trade. That wide interval does not establish a positive mean. Overlapping trades, fat tails, and selection of the best variant make this simple interval too optimistic; use it as a warning about uncertainty, not as a full statistical verdict. The [MIT probability course](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/pages/syllabus/) provides the formal inference background after its calculus prerequisite.

The [statistics lab](labs/README.md) supplies a dated artificial P&L series, a separate synthetic benchmark column, a complete toy trial log, and a reserved final forecast file. Compare the independent-trade calculation above with moving-block intervals on a portfolio time series, then vary block length. Exclude event outcomes that cross a training/evaluation boundary. Score a dated probability forecast with the Brier score against a baseline estimated only on development data. Forecast quality is a separate question from whether an option can be traded profitably. An illustrative interval from a tiny synthetic sample cannot justify a market claim.

Change assumptions for a reason: double estimated slippage, remove the best five days, inspect crisis and quiet periods, shift the entry time to a feasible next quote, and vary strike or maturity slightly. If profitability requires one exact parameter or disappears under a small adverse fill, the claimed edge is fragile. Keep the failed versions in the record. The [backtest-overfitting paper](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2326253) is a reminder that multiple tests increase the chance of a lucky winner.

The preceding strike, fill, and trade examples apply to level C and to synthetic simulator checks at level A. At level B, vary the published-index date window, benchmark, cash yield, fees stated in the methodology, and treatment of any methodology revision. Level B cannot recover a missing constituent-level trade ledger from index values. Across all levels, preserve every attempted choice and disclose what the available observations cannot resolve.

**Common mistake:** saying “40 profitable trades prove it.” A trade count ignores the range and dependence of outcomes, the size of losses, and how many variants were tried before those 40 were chosen.

### Four-week practice

| Week | Work for the 10 hours | Evidence |
| --- | --- | --- |
| 89 | Check chronological splits and all trial versions; A/C also check overlapping events where applicable. Continue the level-appropriate forward record. | Timeline and experiment ledger. |
| 90 | A: mutate input and cost assumptions. B: vary benchmark and methodology assumptions. C: test fees, fills, and nearby parameters. | Sensitivity table with failures. |
| 91 | A: report case coverage. B: compare published periods and regimes. C: report by year, event, tenor, and liquidity group. | Coverage or regime report with sample sizes. |
| 92 | A/C: open the reserved segment once. B: open a genuinely reserved later publication period if available; otherwise label the existing history descriptive. Continue the forward record. | Signed evaluation or descriptive report with evidence-level label. |

### Try it, then check

1. Compute `60 ÷ sqrt(40)` to two decimals. **Answer:** About $9.49.
2. Does a mean of +$4 with that standard error prove positive expected P&L? **Answer:** No. The approximate interval includes negative values, and the assumptions may fail.
3. You change the exit rule after viewing the final period and rerun on the same dates. Is it still an untouched test? **Answer:** No. Those dates helped choose the new rule.
4. A result comes only from one unusually profitable week. What should you report? **Answer:** The concentration, sample size, net results with and without the week, and the fact that the strategy's generality is unproven.

**Pass gate:** All levels preserve tried variants, dated splits, sensitivity results, and a candid conclusion. A demonstrates simulator and analysis behavior under unseen synthetic cases. B quantifies published-history and comparator sensitivity, stating methodology and trade-data limits; claim an untouched test only if later public observations were genuinely reserved. C adds an untouched historical segment, adverse fills, concentration, dependence-aware uncertainty, and a conditional contract-level estimate. A/C show overlapping-event exclusion where applicable; B explains dependence in the published return series without inventing trade events.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** A researcher reports a positive median across parameters but hides the chosen rule’s poor later result. Which record is missing and how would you separate robustness from selection?

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The winning variant is not the frozen variant

**Fictional teaching case.** A fictional team freezes Variant A, then observes a −2% result in its reserved period. After seeing the result it changes the threshold to Variant B, which earns +4% over the same dates, and reports B as successful validation.

Earlier development tried 12 variants, including A and nearby thresholds. Both reserved-period percentages use the same starting capital, dates and stated net-cost convention. No genuinely later B observations have yet been collected.

### Initial decision

Write the audit conclusion for A and B. Specify what should remain in the trial log and what later evidence would support a fair evaluation of B.

### New information — commit your first decision before reading

An adverse cost sensitivity reduces B from +4% to −1%. The team proposes removing that cost case as unrealistic without supplying execution evidence. Respond as reviewer.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The winning variant is not the frozen variant'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

A produced −2% on the frozen evaluation under the stated convention. B’s +4% is post-selection development evidence because the period informed the change. Both results and all twelve earlier variants belong in the log. B needs a newly frozen method and genuinely later evaluation; no label can recover the consumed holdout. The −1% adverse-cost case is material sensitivity unless better documented evidence justifies excluding it. A defensible conclusion can be reject or inconclusive without failing the quality standard.

### Weak — unsupported submission

Choose B and call its +4% a holdout result because the dates are unchanged. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

A produced −2% on the frozen evaluation under the stated convention. B’s +4% is post-selection development evidence because the period informed the change. Both results and all twelve earlier variants belong in the log. B needs a newly frozen method and genuinely later evaluation; no label can recover the consumed holdout. The −1% adverse-cost case is material sensitivity unless better documented evidence justifies excluding it. A defensible conclusion can be reject or inconclusive without failing the quality standard. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

A failed its frozen period; B has a post-selection result and cost sensitivity crossing zero. I preserve every variant and seek later evidence under a newly frozen protocol.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Evaluate robustness while preserving the full research history. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The winning variant is not the frozen variant'. Write the audit conclusion for A and B. Specify what should remain in the trial log and what later evidence would support a fair evaluation of B.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- A researcher reports a positive median across parameters but hides the chosen rule’s poor later result. Which record is missing and how would you separate robustness from selection?
- Teach the central distinction of 'The winning variant is not the frozen variant' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [MIT probability course](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/pages/syllabus/)
- [backtest-overfitting paper](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2326253)

## Module 24: Risk belongs to the whole portfolio

Aggregate correlated losses and reconcile both equity and funding under stress.

Stage: Research, portfolio policy and defense. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 23.

### Decision, intuition and learning outcome

## Begin with a decision

Portfolio risk is determined by shared states, not the number of tickets. Group share-equivalent deltas by underlying. For a joint scenario, calculate each underlying’s dollar effect, then combine those effects and check the funding requirement. A policy must be checked at the portfolio level before adding a new position.

**Learning outcome:** Aggregate correlated losses and reconcile both equity and funding under stress.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

A position can be small by itself and large as part of a portfolio. Two option trades tied to the same index may both lose in a crash. A portfolio risk report adds exposures by underlying, sector, expiry, and the market events that move them together. It also asks how much cash or stock exercise and assignment could require. Risk is a path through time, not only a line at expiration on a payoff chart.

Consider two hypothetical standard five-point-wide vertical credit spreads, each opened for a $1 credit. For an **intact**, standard, one-to-one spread with matching expiry and deliverable, theoretical maximum expiration loss per spread is `(5−1)×100 = $400`, before fees. Two could lose **$800** together. In a $20,000 practice account that is **4%** of equity. Under the sample [risk policy](RISK_AND_OPERATIONS.md) of at most 1% aggregate modeled loss, the limit is $200, so even one such contract would fail the rule. Do not divide correlated risk by two merely because there are two tickets. Assignment, after-hours movement, fees, and forced liquidation can add funding and execution complications beyond an intact-spread diagram.

The **Greeks** summarize local sensitivities. If two positions on stock ALFA have a combined delta of **+40 ALFA-share equivalents**, a $5 decline per ALFA share suggests about `40×(−$5)=−$200` from delta *at the starting point*. Gamma changes delta as price moves; vega changes value as IV moves; quotes may widen. A stress test therefore reprices all positions under several simultaneous changes. Include a down gap with IV rising, an up gap with IV falling, time passing, a dividend or earnings event, a liquidity squeeze, and one-leg assignment. Calculate both mark-to-market loss and the cash/share obligation. [Cboe describes price, volatility, time, and historical-event stress](https://www.cboe.com/solutions/options-analytics/portfolio-margin-analytics/stress-tests/). [OCC's STANS](https://www.theocc.com/risk-management/margin-methodology) is an institutional example of portfolio scenario thinking; its clearing-member margin method is not a personal safety threshold.

A conservative risk limit cannot make a bad strategy good, but it can prevent a learning account from depending on one event. Set limits in cash terms and check the **smallest contract**. If one contract exceeds the limit, the valid action is to stay in simulation. Do not invent a higher limit to fit the trade. Record decisions *not* to trade, because restraint is part of the process you are auditing.

For A/C, use the [lab's standard-European stress function](labs/README.md) as a starting calculation, then build a separate cash/share ledger for exercise and assignment. Test eight joint price, IV, time, and liquidity changes; include a full underlying wipeout as a severe boundary case for puts. The simple pricer does not model a volatility surface, broker margin, dividends, or American exercise. Report those omissions next to the results and use actual product specifications when moving beyond the teaching fixture. For B, analyze published index drawdown and stress periods, then complete a clearly separate hypothetical portfolio stress exercise for assignment and funding practice.

**Common mistake:** summing theoretical max losses while ignoring the temporary shares, margin, or liquidity needed if a short American-style leg is assigned. The [FINRA assignment guide](https://www.finra.org/investors/insights/trading-options-understanding-assignment) provides concrete cases.

### Four-week practice

| Week | Work for the 10 hours | Evidence |
| --- | --- | --- |
| 93 | A/C: map specified portfolio positions and exposures. B: identify published index risk exposures and data limits. Continue the level-appropriate record. | Exposure or methodology map. |
| 94 | A/C: hand-calculate position loss and funding in eight scenarios. B: locate stress periods in index history and begin a separate hypothetical portfolio exercise. | Scenario worksheet with source label. |
| 95 | A/C: add correlated gaps, IV shocks, wider spreads, and funding needs. B: test index/comparator sensitivity and finish the hypothetical portfolio exercise. | Revised stress table with limitations. |
| 96 | A/C: write a limit-breach response. B: explain index risks and what an account-level limit would still need. Practice the end-of-day check on the hypothetical portfolio. | Written risk response and checklist. |

### Try it, then check

1. What is the theoretical expiration loss of one five-point credit spread sold for $1, assuming standard matching legs? **Answer:** `(5−1)×100 = $400`, before fees.
2. What is the aggregate for two, and what percent of $20,000 is it? **Answer:** $800, or 4%.
3. Does a net delta of +40 guarantee only $200 loss after a $5 downward gap? **Answer:** No. It is a local approximation; gamma, IV, time, and execution also change.
4. If a rule permits $200 aggregate modeled loss but the smallest contract risks $400, what does the rule imply? **Answer:** Do not open it under that policy; continue in simulation or study a different exposure.

**Pass gate:** A and C reproduce eight joint-shock scenarios on a specified synthetic or historical portfolio, account for assignment and cash needs, show concentration, and state an action before each risk limit is crossed. B reports the published index's observed drawdowns and stress periods, explains what its methodology can reveal, and marks assignment funding and executable exit prices as unobservable from index values alone. B also completes a separately labeled hypothetical portfolio stress exercise for operational learning, with no claim that it reconstructs the index.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Create eight named joint shocks covering price, IV, time, liquidity and assignment. Identify which require repricing, which require a cash ledger and which remain unquantified.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: Two small tickets, one large shock

**Fictional teaching case.** A fictional $20,000 portfolio contains two matching five-point credit spreads opened for $1 each. Both depend on stock ALFA and the same expiry. The manager describes them as diversified because they were opened on different days.

Each spread has one short and one long standard ALFA put with matching expiration. Each contract has a multiplier of 100 and physically settles into 100 ALFA shares. Ignore fees. The aggregate modeled-loss limit is $200. Together the two spreads currently have delta +40 ALFA-share equivalents.

Separately, a proposed two-stock portfolio has delta +40 ALFA-share equivalents and −10 BRAVO-share equivalents. A manager asks for its dollar response to a 1% rise in a broad market index. The memo includes neither stock’s spot price nor a relationship between either stock and the index.

### Initial decision

Compute each spread’s intact expiration loss, the combined loss as a percentage of equity, and the initial delta-only P&L if ALFA falls $5 per share. For the separate two-stock proposal, write whether the index scenario determines its dollar P&L. Name the missing risk-factor inputs and their units, and explain how you would use them.

### New information — commit your first decision before reading

One short ALFA put with a $50 strike is assigned while its long put remains open. Identify the gross cash and share transaction. In the separate two-stock proposal, a new joint scenario specifies that ALFA falls $2 per ALFA share and BRAVO rises $3 per BRAVO share. Holding initial deltas fixed, give each stock’s dollar contribution and the combined estimated P&L before costs.

### Defense

- The manager adds +40 ALFA-share equivalents and −10 BRAVO-share equivalents and calls the portfolio “long 30 shares of the index.” What risk factor, price changes and units would support an index sensitivity?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Each spread can lose ($5 − $1) × 100 = $400 before fees. Together they can lose $800, or 4% of the $20,000 portfolio, exceeding the $200 limit. For an ALFA decline of $5 per share, the two spreads’ current delta implies 40 × (−$5) = −$200 of local P&L. Their different entry dates leave both exposed to the same expiration outcome. Assignment buys 100 ALFA shares for $5,000 and leaves the long put open. The account needs a separate funding check.

For the two-stock proposal, the index move alone leaves each stock’s move unknown. A valid answer specifies a dollar move per ALFA share and per BRAVO share, or supplies starting prices in dollars per share and a modeled percentage move in each stock for each 1% index move. State the assumptions behind that mapping. With the update’s explicit stock shocks, ALFA contributes +40 × (−$2) = −$80 and BRAVO contributes −10 × (+$3) = −$30. The combined first-order estimate is −$110 before costs. Changing sensitivities, IV or liquidity would require more information.

### Weak — unsupported submission

Two tickets halve the risk, and net delta bounds the loss. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

The two spreads can lose $800, or 4% of equity. The ALFA assignment uses $5,000 and leaves the long put open. In the separate two-stock scenario, ALFA contributes −$80 and BRAVO contributes −$30, giving −$110. This answer still needs to explain which inputs were missing from the manager’s original index scenario and defend an action under the $200 limit.

### Excellent — defended and qualified submission

I would decline further exposure under the $200 limit. Even one $400 spread exceeds it. I would check the funding available for the $5,000 ALFA share purchase and value the surviving long put separately. For the two-stock proposal, +40 ALFA-share equivalents describe sensitivity to ALFA, and −10 BRAVO-share equivalents describe sensitivity to BRAVO. A 1% index rise leaves each stock’s dollar move unspecified. I would request per-name shocks in dollars per share, or percentage responses to the index and starting stock prices. Under the supplied −$2 and +$3 stock moves, the estimated contributions are −$80 and −$30, for −$110 before costs. I would reprice both positions if the size of the shocks makes frozen deltas unreliable.

### Rubric

- **Contract, units and calculation:** Names the underlying for each share-equivalent delta and the units for every stock shock. Computes dollar contributions before aggregation and reconciles the $5,000 assignment cash separately.
- **Objective and alternatives:** The recommendation serves this outcome: Aggregate correlated losses and reconcile both equity and funding under stress. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** Identifies the missing per-stock moves under the 1% index shock, or supplies a justified stock-to-index mapping and the prices needed to convert percentage changes to dollars per share. Explains the limits of a local estimate.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend “Two small tickets, one large shock.” Compute each spread’s intact expiration loss, the combined loss as a percentage of equity, and the initial delta-only P&L if ALFA falls $5 per share. For the separate two-stock proposal, write whether the index scenario determines its dollar P&L. Name the missing risk-factor inputs and their units, and explain how you would use them.

- Dated initial recommendation written before the update.
- A signed ledger for the original spreads and the separate two-stock scenario. Name each underlying, state delta and shock units, and show each dollar P&L contribution.
- A written explanation of which risk-factor inputs are missing from the 1% index scenario, what units they need, and how they would allow a local dollar estimate. Defend an alternative under the $200 risk limit.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Create eight named joint shocks covering price, IV, time, liquidity and assignment. Identify which require repricing, which require a cash ledger and which remain unquantified.
- Given only signed share-equivalent deltas for two different stocks, explain what additional information a specified index move needs to produce estimated dollar P&L. Give the units of each input.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [Cboe describes price, volatility, time, and historical-event stress](https://www.cboe.com/solutions/options-analytics/portfolio-margin-analytics/stress-tests/)
- [OCC's STANS](https://www.theocc.com/risk-management/margin-methodology)
- [FINRA assignment guide](https://www.finra.org/investors/insights/trading-options-understanding-assignment)

## Module 25: Choose one field to investigate deeply

Select a feasible research specialization with explicit resources and failure criteria.

Stage: Research, portfolio policy and defense. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 24.

### Decision, intuition and learning outcome

## Begin with a decision

Specialization is a resource allocation decision. The right project is narrow enough to audit and important enough to justify its data, mathematical and operational demands. Feasibility is part of intellectual quality, not a concession after the analysis fails.

**Learning outcome:** Select a feasible research specialization with explicit resources and failure criteria.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

Options trading contains several professions. A portfolio manager may use puts to manage downside exposure; a volatility researcher may compare implied and realized movement; a systematic trader may define repeatable index-option rules; an event researcher may study earnings; a market maker needs quoting, hedging, technology, and substantial operational support. Options on futures add another contract system. Knowing the same Greek names does not make the work interchangeable.

Revisit the **feasibility test begun in Module 21** when choosing a long-term specialization. Ask four questions: (1) What specific question excites you enough to study for years? (2) What data are needed, and can you legally and affordably obtain them? (3) What technology, time, and capital would implementation require? (4) Can you measure a fair benchmark and the main way the idea could fail? For example, market making cannot be credibly backtested by pretending to buy at every bid and sell at every ask. Quote placement, queue priority, nonfills, hedging, fees, inventory, and adverse selection are the work. If you cannot observe those, choose a narrower research question rather than claiming a market-making edge.

Here are six possible research tracks. **Hedging and overlays:** measure how much a put or collar reduces drawdown and how much return it costs. **Volatility relative value:** compare contracts across strike and tenor, with careful model and execution checks. **Systematic index options:** compare an explicit rule with a published methodology such as [Cboe's BXM covered-call index](https://www.cboe.com/us/indices/dashboard/bxm/) and its [methodology](https://cdn.cboe.com/api/global/us_indices/governance/Cboe_BuyWrite_Indices_Methodology.pdf). **Event options:** align earnings announcements and quote timestamps; distinguish the event move from the paid IV. **Market microstructure:** study quotes, auctions, and execution rather than promising easy spread capture. **Options on futures:** begin with [CME's separate curriculum](https://www.cmegroup.com/education/courses/curriculum-all-about-options) because the underlying, multiplier, margin, and settlement can differ from stock options.

Worked decision example: A learner has 10 hours a week and no paid option history. A full intraday relative-value backtest needs quote-by-quote data they cannot yet access. They can compare **published BXM daily index history** with an underlying total-return benchmark as an educational study, while clearly labeling both as published indices. Faithfully replicating BXM's option trades would require historical option quotes and methodology details, often with paid data. The appropriate choice for this module is the study they can **actually audit**. That judgment says nothing about which strategy will make money. Avoid buying data or a course simply because its marketing promises an edge.

**Common mistake:** trying to master all six tracks at once. Specialization creates a research question narrow enough to falsify.

### Four-week practice

| Week | Work for the 10 hours | Evidence |
| --- | --- | --- |
| 97 | Compare at least three tracks using interest, data, skills, time, capital, and failure modes; continue the level-appropriate forward record. | Feasibility matrix. |
| 98 | Read two primary sources in the chosen track, including product specifications or a published index methodology; continue the forward record. | Annotated source notes. |
| 99 | Build a small, reproducible study or simulation with a comparator; continue the forward record. | Notebook or written calculation. |
| 100 | Write a one-page argument against your conclusion and revise the feasibility judgment; continue the forward record. | Specialization memo. |

### Try it, then check

1. Why is buying at every bid and selling at every ask a bad market-making backtest? **Answer:** It ignores who gets filled, queue position, informed orders, hedging, fees, and inventory risk.
2. Does a futures option necessarily have the same 100-share deliverable as a stock option? **Answer:** No. Check that product's CME contract specification and settlement rules.
3. What is a fair question for a protective-put overlay? **Answer:** Whether the measured drawdown reduction, after premiums and costs, is worth the foregone return under a fixed objective, versus unhedged ownership.
4. If a necessary dataset is unavailable, what is a defensible result? **Answer:** Narrow or defer the study and document the limitation. Do not fill missing data with favorable assumptions.

**Pass gate:** One feasible track, a small reproducible project, at least one comparison, and a written account of the skills/data still missing.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** With the same hours but strong numerical skills and no Python, redesign the project scope. Which prerequisite work should precede a professional implementation claim?

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: A specialization that can be completed

**Fictional teaching case.** A fictional learner has ten hours per week for twelve weeks, basic Python and a $300 research budget. They compare intraday market making, a published-index overlay study and a synthetic hedging engine.

Available effort: 120 hours. Market-making proposal requires queue-level data not currently licensed. Index history and methodology are accessible. Synthetic engine inputs can be independently specified, but its outputs cannot establish historical executable returns.

### Initial decision

Build a feasibility matrix and select one project. Define the deliverable, evidence level, prerequisite gaps, reviewer and criteria for narrowing or stopping it.

### New information — commit your first decision before reading

A vendor offers a $250 dataset without quote timestamps, clear product coverage or an explicit permitted-use statement. Decide what due diligence is needed before spending most of the budget.

### Defense

- What is the strongest reason to disagree with your recommendation in 'A specialization that can be completed'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

There is no uniquely correct interest choice. The index study can support a level B comparison; the engine can support level A software/hedging-accounting checks. The intraday market-making claim is not feasible with missing queue and execution evidence. A good plan allocates the 120 hours among source study, implementation, validation and defense and states what will be omitted. Price alone does not establish dataset suitability; inspect fields, timing, coverage, license and a sample before purchase. Deferring purchase can be a well-supported project decision.

### Weak — unsupported submission

Buy the dataset because paying for data automatically makes the project professional. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

There is no uniquely correct interest choice. The index study can support a level B comparison; the engine can support level A software/hedging-accounting checks. The intraday market-making claim is not feasible with missing queue and execution evidence. A good plan allocates the 120 hours among source study, implementation, validation and defense and states what will be omitted. Price alone does not establish dataset suitability; inspect fields, timing, coverage, license and a sample before purchase. Deferring purchase can be a well-supported project decision. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

I choose an auditable level A or B question, budget the 120 hours and verify data suitability before purchase. My deliverable states exactly what its evidence can establish and what remains unavailable.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Select a feasible research specialization with explicit resources and failure criteria. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'A specialization that can be completed'. Build a feasibility matrix and select one project. Define the deliverable, evidence level, prerequisite gaps, reviewer and criteria for narrowing or stopping it.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- With the same hours but strong numerical skills and no Python, redesign the project scope. Which prerequisite work should precede a professional implementation claim?
- Teach the central distinction of 'A specialization that can be completed' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [Cboe's BXM covered-call index](https://www.cboe.com/us/indices/dashboard/bxm/)
- [methodology](https://cdn.cboe.com/api/global/us_indices/governance/Cboe_BuyWrite_Indices_Methodology.pdf)
- [CME's separate curriculum](https://www.cmegroup.com/education/courses/curriculum-all-about-options)

## Module 26: Defend the work in an independent audit

Defend a reproducible project and revise conclusions when evidence changes.

Stage: Research, portfolio policy and defense. Study allocation: Four-week study reference; advance through demonstrated work. Prerequisites: 25.

### Decision, intuition and learning outcome

## Begin with a decision

A capstone defense is an audit conversation. The reviewer should be able to follow the original question through data, method, costs, exceptions and conclusion. A persuasive presentation cannot replace a missing cash line or a consumed holdout.

**Learning outcome:** Defend a reproducible project and revise conclusions when evidence changes.

**Opening diagnostic:** Read the case brief and write the first two facts you would verify before calculating. Explain your initial intuition in three sentences, without reading the staged update or debrief. This is a baseline, not a graded claim of mastery.

**Study sequence:** Read the core teaching; reproduce one calculation without the answer; prepare the initial case memo; reveal the changed information; revise; then defend the decision and complete a fresh transfer case. The four-week reference pace can be extended when prerequisites need work.

### Core teaching and worked practice

### Lesson

The final project is an **evidence bundle**, not a victory presentation. An auditor should be able to see the original question, evidence level A/B/C, every variant tried, data and code versions, decision timestamps, and the level-appropriate ledger, methodology, benchmark, risk checks, and forward record. Level C includes fill and fee assumptions, risk-limit breaches, empty days, rejected orders, and failed hypotheses. Level A preserves failed synthetic cases; level B preserves index revisions and methodological limitations. Selective reporting is itself a failed process.

Reconcile money before interpreting skill. The following is a **level C trade-ledger illustration**. Suppose a hypothetical study of 100 trades shows **$2,400 gross profit measured at frictionless reference-mid prices**, **$300 commissions**, and **$700 execution slippage relative to those mid prices**. Net trading profit is `$2,400−$300−$700=$1,400`. If gross profit had already used actual fills, deducting slippage again would double-count it. If a $200 data expense is also part of running the research, project net after that expense is **$1,200**. Starting with $20,000, paying that expense from the project capital, and assuming no other deposits or withdrawals gives $21,200, a **6%** total project return for the *stated sample dates*. Keep trading and research expenses separate in the report so the reader can reconcile both. If a fair benchmark ended at $21,400 from the same $20,000 starting amount, the project trailed it by **$200**, or one percentage point of initial capital, before comparing risk.

Suppose equity reached $22,000, then fell to $19,800 before recovering. The peak-to-trough drawdown was `(22,000−19,800)÷22,000=10%`. A positive ending return did not erase the interim risk. Check that the trade ledger really supports the equity path and that the account had enough buying power and cash when required. If the project has only a few months of forward decisions or one market regime, call the result preliminary. Do not annualize a short sample into a career claim. An independent reviewer should try to reproduce calculations and find a case that breaks the thesis. If they find an error, preserve both the original and corrected report.

Your conclusion can be **reject**, **inconclusive**, or **continue forward research**. The capstone passes when the work is honest and reproducible, including a negative result. Real capital remains a separate personal decision subject to [the risk guide](RISK_AND_OPERATIONS.md), broker permissions, finances, and continuing evidence. Neither this course nor a simulator certifies profitability.

**Common mistake:** calling a strategy “verified” because the historical and paper charts both rise. A paper simulator can give unrealistic fills, and both periods may share the same favorable regime. [IBKR documents its simulator limitations](https://www.ibkrguides.com/orgportal/aboutpapertradingaccount.htm).

### Four-week practice

| Week | Work for the 10 hours | Evidence |
| --- | --- | --- |
| 101 | A: reconcile simulation cases. B: reconcile source index and comparator series. C: reconcile every trade, cash flow, and forward shadow record. Reproduce from a clean run. | Level-appropriate ledger or source/methodology manifest. |
| 102 | A: report case coverage and failures. B: report published return, drawdown and methodology sensitivity. C: report net results, benchmark, tail risk, costs and forward differences. | Level-appropriate audit and limitations report. |
| 103 | Give the bundle to a knowledgeable reviewer and ask for counterexamples; continue the level-appropriate forward record. | Questions, found issues, and responses. |
| 104 | Present the revised work and state reject/inconclusive/continue with reasons; preserve the complete record and earlier report. | Final report and preserved earlier version. |

### Try it, then check (the arithmetic questions below use the level C illustration)

1. What is trading net after $2,400 gross, $300 commissions, and $700 slippage? **Answer:** $1,400.
2. What is project net after a further $200 data expense, and return on $20,000 without cash flows? **Answer:** $1,200 and 6% for the full sample, not an annualized rate.
3. What is drawdown from $22,000 to $19,800? **Answer:** $2,200 ÷ $22,000 = 10%.
4. If the comparator earned 7% over the same sample and starting capital, did 6% outperform? **Answer:** No; it lagged by one percentage point before adjusting for different risks.
5. Can an inconclusive result pass the course? **Answer:** Yes, if data, assumptions, full results, limits, and errors are honestly documented and reproducible.

**Final pass gate:** A second person can reproduce the calculations and understand why the conclusion follows from the chosen evidence level. At level A, only software behavior is established; at B, a comparison of published histories; at C, a conditional net, dated, risk-aware estimate whose execution and forward limits are explicit. The [research lab](RESEARCH_LAB.md) supplies the full audit specification. Future expertise comes from repeating this cycle across different market conditions and updating claims when evidence changes.

### Seminar preparation and transfer

## From calculation to recommendation

Use the original module practice below as the mathematical/mechanical foundation. For the seminar case, preserve five separate entries: initial recommendation, analysis and units, risks and missing information, response to the update, and final reflection.

**Guided rehearsal:** Explain the first numerical or accounting relationship in the case exhibit aloud. Then change one input yourself and predict which part of the answer should change. Verify the change by recomputing; an unexplained correct number is not yet an adequate decision argument.

**Independent transfer:** Draft a ten-minute defense covering claim, evidence level, one hand reconciliation, failed variants, largest uncertainty and what would reverse the conclusion. Ask a reviewer to change one assumption.

**Peer or tutor challenge:** Ask another person to identify one unsupported assumption and one omitted alternative. For solo work, write the strongest objection before opening the debrief. Treat self-review as self-review; it is not independent reviewer approval.

**Later check:** Return after at least seven days and solve the transfer case without the original solution. Record date, assistance and corrections. A tutor should change a material condition after a previously seen case; changing numbers alone is useful arithmetic practice but does not ensure conceptual transfer.

### Case: The committee asks for the missing ledger

**Fictional teaching case.** A fictional research team presents $2,400 gross midpoint profit on a $20,000 project. It claims a strong strategy but omits execution costs from the first slide. The reviewer asks for complete reconciliation and a fair comparator.

Trading commissions $300; execution slippage relative to the gross midpoint convention $700; separately paid project data expense $200. No other cash flows. Same-period benchmark ends at $21,400. Project equity once reached $22,000 and then $19,800.

### Initial decision

Reconcile trading net, project net, ending capital, sample return and peak-to-trough drawdown. Give a defensible conclusion and specify the evidence bundle another person needs.

### New information — commit your first decision before reading

The gross report is discovered to have already used actual fills rather than midpoint marks. Explain why slippage must not be deducted twice and how the corrected convention changes the accounting before any performance claim is revised.

### Defense

- What is the strongest reason to disagree with your recommendation in 'The committee asks for the missing ledger'?
- Which supplied fact or assumption most affects your conclusion, and how would a change alter it?
- Reproduce one cash-flow or numerical relationship without the worked answer.
- What would this exercise permit you to conclude, and what evidence remains unavailable?

### Debrief — attempt the case first

Under the original midpoint convention, trading net is $1,400 and project net $1,200, ending capital $21,200 and return 6% over the stated dates. The project trails the benchmark by $200 before risk comparison. Drawdown from $22,000 to $19,800 is 10%. If gross instead already used actual fills, the $700 slippage is already embedded; subtract only commissions and the separate data expense from that gross convention, subject to verifying the report. Preserve both versions, explain the discrepancy and rerun the full ledger rather than changing a slide in isolation.

### Weak — unsupported submission

The ending profit is positive, so missing details and benchmark underperformance do not matter. This answer misses a core distinction and cannot support the requested decision.

### Adequate — calculation established submission

Under the original midpoint convention, trading net is $1,400 and project net $1,200, ending capital $21,200 and return 6% over the stated dates. The project trails the benchmark by $200 before risk comparison. Drawdown from $22,000 to $19,800 is 10%. If gross instead already used actual fills, the $700 slippage is already embedded; subtract only commissions and the separate data expense from that gross convention, subject to verifying the report. Preserve both versions, explain the discrepancy and rerun the full ledger rather than changing a slide in isolation. The calculation addresses the central fact, but full credit also requires a justified alternative, uncertainty and an explicit response to the update.

### Excellent — defended and qualified submission

I reconcile $1,200 project net under the midpoint convention, report the 10% drawdown and benchmark gap, and preserve the correction when gross pricing convention changes. The conclusion follows the audited evidence, including negative or inconclusive findings.

### Rubric

- **Contract, units and calculation:** Every supplied amount and unit is reconciled; a reader can reproduce the case arithmetic, and missing quantities remain explicitly unknown.
- **Objective and alternatives:** The recommendation serves this outcome: Defend a reproducible project and revise conclusions when evidence changes. It compares the strongest relevant alternative rather than selecting a familiar label.
- **Risk and evidence:** The memo identifies the case-specific limiting assumption, distinguishes known facts from modeled quantities, and explains a plausible adverse outcome.
- **Revision and communication:** The initial answer is preserved; the update produces an explained revision or defended continuation, with a concise response to a reviewer challenge.

### Assignment

Prepare and defend 'The committee asks for the missing ledger'. Reconcile trading net, project net, ending capital, sample return and peak-to-trough drawdown. Give a defensible conclusion and specify the evidence bundle another person needs.

- Dated initial recommendation written before the update.
- Reproducible calculation or account/evidence reconciliation with units and assumptions.
- Comparison with at least one relevant alternative and one reason your choice can disappoint.
- Preserved revision responding to the staged update and reviewer questions.
- Fresh transfer solution, later retest record and a statement of assistance used.

### Later transfer questions

- Draft a ten-minute defense covering claim, evidence level, one hand reconciliation, failed variants, largest uncertainty and what would reverse the conclusion. Ask a reviewer to change one assumption.
- Teach the central distinction of 'The committee asks for the missing ledger' to a nontechnical committee member in ninety seconds.
- What was your first misconception, what evidence corrected it, and can you explain the correction without reopening the debrief?

### Primary references

- [IBKR documents its simulator limitations](https://www.ibkrguides.com/orgportal/aboutpapertradingaccount.htm)