# Form C: A partial fill changes the hedge — update packet

Release only after the initial response has been saved. Preserve it, then write and defend a separate revision.

Regardless of your initial recommendation, audit this **separate supplied execution episode for D**. One put actually fills at $5.00; both calls actually sell at $3.00; the remaining put order is cancelled and the cancellation is acknowledged. Entry fees are $1 for each of the three filled contracts. No other trades occur.

Reconcile cash, shares, long puts and short calls. Has the planned downside floor been established? There is a new offer to buy one additional matching put at a supplied $6.00 ask, with a $1 fee, but no fill yet. Would completing that purchase at the supplied terms meet the cash reserve? Explain what can and cannot be concluded if the committee instead wants to close an existing leg; no exit quote has been supplied.
