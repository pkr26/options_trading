# Your offline options course

Start with [the beginner course](beginner/README.md). This package contains 64 small lessons, review aids, reference chapters, Python teaching scripts and synthetic lab data. No brokerage account is needed.

MY_LEARNING_RECORD.md is a newly generated blank template. The existing personal learning record, completion history, notes, accounts and application databases are not included.

The browser application source and dependencies are not included. [Application note](course-app/README.md) explains that boundary. Root documents may describe the app or link to its source checkout; use the course Markdown directly for offline study.

For Python practice, see [the teaching labs](labs/README.md). All supplied market data are synthetic unless a document explicitly says otherwise.
