# Form A: The near-term cash reserve — update packet

Release only after the initial response has been saved. Preserve it, then write and defend a separate revision.

Before any order fills, the committee raises its immediate accessible-cash reserve from **$2,500 to $2,800**. Quotes and fees are unchanged. It asks you to preserve the original comparison and explain any revised recommendation. A colleague suggests ignoring a $106 shortfall because “the collar's shares are valuable.” Address that proposal. Do not silently resize a portfolio while retaining its original results.
