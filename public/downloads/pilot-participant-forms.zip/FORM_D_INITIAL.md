# Form D: Adjusted deliverables and surviving coverage — initial packet

Fictional teaching data. Save your initial recommendation, calculations and uncertainty before requesting the separate update. Record prior exposure and any assistance; this public blueprint is not automatically an unseen assessment.

## Contract and accounting conventions

All issuers, portfolios, quotes, fills, events and mandates below are invented. Cash interest, dividends, taxes, stock commissions and modeled settlement charges are zero. Each filled option entry contract costs a total $1 fee for that leg. Premiums already paid or received remain part of cash; they are not counted again in terminal payoff. Use supplied option asks for purchases and bids for sales. Displayed quotes alone do not guarantee a fill. Adequate size and actual execution at the supplied side are stipulated only for each initial comparison.

Initial scenario tables assume the stated positions remain intact until the common three-month expiration and value the supplied terminal rights/obligations. They do not predict an American option's pre-expiration value or eliminate early-assignment exposure. Where an update supplies an American-style physical-assignment event, rebuild positions and cash from that event; it is a separate operational rehearsal. Do not invent option marks, exit prices, exercise choices or broker permissions that the packet does not supply.

### Learner packet

The fictional Delta committee owns **400 shares at $25 and $3,000 cash**, total current wealth **$13,000**. It seeks three-month downside protection with some upside participation and requires **$2,600 accessible cash immediately after implementation**. Borrowing and uncovered short calls are not authorized.

The following are **fictional, explicitly specified adjusted contracts**. Each delivers **50 shares**. Premium multiplier and exercise-price multiplier are each **100**; they are separate supplied fields. For one put with strike label $12, exercise delivers 50 shares and receives $1,200 aggregate strike cash. For one call with strike label $15, assignment delivers 50 shares and receives $1,500 aggregate strike cash. At terminal stock price S, one put payoff is `max(1,200−50S,0)`; one short call's obligation is `max(50S−1,500,0)`. Do not substitute standard 100-share deliverables.

| Instrument | Premium bid | Premium ask | Dollar premium for one contract at the relevant side |
|---|---:|---:|---:|
| Adjusted put, strike label $12 | $0.50 | $0.60 | Buy at $0.60×100 = $60 |
| Adjusted call, strike label $15 | $0.20 | $0.30 | Sell at $0.20×100 = $20 |

- **A: Hold.** Keep 400 shares and cash.
- **B: Reduce shares.** Sell 200 shares at $25; keep 200 shares and retained cash/proceeds.
- **C: Protect.** Buy enough of the supplied puts to match 400 shares, keeping the stock and paying entry fees.
- **D: Collar.** Buy the same puts and sell enough of the supplied calls to match those 400 shares, including entry fees for each leg.

Determine contract counts, aggregate premiums, cash, terminal wealth and change from $13,000 at stock prices **$10, $24, $25, $30 and $40**. Identify the implied economic stock-price floor and ceiling from the supplied deliverables and strike cash; the strike labels alone do not give those stock-price levels. Test the cash reserve and recommend a choice.

Defense question: Which three quantities must be kept separate when a contract is adjusted?
