# Form A: The near-term cash reserve — initial packet

Fictional teaching data. Save your initial recommendation, calculations and uncertainty before requesting the separate update. Record prior exposure and any assistance; this public blueprint is not automatically an unseen assessment.

## Contract and accounting conventions

All issuers, portfolios, quotes, fills, events and mandates below are invented. Cash interest, dividends, taxes, stock commissions and modeled settlement charges are zero. Each filled option entry contract costs a total $1 fee for that leg. Premiums already paid or received remain part of cash; they are not counted again in terminal payoff. Use supplied option asks for purchases and bids for sales. Displayed quotes alone do not guarantee a fill. Adequate size and actual execution at the supplied side are stipulated only for each initial comparison.

Initial scenario tables assume the stated positions remain intact until the common three-month expiration and value the supplied terminal rights/obligations. They do not predict an American option's pre-expiration value or eliminate early-assignment exposure. Where an update supplies an American-style physical-assignment event, rebuild positions and cash from that event; it is a separate operational rehearsal. Do not invent option marks, exit prices, exercise choices or broker permissions that the packet does not supply.

### Learner packet

The fictional Alder committee owns **300 shares at $40 and $3,000 cash**, a total current resource value of **$15,000**. Over the next three months it wants less downside while retaining some participation in a rise. Borrowing and naked short options are not permitted. It requires **at least $2,500 of accessible cash immediately after implementation**. This is a reserve requirement; no bill is paid in the scenario table.

Every option has a 100-share deliverable, premium multiplier 100, and aggregate exercise cash of strike × 100.

| Instrument | Bid/share | Ask/share |
|---|---:|---:|
| $36 put | $1.70 | $2.00 |
| $46 call | $1.00 | $1.30 |

Compare these specified alternatives:

- **A: Hold.** Keep all 300 shares and cash.
- **B: Reduce shares.** Sell 100 shares at $40; keep 200 shares and the proceeds plus original cash.
- **C: Protect.** Keep 300 shares and buy three $36 puts at the ask, including entry fees.
- **D: Collar.** Keep 300 shares, buy three $36 puts at the ask and sell three covered $46 calls at the bid, including fees for all six contracts.

Build terminal wealth for stock prices **$20, $36, $40, $46 and $55**, and change from $15,000. Include a zero-stock boundary for the protected portfolios. Identify which choices meet the immediate cash reserve, then recommend a choice or explain what further mandate information prevents a choice. These scenario prices are not probabilities.

Defense question: Which alternative most strongly challenges your recommendation, and how much protection or upside do you surrender by rejecting it?
