# Form B: Protection and a share-retention mandate — initial packet

Fictional teaching data. Save your initial recommendation, calculations and uncertainty before requesting the separate update. Record prior exposure and any assistance; this public blueprint is not automatically an unseen assessment.

## Contract and accounting conventions

All issuers, portfolios, quotes, fills, events and mandates below are invented. Cash interest, dividends, taxes, stock commissions and modeled settlement charges are zero. Each filled option entry contract costs a total $1 fee for that leg. Premiums already paid or received remain part of cash; they are not counted again in terminal payoff. Use supplied option asks for purchases and bids for sales. Displayed quotes alone do not guarantee a fill. Adequate size and actual execution at the supplied side are stipulated only for each initial comparison.

Initial scenario tables assume the stated positions remain intact until the common three-month expiration and value the supplied terminal rights/obligations. They do not predict an American option's pre-expiration value or eliminate early-assignment exposure. Where an update supplies an American-style physical-assignment event, rebuild positions and cash from that event; it is a separate operational rehearsal. Do not invent option marks, exit prices, exercise choices or broker permissions that the packet does not supply.

### Learner packet

The fictional Birch committee owns **300 shares at $60 and $4,000 cash**, total current wealth **$22,000**. It wants to reduce the risk of a severe decline over three months while retaining some upside. It requires **$3,000 accessible cash immediately after implementation** and has not authorized borrowing or naked short options.

All options have a common three-month expiration, standard 100-share deliverable, premium multiplier 100 and aggregate exercise cash of strike × 100. The initial terminal table uses the shared intact-position assumptions; the update supplies an additional American-style implementation constraint.

| Instrument | Bid/share | Ask/share |
|---|---:|---:|
| $55 put | $2.60 | $3.00 |
| $70 call | $2.00 | $2.40 |

- **A: Hold.** Keep 300 shares and cash.
- **B: Reduce shares.** Sell 100 shares at $60, leaving 200 shares and retained cash/proceeds.
- **C: Protect.** Keep 300 shares and buy three $55 puts at the ask, with entry fees.
- **D: Collar.** Keep 300 shares, buy three $55 puts at the ask and sell three covered $70 calls at the bid, with all entry fees.

Show cash and terminal wealth at stock prices **$35, $55, $60, $70 and $85**, plus change from $22,000. Identify the severe boundary, cash feasibility and the cost of retaining or surrendering upside. Recommend an action under an explicit interpretation of the downside objective.

Defense question: Why can the portfolio with the higher terminal floor still be unsuitable for an implementation mandate?
