# Form B: Protection and a share-retention mandate — update packet

Release only after the initial response has been saved. Preserve it, then write and defend a separate revision.

The committee clarifies that it must retain **at least 200 of the original shares until a specified date before expiration**. For this operational rehearsal the option contracts are American-style and physically settled; the committee cannot control whether its short calls are assigned before that date. No entry has filled yet.

Assess each original choice against that share-retention requirement. A colleague proposes a new partial collar: retain 300 shares, buy three puts and sell **only one** call. Reconstruct its entry cash at the same supplied quotes and fees. Would one assigned short call leave enough shares? Do not assume the original full-collar payoff table applies to this new portfolio.
