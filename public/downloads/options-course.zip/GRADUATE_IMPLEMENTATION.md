# Advanced Academy implementation

Delivered November 14, 2026. Open **Advanced academy** in the existing Options Academy app. The beginner course remains the entry path; advanced prerequisites guide preparation and every module can be previewed.

## Phase 1 — complete teaching packages

The advanced curriculum now has 26 app-native teaching packages. Each combines the original teaching volume with an original fictional decision case, exhibits, an initial decision, new information, debrief, weak/adequate/excellent submission examples, four rubric dimensions, defense prompts, deliverables and transfer questions. Module 10 is the flagship Trade Design seminar: it compares holding shares, reducing concentration, protective puts and a collar with equal starting resources, quote-side costs, a full scenario table, a changed cash mandate and an operational extension.

The canonical source is `course-app/content/graduate.json`. Primary sources are linked in each package. Fictional data are labeled as teaching inputs. The [teaching standard](GRADUATE_TEACHING_STANDARD.md) describes the assessment and review expectations.

## Phase 2 — learning and evidence infrastructure

The app provides classrooms, a staged case studio, numeric practice, a mistake journal, competency evidence and a capstone workspace. Initial submissions, later revisions and drafts are appended to the learner's private database records. Course packets and versions are preserved with submissions. Conflicting tab saves are rejected; the learner can compare and reconcile edits. Saved work reloads, memo drafts survive navigation within the app, and browser departure warns about unsaved work. Advanced modules have bookmark URLs.

All 26 modules have three server-graded numerical practice questions per set with deterministic variations, hints and explained feedback. The server derives keys and saves the original response. Generated question families are practice; independent assessment requires a reviewer to provide genuinely unfamiliar cases. The evidence screen separates writing awaiting review from numeric results and identifies later study checks. It does not infer mastery from reading, a text-length threshold or submitting a memo.

## Phase 3 — laboratories, extension and release checks

Four laboratories require a prediction before revealing their results: equal-budget portfolio protection, European prices and Greeks, an assigned short call's cash/share ledger, and supplied partial/nonfill execution episodes. Tables accompany the explanations. Model values, local approximations, terminal values and stipulated fills remain distinct. The advanced Markdown download and full offline ZIP contain the complete teaching packages. The ZIP includes the supporting reference files; the standalone Markdown identifies additional library references by name.

The new schema migration is additive and keeps beginner progress, notes and scores intact. New advanced records begin empty. Learner-specific exports include immutable revisions and feedback; published teaching downloads exclude learner records.

## Verification

- 32 unit/content/math/validation tests pass, including 78 independent practice answer checks, pricing reference values, parity, portfolio accounting and migration preservation.
- TypeScript and repository ESLint pass.
- 24 live advanced API checks pass: authentication, owner isolation, immutable revisions, concurrent request handling, strict request validation, hidden pre-submission keys, grading and exports.
- The advanced live browser journey passes: 26-module navigation, commitment, revision, reload, practice, mistake history and mobile layout. Six additional mocked browser checks cover conflict recovery, draft retention and anonymous study.
- The existing 14-stage beginner browser regression suite passes.
- The flagship scenario table and cash update were independently recalculated. A separate pricing implementation checked 90 parameter combinations; differences remained below the cent-display tolerance.
- Desktop and mobile screenshots were inspected. This is targeted accessibility/layout verification, not a full accessibility certification.

Source freshness, local Markdown links, and the production build are checked before publication. Publication outcome is reported separately by the publishing service.

## Phase 4 — learner validation

The [pilot protocol](GRADUATE_PILOT_PROTOCOL.md) is ready. A learner pilot and external academic review have not occurred. They require actual learner work and knowledgeable reviewers. The protocol measures starting ability, unfamiliar-case performance, retention after 7 and 30 days, reasoning quality, misconceptions, time burden and usability. Those results should guide the next revision. No learning gains, academic credit, accreditation or investment performance are claimed from implementation alone.

Written work is supported by task-specific rubrics, annotated examples and guided defense prompts. Independent reviewer feedback should be recorded in the reflection field. The app supplies structured study support and numerical feedback; it does not impersonate a faculty reviewer or an AI grading service.
